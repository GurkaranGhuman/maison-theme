# Product #
- Matching items in footer can update using AJAX, just like the cart menu.