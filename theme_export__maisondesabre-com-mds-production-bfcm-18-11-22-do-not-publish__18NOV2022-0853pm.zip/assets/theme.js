$(document).ready(function(){
  $('.color-list input').change(function() {
   var selected_val =$(this).val();
    console.log(selected_val);
    if(selected_val == 'Selvedge Denim'){
        $(".for-mini-tote-selvedge-denim").show();
        $(".for-mini-tote-other").hide();      
    }
    else{
          $(".for-mini-tote-selvedge-denim").hide();
          $(".for-mini-tote-other").show();
      
      }
});
});
// Gift Card Js Start
$(document).on('click','.cus_ad_to_cart',function(event){ 
  event.preventDefault();
var vid = $("#gift_vid").val();
$('.gift-spin').removeClass('hide');
$.ajax({
type: 'POST',
url: '/cart/add.js',
data: {
  quantity: 1,
  id: vid
},
dataType: 'json', 
 success: function (data) { 
   $('.gift-spin').addClass('hide');
  loadCart(0);
 } 
 });
});
// Gift Card Js End
// ♈︎♉︎♊︎♋︎♌︎♍︎♎︎♏︎♐︎♑︎♒︎♓︎ 
var regex = new RegExp('^[a-zA-Z0-9.!@*^#=~$#♡&\-]+$');
var clearInvalid;
// Personalise Initials
function isShortMonogram(shortMonogram) {
  if(shortMonogram == 'Airpods' || shortMonogram == 'Sling Bag' || shortMonogram == 'Statement Strap' || shortMonogram == 'Backpacks' || shortMonogram == 'Keychain' || shortMonogram == 'Soft Tote' || shortMonogram == 'Camera Bag' || shortMonogram == 'Sling Bag'  || shortMonogram == 'Mini Tote'  || shortMonogram == 'Apple Watch Band' || shortMonogram == 'shortMonogram' || shortMonogram == 'Crossbody Phone Pouch')
    return true;
  return false;
}
function validateIconMonogram(monogram,shortMonogram = false) {
      monogram = monogram.replaceAll('@','');
      monogram = monogram.replaceAll('!','');
      monogram = monogram.replaceAll('=','');
      monogram = monogram.replaceAll('-','');
      monogram = monogram.replaceAll('*','');
      monogram = monogram.replaceAll('^','');
      monogram = monogram.replaceAll('$','');
      monogram = monogram.replaceAll('~','');
  if(shortMonogram) {
  monogram =	validateShortMonogram(monogram);
  }
    return monogram;
}
function checkIcons() {
  var text = localStorage.getItem('mdsEngraving');
  if(text != null) {
  for (var position = 0; position < text.length; position++) {
        if (text.charAt(position) == '@') {
          localStorage.setItem('mdsEngraving',localStorage.getItem('mdsEngraving').replaceAll('@',''));
         
        }
        if (text.charAt(position) == '-') {
          localStorage.setItem('mdsEngraving',localStorage.getItem('mdsEngraving').replaceAll('-',''));
         
        }
        if (text.charAt(position) == '~') {
          localStorage.setItem('mdsEngraving',localStorage.getItem('mdsEngraving').replaceAll('~',''));
         
        }
        if (text.charAt(position) == '=') {
          localStorage.setItem('mdsEngraving',localStorage.getItem('mdsEngraving').replaceAll('=',''));
         
        }
        if (text.charAt(position) == '!') {
          localStorage.setItem('mdsEngraving',localStorage.getItem('mdsEngraving').replaceAll('!',''));
         
        }
        if (text.charAt(position) == '^') {
          localStorage.setItem('mdsEngraving',localStorage.getItem('mdsEngraving').replaceAll('^',''));
         
        }
        if (text.charAt(position) == '$') {
          localStorage.setItem('mdsEngraving',localStorage.getItem('mdsEngraving').replaceAll('$',''));
         
        }
        if (text.charAt(position) == '*') {
          localStorage.setItem('mdsEngraving',localStorage.getItem('mdsEngraving').replaceAll('*',''));
         
        }
      }
  }
}
//'@','+

function validateShortMonogram(Monogram) {
  if(Monogram=='' || Monogram==null) {
  	return '';
  }
  else {
     if(Monogram.length<=2) {
    	return Monogram;
    }
    else {
      Monogram = Monogram.substring(0,3);
      if(Monogram.includes('.')) {
      	return Monogram;
      }
      else {
        return Monogram.substring(0,2);
      }
  	}
  }
  return Monogram;
}
function validateShortMonogram2(Monogram) {
  if(Monogram=='' || Monogram==null) {
  	return '';
  }
  else {
     if(Monogram.length<=2) {
    	return Monogram;
    }
    else {
      Monogram = Monogram.substring(0,4);
      if(Monogram.includes('.')) {
      	return Monogram;
      }
      else {
        return Monogram.substring(0,3);
      }
  	}
  }
  return Monogram;
}
function checkDot(text) {
	for (var position = 0; position < text.length; position++) {
      	if (text.charAt(position) == '.') {
         return true;
        }
   	  }
  return false;
}
var initials = {
  load: function() {
   $('.engrave:not(.cart-engrave)').text(this.get('null',false));
      $('.engrave.airpods-bundle-set:not(.cart-engrave) ,.engrave.mini-tote:not(.cart-engrave)').text(this.get("shortMonogram",false));   //this one  
  $('.engrave.phone-case:not(.cart-engrave)').text(this.get("null",true)); 

$('.engrave.airpods:not(.cart-engrave):not(.airpods-pro) ,.engrave.mini-tote:not(.cart-engrave),.engrave.apple-watch-band:not(.cart-engrave),.engrave.the-apple-watch-band:not(.cart-engrave)').text(this.get("shortMonogram",false));  
 $('.engrave.airpods-bundle-set:not(.cart-engrave) ,.engrave.mini-tote:not(.cart-engrave)').text(this.get("shortMonogram",false));   //this one  
    $('.engrave.airpods:not(.cart-engrave):not(.airpods-pro)').text(this.get("shortMonogram2",false));  

    $('.engrave.phone-case-bundle:not(.cart-engrave)').text(this.get("null",true)); 
        $('.engrave.notebook:not(.cart-engrave)').text(this.get("null",true)); 

  if($('.initials').hasClass('phone-case') || $('.initials').hasClass('phone-case-bundle') || $('.initials').hasClass('notebook') ) {
    $('.initials').val(this.get("null",true));
  }
  else {
    $('.initials').val(this.get('null',false));
  }

    this.update();
  },
   update: function() {
    let field = $('.initials');
    let limit = 2;
     if($('.initials').hasClass('airpods') ) {
       limit = 3;
    }
    if(field.length != 0) {
      let text = $(field).val();
      if(checkDot(text)) {
      	limit = limit+ 1;
      }
      $('.initials-limit').html(text.length + '/' + 5);
      $('.initials-limit-shortMonogram').html(text.length + '/' + limit);
       $('.initials-limit-airpods').html(text.length + '/' + limit);
      if(text.length != 0) {
        $('.initials_field').addClass('has-value');
      } else {
        $('.initials_field').removeClass('has-value');
      }
    }
  },
   get: function(shortMonogram = "null", phone_case = false) {
      let airpods_mono = shortMonogram;
    if(shortMonogram == 'Phone Case' || shortMonogram == 'Phone Case Bundle') {
      phone_case = true;
    }
    shortMonogram = isShortMonogram(shortMonogram);

   if($('.initials').hasClass('phone-case') || $('.initials').hasClass('notebook') || $('.initials').hasClass('phone-case-bundle') ) {
      if(!phone_case){
       if(airpods_mono=="shortMonogram2" ) {
          return validateShortMonogram2(localStorage.getItem('mdsEngraving') != null ? localStorage.getItem('mdsEngraving') : '');
      }
        return validateIconMonogram(localStorage.getItem('mdsEngraving') != null ? localStorage.getItem('mdsEngraving') : '',shortMonogram);
      }
      else {
         return (localStorage.getItem('mdsEngraving') != null ? localStorage.getItem('mdsEngraving') : '');
      }

    }
    else if($('.initials').hasClass('airpods') ) {
          return validateShortMonogram2(localStorage.getItem('mdsEngraving') != null ? localStorage.getItem('mdsEngraving') : '');
      }
      else if(airpods_mono=="shortMonogram2" ) {
          return validateShortMonogram2(localStorage.getItem('mdsEngraving') != null ? localStorage.getItem('mdsEngraving') : '');
      }
    else if(shortMonogram) {
          return validateShortMonogram(localStorage.getItem('mdsEngraving') != null ? localStorage.getItem('mdsEngraving') : '');
      }
   else {
      checkIcons();
      if(airpods_mono=="shortMonogram2" ) {
          return validateShortMonogram2(localStorage.getItem('mdsEngraving') != null ? localStorage.getItem('mdsEngraving') : '');
      }
      else {
        if($('.initials').hasClass('shortMonogram ') ) {
                    return validateShortMonogram(localStorage.getItem('mdsEngraving') != null ? localStorage.getItem('mdsEngraving') : '');

        }
        else {
      		return localStorage.getItem('mdsEngraving') != null ? localStorage.getItem('mdsEngraving') : ''; 
        }
      }
    }

  },
  getMonogram: function() {
    return $('.initials').val();
  },
  set: function(letters) {
    localStorage.setItem('mdsEngraving', letters.toUpperCase());
    this.load();
  },
  invalid: function(e, t) {
    e.preventDefault();
    window.clearTimeout(clearInvalid);
    $('.initials').addClass('invalid');
    $('.tooltip').addClass('active');
    clearInvalid = window.setTimeout(function() {
      $('.initials').removeClass('invalid');
      $('.tooltip').removeClass('active');
    }, 1000 * t);
  },
  showSlide: function() {
      const productSliders = $('.product-images, .product-images-nav, .product-images-mobile').find('.p-slider');
      if($(productSlider)[0] != null) {
        try {
          $(productSliders).slick('slickGoTo', 0, true);
          if(window.matchMedia('(max-width:991px)').matches) {
            let mobileSlider = document.querySelector('.product-images-mobile');
            if(mobileSlider != null) {
              $('html, body').animate({scrollTop: mobileSlider.offsetTop}, 300);
            }
          }
        } catch (error) {
          
        }
      }
  }
};

var artwork = {
  load: function() {
    $('.artwork-engrave:not(.cart-engrave)').removeClass('inner-strength');
    $('.artwork-engrave:not(.cart-engrave)').removeClass('bit-of-sunshine');
    $('.artwork-engrave:not(.cart-engrave)').addClass(this.get().toLowerCase().replace(/ /g, '-'));
    $('.artwork-engrave:not(.cart-engrave)').removeClass('no-artwork');
      
    if($('#artwork')[0] != null) {
      $('#artwork').val(this.get());
      $('.drop-down-artwork .drop-down-btn').text(this.get());

      initials.showSlide();
    }
  },
  get: function() {
    return localStorage.getItem('mdsArtwork') != null ? localStorage.getItem('mdsArtwork') : 'No Artwork';
  },
  set: function(art) {
    localStorage.setItem('mdsArtwork', art);
    this.load();
  }
};

function setZodiacUrl() {
  var is_zodiac_url = window.location.href.split('#');
  if(is_zodiac_url[1] != null) {
    var horoscopes = is_zodiac_url[1].split('-');
    if(horoscopes[0] == 'leo' || horoscopes[0] == 'Leo' ) {
      current_zodiac = 'Leo';
      localStorage.setItem('mdsZodiac', current_zodiac);
      localStorage.setItem('mdsEngraving', '');
      localStorage.setItem('mdsCustomize','horoscopes');
      initials.set('');
      return  current_zodiac;
    }
  }
  return null;
}

//Zodiac
var zodiac = {
  load: function() {
      
    if($('#zodiac')[0] != null) {
      $('#zodiac').val(this.get());

      initials.showSlide();
    }
  },
  get: function() {
    if(setZodiacUrl() != null) {
      return setZodiacUrl();
    }
    return localStorage.getItem('mdsZodiac') != null ? localStorage.getItem('mdsZodiac') : 'No Zodiac';
  },
  set: function(zod,mym_variant = false) {
    if(!mym_variant) {
        localStorage.setItem('mdsZodiac', zod);
    }
    this.load();
    foil.load();
  }
};

var foil = {
  load: function(clickTarget) {
    $('.engrave:not(.cart-engrave), .zodiac-engrave:not(.cart-engrave)').removeClass('gold').removeClass('rose').removeClass('silver').addClass(this.get().toLowerCase());

    if(this.get() == 'Gold') {
      $('.silver-warning').addClass('hidden');
       $('.customizer-color-text').text('Color - Gold');
    }
    else if(this.get() == 'Rose') {
      $('.customizer-color-text').text('Color - Rose Gold');
      $('.silver-warning').removeClass('hidden');
    }
    else {
      $('.silver-warning').removeClass('hidden');
       $('.customizer-color-text').text('Color - Silver');
    }

    if(clickTarget) {
      $('.foil-list input').removeClass('checked');
      $('.foil-list input[value="'+this.get()+'"]').addClass('checked').prop('checked', true);
    }
  },
  get: function() {
    return localStorage.getItem('mdsFoil') != null ? localStorage.getItem('mdsFoil') : 'Gold';
  },
  set: function(colour) {
    localStorage.setItem('mdsFoil', colour);
    $('.foil-list input').removeClass('checked');
    $('.foil-list input[value="'+colour+'"]').addClass('checked').prop('checked', true);
    this.load(false);
  }
};

var valentine = {
  load: function() {
    if(document.querySelector('.valentine-engrave:not(.cart-engrave)') == null) {
      $('.load-valentine').parent().append('<div class="engrave valentine-engrave '+ foil.get().toLowerCase() +'"></div>');
    }

    $('.valentine-engrave:not(.cart-engrave)').removeClass('him-her');
    $('.valentine-engrave:not(.cart-engrave)').removeClass('him-him');
    $('.valentine-engrave:not(.cart-engrave)').removeClass('her-her');
    $('.valentine-engrave:not(.cart-engrave)').removeClass('you');
    $('.valentine-engrave:not(.cart-engrave)').removeClass('no-valentine');
    $('.valentine-engrave:not(.cart-engrave)').addClass(this.get().toLowerCase().replace(/ /g, '-'));
      
    if($('#valentine')[0] != null) {
      if(this.get() == 'no-valentine') {
        $('#valentine').val('');
      } else {
        $('#valentine').val(this.get());
      }
      $('.drop-down-valentine .drop-down-btn').text(this.get());
      $('.valentine-btn').text(this.get().replace(/-/g, '/'));

      initials.showSlide();
    }
  },
  get: function() {
    return localStorage.getItem('mdsCNY') != null ? 'him-her' : 'no-valentine';
  },
  set: function(alias) {
    $('.valentine-prompt').addClass('hidden');
  //  localStorage.setItem('mdsValentine', alias);
    this.load();
  },
  drop: function() {
    $('.valentine-btn').toggleClass('active');
    $('.drop-down-valentine').toggleClass('active');
    $('.valentine-prompt').addClass('hidden');
    
    if(window.matchMedia('(max-width:991px)').matches) {
      let target = document.querySelector('.personalise-form');
      if(target != null) {
        $('html, body').animate({scrollTop: $(target).offset().top}, 300);
      }
    }
  }
};

// CUSTOMIZER
var customizer = {
  load: function(update) {
    if(update) {
      let last_open = localStorage.getItem('mdsCustomize');
      let target = document.querySelector('[data-tab]');
      if(last_open != null) {
        let temp = document.querySelector('[data-tab="'+ last_open +'"]');
        if(temp != null) {
          target = temp;
        }
      }
      let id = target.dataset.tab;
      if(id == 'text') {
        artwork.set('No Artwork');
      }
      if(id == 'artwork') {
        initials.set('');
      }
      localStorage.setItem('mdsCustomize', id);
      $('.customizer_tab.active').removeClass('active');
      $('.customizer_panel.active').removeClass('active');
      $('[data-tab="'+id+'"]').addClass('active');
      $('[data-panel="'+id+'"]').addClass('active');

      var isInstagram = navigator.userAgent.indexOf('Instagram') != -1;
      var isBugged = navigator.userAgent.indexOf('iPhone11') != -1;
      if (isInstagram && isBugged) {
        $('.customizer').css('max-height', 'calc(100% - 36px)').css('overflow', 'scroll');
        $('.customizer_wrap').css('padding-bottom', '4rem');
      }
    }
    customizer.update();

    if(update) {
      setInterval(function() {
        if($('.customizer').hasClass('open')) {
          if($('.customizer_tab.active').length != 0) {
            $('.customizer_tab-active').css('width', $('.customizer_tab.active').width());
            $('.customizer_tab-active').css('left', $('.customizer_tab.active').offset().left - $('.customizer_tab.active').offsetParent().offset().left);
          }
        }
      }, 100);
    }
  },
  update: function() {
	if($('#mym_variant').val() != "true") {
  	if($('.initials').hasClass('phone-case') || $('.initials').hasClass('notebook')) {
      $('#input_text').val(initials.get('null',true));
     }
      else {
  	$('#input_text').val(initials.get());
  }
       if($('.initials').hasClass('silicone-phone-case')) {
      $('#input_text').val('');
     }
      if(initials.get()!=''){
          $('.customizer__text--preset').text(initials.get());
      }
      $('#input_foil-color').val(foil.get());

      if(zodiac.get()=="No Zodiac") { 
      }
      else {
          $('.customizer__zodiac--preset').text(zodiac.get());
      }
      $('#input_valentine').val(valentine.get());

      if($('[data-artwork]').length == 0) { artwork.set('No Artwork'); }
      if($('[data-zodiac]').length == 0) { zodiac.set('No Zodiac'); }

      $('[data-artwork="'+artwork.get()+'"]').addClass('active');
      $('[data-zodiac="'+zodiac.get()+'"]').addClass('active');

      $('.customizer_input').removeAttr('disabled');
    }

    let customized = false;

    if(artwork.get() != "No Artwork" || zodiac.get() != "No Zodiac") {
      $('.customizer_choice').html('<img src="'+$('.item-icon.active img').attr('src')+'" />');
      $('#input_text').attr('disabled', true);
      customized = true;
    }
     if(initials.get('null',true) != "") {
      if($('.initials').hasClass('phone-case') || $('.initials').hasClass('notebook')) {
       $('.customizer_choice').html(initials.get('null',true));
     }
     else {
       $('.customizer_choice').html(initials.get());
     }
      customized = true;
    }
    if(customized && $('#mym_variant').val() != "true" ) {
      $('.customizer_edit').removeClass('hide');
      $('.customizer_personalize').addClass('hide');
    } else {
      $('.customizer_edit').addClass('hide');
      $('.customizer_personalize').removeClass('hide');
    }
    
  },
  open: function() {
    let last_open = localStorage.getItem('mdsCustomize');
    if(last_open != null) {
      customizer.change.tab(last_open);
    }
    if(! $('body').hasClass('template-page-valentines')) {

      scrollLock(function() {
        $('.customizer').addClass('open');
        $('html').addClass('c-open').addClass('no-scroll');
        $('body').css('height', '100vh');
      });
    }
    else {

        $('.customizer').addClass('open');
        $('html').addClass('c-open').addClass('no-scroll');
        $('body').css('height', '100vh');
    }
  },
  close: function() {
    $('.matching-initials').removeClass('invalid');
    customizer.update();
    if(! $('body').hasClass('template-page-valentines')) {
      scrollLock(function() {
        $('.customizer').removeClass('open');
        $('html').removeClass('c-open').removeClass('no-scroll');
      });
  }
  else {
    $('.customizer').removeClass('open');
        $('html').removeClass('c-open').removeClass('no-scroll');
  }
   if(! $('body').hasClass('template-page-valentines')) {
    if(window.matchMedia("(max-width:991px)").matches ) {
      if(initials.get() != "" || artwork.get() != "No Artwork" || zodiac.get() != "No Zodiac") {
        window.scrollTo(0, $('.product-images-mobile').offset().top);
      }
    }
  }
    if($('body').hasClass('template-page-valentines')) {
        if($('.set_2_product select').attr('disabled')) {
          $('.set_main:not(.hide) .set_btn_1').trigger('click');
      }
    else if($('.set_3_product button').attr('disabled') && (!$('.set_2_product select').attr('disabled'))) {
           $('.set_main:not(.hide) .set_btn_2').trigger('click');
      }
    }
  },
    reset: function(tabchange=false,tabtext="null") {  //saving text changes
    if(tabchange) {  //saving text changes
    //do nothing
      if(tabtext=="text"){  //saving text changes
        zodiac.set('No Zodiac');  //saving text changes
        initials.set($('.customizer__text--preset').text());  //saving text changes
      }
       if(tabtext=="horoscopes"){  //saving text changes
        initials.set('');  //saving text changes
        zodiac.set($('.customizer__zodiac--preset').text());  //saving text changes
      }
    }
    else {  //saving text changes
      foil.set('Gold');   //saving text changes
      initials.set(''); //saving text changes
      $('.customizer__zodiac--preset').text('No Zodiac'); //saving text changes
      $('.customizer__text--preset').text(''); //saving text changes
      zodiac.set('No Zodiac'); //saving text changes
      $('.customizer_panel.active .active').removeClass('active'); //saving text changes
    }
    this.validation.text(false);

  
  },
  validation: {
    text: function(hasError) {
      if(hasError) {
        $('.initials,.initials_text').addClass('invalid');
        if($('.initials').hasClass('shortMonogram')) {
            $('.initials_text .error').text('Maximum 2 Characters with only English letters, numbers and the symbols: . & and ♡ (no spaces)');
          }
          else if($('.initials').hasClass('airpods')) {
            $('.initials_text .error').text('Maximum 3 Characters with only English letters, numbers and the symbols: . & and ♡ (no spaces)');
          }
          else {
          $('.initials_text .error').text('Maximum 5 Characters with only English letters, numbers and the symbols:  # & @ - ~ ! = $ ^ * and ♡ (no spaces)');
          }
        $('.customizer_save').attr('disabled', true);
        $('.customizer_save').attr('aria-disabled', true);
      } else {
        $('.initials,.initials_text').removeClass('invalid');
        $('.customizer_save').removeAttr('disabled');
        $('.customizer_save').removeAttr('aria-disabled');
      }
    }
  },
  focus: function() {
    $('.initials_field').addClass('has-focus');
  },
  unfocus: function() {
    if(! $('body').hasClass('template-page-valentines')) {
      if(window.matchMedia('(max-width:991px)').matches) {
        // Scroll up
        if($('.customizer').hasClass('open')) {
          window.scrollTo(0, 0);
        }
      }
    }
    $('.initials_field').removeClass('has-focus');
  },
  change: {
    variant: function(color) {
      color = color.split("mm / ").pop();

      $('.color-list input').each(function(){
        $(this).prop('checked', false);
        $(this).next('span').css('border-color','transparent');
      });
      $('.color-list input[value="'+color+'"]').each(function(){
        $(this).prop('checked', true);
        $(this).next('span').css('border-color','#000');
      });

      $('.list_product-images .active').removeClass('active');
       let selected_color = color.replace(/\W+/g, "-").toLowerCase();
      selected_color.includes('ombr')? selected_color = selected_color.replace('ombr','ombré') : selected_color;
      $('[data-color="'+selected_color+'"]').addClass('active');
      document.querySelector('.container_product-images').setAttribute('class', 'container_product-images ' + selected_color);
      if(color.includes('Bondi') || color.includes('Violet') || color.includes('White') ||  color.includes('Fuchsia') || color.includes('Manhattan') || color.includes('Lavender') || color.includes('Ombré') ) {
         if(! ($('.customizer .engrave').hasClass('backpacks'))) { $('.limited_variant_handles').removeClass('hide');}
      }
      else {
        $('.limited_variant_handles').addClass('hide');
      }
      $('.label_current-color').text(color);
    },
    tab: function(id) {
      let last_open = localStorage.getItem('mdsCustomize');
      if(last_open == null || last_open != id) {
        localStorage.setItem('mdsCustomize', id);
        customizer.reset(true,id);  //saving text changes
      }
      $('.customizer_tab.active').removeClass('active');
      $('.customizer_panel.active').removeClass('active');
      $('[data-tab="'+id+'"]').addClass('active');
      $('[data-panel="'+id+'"]').addClass('active');
    },
    text: function(e) {
      let text = $('.initials').val().toUpperCase();
      let limit=6; //for airpods
      let dotcounter=0;
      if($('.initials').hasClass('shortMonogram')) { //for airpods
       for (var position = 0; position < text.length; position++) {
      	if (text.charAt(position) == '.') {
          limit = 4; //for airpods
          dotcounter++;
        }
   	  }
        if(dotcounter==0) {
        	limit = 3;
          	$('.initials.shortMonogram').attr('maxlength',3);
        }
        else {
        	$('.initials.shortMonogram').attr('maxlength',4);
        }
      	
     } //for airpods
      if($('.initials').hasClass('airpods')) { //for airpods
       for (var position = 0; position < text.length; position++) {
      	if (text.charAt(position) == '.') {
          limit = 5; //for airpods
          dotcounter++;
        }
   	  }
        if(dotcounter==0) {
        	limit = 4;
          	$('.initials.airpods').attr('maxlength',4);
        }
        else {
        	$('.initials.airpods').attr('maxlength',5);
        }
      	
     }
            if($('.initials').hasClass('apple-watch-band')){
         	regex = new RegExp('^[a-zA-Z0-9.]+$');
         }
      if(text.length <= limit) {
        if(text.length <= (limit-1) && (regex.test(text) || text == '') && (limit==6 || (limit<6) ) ) {  //for airpods
          initials.set(text);
          initials.update();
          $('.customizer__text--preset').text(text);  //saving text changes
          customizer.validation.text(false);
        } else {
          $('.initials').val(text);
          initials.update();
          customizer.validation.text(true);
        }
      } else {
        e.preventDefault();
        initials.load();
        customizer.validation.text(true);
      }
      if(text.length !=0 ) {
         
         // motherDayAvailable(false);
        }
        else {
              
            //   motherDayAvailable(true);

        }
    },
    emoji: function(event) {
      let text = $('.customizer_panel.active .initials').val().toUpperCase();
      let limit=6;
      if($('.initials').hasClass('airpods') || $('.initials').hasClass('airpods-bundle-set')) {
       limit=4;
      }
      if(text.length < limit) {
        var emjoi_text = $(event).data( "emoji" ); 
        
          if(emjoi_text == '@') {
           emjoi_text= '\u0040';
          }
          if(emjoi_text == '-') {
           emjoi_text= '\u002D';
          }
          if(emjoi_text == '!') {
           emjoi_text= '\u0021';
          }
          if(emjoi_text == '=') {
           emjoi_text= '\u003D';
          }
          if(emjoi_text == '$') {
           emjoi_text= '\u0024';
          }
          if(emjoi_text == '^') {
           emjoi_text= '\u005E';
          }
          if(emjoi_text == '~') {
           emjoi_text= '\u007E';
          }
          if(emjoi_text == '*') {
           emjoi_text= '\u002A';
          }
          
         console.log(emjoi_text);
        $('.initials').val(text + emjoi_text);
      }
      this.text(null);

      $('.customizer_panel.active .initials').addClass('has-focus');
      $('.customizer_panel.active .initials').focus();
    },
    heart: function() {
      let text = $('.initials').val().toUpperCase();
      if(text.length < 6) {
        $('.initials').val(text + "\u2661")
      }
      this.text(null);
      
      $('.initials_field').addClass('has-focus');
      $('.initials').focus();
    },
     moon: function() {
      let text = $('.initials').val().toUpperCase();
      if(text.length < 5) {
        $('.initials').val(text + "\ue800")
      }
      this.text(null);
      
      $('.initials_field').addClass('has-focus');
      $('.initials').focus();
    },
    foil: function(color) {
      foil.set(color);
    },
    zodiac: function(sign) {
      if(zodiac.get() == sign) {
        zodiac.set('No Zodiac');
        $('.customizer__zodiac--preset').text('No Zodiac');  //saving text changes
      } else {
        zodiac.set(sign);
        $('.customizer__zodiac--preset').text(sign);  //saving text changes
      }
    },
    artwork: function(art) {
      if(artwork.get() == art) {
        artwork.set('No Artwork');
      } else {
        artwork.set(art);
      }
    }
  }
};

let prevScroll = 0;
function scrollLock(func) {
  let scrollLocked = $('html').hasClass('no-scroll');
  if (!scrollLocked) {
    prevScroll = window.scrollY;
    window.scrollTo(0, 0);
    $('html').css('marginTop', '-'+prevScroll+'px');
  }

  func();

  if (scrollLocked) {
    $('body').css('height', '');
    $('html').css('marginTop', '');
    window.scrollTo(0, prevScroll);
  }
}

function isIE() {
  return typeof MSCSSMatrix != "undefined";
}

window.theme = window.theme || {};

/* ================ SLATE ================ */
window.theme = window.theme || {};

theme.Sections = function Sections() {
  this.constructors = {};
  this.instances = [];

  $(document)
    .on('shopify:section:load', this._onSectionLoad.bind(this))
    .on('shopify:section:unload', this._onSectionUnload.bind(this))
    .on('shopify:section:select', this._onSelect.bind(this))
    .on('shopify:section:deselect', this._onDeselect.bind(this))
    .on('shopify:block:select', this._onBlockSelect.bind(this))
    .on('shopify:block:deselect', this._onBlockDeselect.bind(this));
};

theme.Sections.prototype = _.assignIn({}, theme.Sections.prototype, {
  _createInstance: function(container, constructor) {
    var $container = $(container);
    var id = $container.attr('data-section-id');
    var type = $container.attr('data-section-type');

    constructor = constructor || this.constructors[type];

    if (_.isUndefined(constructor)) {
      return;
    }

    var instance = _.assignIn(new constructor(container), {
      id: id,
      type: type,
      container: container
    });

    this.instances.push(instance);
  },

  _onSectionLoad: function(evt) {
    var container = $('[data-section-id]', evt.target)[0];
    if (container) {
      this._createInstance(container);
    }
  },

  _onSectionUnload: function(evt) {
    this.instances = _.filter(this.instances, function(instance) {
      var isEventInstance = instance.id === evt.detail.sectionId;

      if (isEventInstance) {
        if (_.isFunction(instance.onUnload)) {
          instance.onUnload(evt);
        }
      }

      return !isEventInstance;
    });
  },

  _onSelect: function(evt) {
    // eslint-disable-next-line no-shadow
    var instance = _.find(this.instances, function(instance) {
      return instance.id === evt.detail.sectionId;
    });

    if (!_.isUndefined(instance) && _.isFunction(instance.onSelect)) {
      instance.onSelect(evt);
    }
  },

  _onDeselect: function(evt) {
    // eslint-disable-next-line no-shadow
    var instance = _.find(this.instances, function(instance) {
      return instance.id === evt.detail.sectionId;
    });

    if (!_.isUndefined(instance) && _.isFunction(instance.onDeselect)) {
      instance.onDeselect(evt);
    }
  },

  _onBlockSelect: function(evt) {
    // eslint-disable-next-line no-shadow
    var instance = _.find(this.instances, function(instance) {
      return instance.id === evt.detail.sectionId;
    });

    if (!_.isUndefined(instance) && _.isFunction(instance.onBlockSelect)) {
      instance.onBlockSelect(evt);
    }
  },

  _onBlockDeselect: function(evt) {
    // eslint-disable-next-line no-shadow
    var instance = _.find(this.instances, function(instance) {
      return instance.id === evt.detail.sectionId;
    });

    if (!_.isUndefined(instance) && _.isFunction(instance.onBlockDeselect)) {
      instance.onBlockDeselect(evt);
    }
  },

  register: function(type, constructor) {
    this.constructors[type] = constructor;

    $('[data-section-type=' + type + ']').each(
      function(index, container) {
        this._createInstance(container, constructor);
      }.bind(this)
    );
  }
});

window.slate = window.slate || {};

/**
 * Slate utilities
 * -----------------------------------------------------------------------------
 * A collection of useful utilities to help build your theme
 *
 *
 * @namespace utils
 */

slate.utils = {
  /**
   * Get the query params in a Url
   * Ex
   * https://mysite.com/search?q=noodles&b
   * getParameterByName('q') = "noodles"
   * getParameterByName('b') = "" (empty value)
   * getParameterByName('test') = null (absent)
   */
  getParameterByName: function(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
      results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  },

  keyboardKeys: {
    TAB: 9,
    ENTER: 13,
    ESCAPE: 27,
    LEFTARROW: 37,
    RIGHTARROW: 39
  }
};

window.slate = window.slate || {};

/**
 * iFrames
 * -----------------------------------------------------------------------------
 * Wrap videos in div to force responsive layout.
 *
 * @namespace iframes
 */

slate.rte = {
  /**
   * Wrap tables in a container div to make them scrollable when needed
   *
   * @param {object} options - Options to be used
   * @param {jquery} options.$tables - jquery object(s) of the table(s) to wrap
   * @param {string} options.tableWrapperClass - table wrapper class name
   */
  wrapTable: function(options) {
    options.$tables.wrap(
      '<div class="' + options.tableWrapperClass + '"></div>'
    );
  },

  /**
   * Wrap iframes in a container div to make them responsive
   *
   * @param {object} options - Options to be used
   * @param {jquery} options.$iframes - jquery object(s) of the iframe(s) to wrap
   * @param {string} options.iframeWrapperClass - class name used on the wrapping div
   */
  wrapIframe: function(options) {
    options.$iframes.each(function() {
      // Add wrapper to make video responsive
      $(this).wrap('<div class="' + options.iframeWrapperClass + '"></div>');

      // Re-set the src attribute on each iframe after page load
      // for Chrome's "incorrect iFrame content on 'back'" bug.
      // https://code.google.com/p/chromium/issues/detail?id=395791
      // Need to specifically target video and admin bar
      this.src = this.src;
    });
  }
};

window.slate = window.slate || {};

/**
 * A11y Helpers
 * -----------------------------------------------------------------------------
 * A collection of useful functions that help make your theme more accessible
 * to users with visual impairments.
 *
 *
 * @namespace a11y
 */

slate.a11y = {
  /**
   * For use when focus shifts to a container rather than a link
   * eg for In-page links, after scroll, focus shifts to content area so that
   * next `tab` is where user expects if focusing a link, just $link.focus();
   *
   * @param {JQuery} $element - The element to be acted upon
   */
  pageLinkFocus: function($element) {
    var focusClass = 'js-focus-hidden';

    $element
      .first()
      .attr('tabIndex', '-1')
      .focus()
      .addClass(focusClass)
      .one('blur', callback);

    function callback() {
      $element
        .first()
        .removeClass(focusClass)
        .removeAttr('tabindex');
    }
  },

  /**
   * If there's a hash in the url, focus the appropriate element
   */
  focusHash: function() {
    var hash = window.location.hash;

    // is there a hash in the url? is it an element on the page?
    if (hash && document.getElementById(hash.slice(1))) {
      this.pageLinkFocus($(hash));
    }
  },

  /**
   * When an in-page (url w/hash) link is clicked, focus the appropriate element
   */
  bindInPageLinks: function() {
    $('a[href*=#]').on(
      'click',
      function(evt) {
        this.pageLinkFocus($(evt.currentTarget.hash));
      }.bind(this)
    );
  },

  /**
   * Traps the focus in a particular container
   *
   * @param {object} options - Options to be used
   * @param {jQuery} options.$container - Container to trap focus within
   * @param {jQuery} options.$elementToFocus - Element to be focused when focus leaves container
   * @param {string} options.namespace - Namespace used for new focus event handler
   */
  trapFocus: function(options) {
    var eventsName = {
      focusin: options.namespace ? 'focusin.' + options.namespace : 'focusin',
      focusout: options.namespace
        ? 'focusout.' + options.namespace
        : 'focusout',
      keydown: options.namespace
        ? 'keydown.' + options.namespace
        : 'keydown.handleFocus'
    };

    /**
     * Get every possible visible focusable element
     */
    var $focusableElements = options.$container.find(
      $(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex^="-"])'
      ).filter(':visible')
    );
    var firstFocusable = $focusableElements[0];
    var lastFocusable = $focusableElements[$focusableElements.length - 1];

    if (!options.$elementToFocus) {
      options.$elementToFocus = options.$container;
    }

    function _manageFocus(evt) {
      if (evt.keyCode !== slate.utils.keyboardKeys.TAB) return;

      /**
       * On the last focusable element and tab forward,
       * focus the first element.
       */
      if (evt.target === lastFocusable && !evt.shiftKey) {
        evt.preventDefault();
        firstFocusable.focus();
      }
      /**
       * On the first focusable element and tab backward,
       * focus the last element.
       */
      if (evt.target === firstFocusable && evt.shiftKey) {
        evt.preventDefault();
        lastFocusable.focus();
      }
    }

    options.$container.attr('tabindex', '-1');
    options.$elementToFocus.focus();

    $(document).off('focusin');

    $(document).on(eventsName.focusout, function() {
      $(document).off(eventsName.keydown);
    });

    $(document).on(eventsName.focusin, function(evt) {
      if (evt.target !== lastFocusable && evt.target !== firstFocusable) return;

      $(document).on(eventsName.keydown, function(evt) {
        _manageFocus(evt);
      });
    });
  },

  /**
   * Removes the trap of focus in a particular container
   *
   * @param {object} options - Options to be used
   * @param {jQuery} options.$container - Container to trap focus within
   * @param {string} options.namespace - Namespace used for new focus event handler
   */
  removeTrapFocus: function(options) {
    var eventName = options.namespace
      ? 'focusin.' + options.namespace
      : 'focusin';

    if (options.$container && options.$container.length) {
      options.$container.removeAttr('tabindex');
    }

    $(document).off(eventName);
  },

  /**
   * Add aria-describedby attribute to external and new window links
   *
   * @param {object} options - Options to be used
   * @param {object} options.messages - Custom messages to be used
   * @param {jQuery} options.$links - Specific links to be targeted
   */
  accessibleLinks: function(options) {
    var body = document.querySelector('body');

    var idSelectors = {
      newWindow: 'a11y-new-window-message',
      external: 'a11y-external-message',
      newWindowExternal: 'a11y-new-window-external-message'
    };

    if (options.$links === undefined || !options.$links.jquery) {
      options.$links = $('a[href]:not([aria-describedby])');
    }

    function generateHTML(customMessages) {
      if (typeof customMessages !== 'object') {
        customMessages = {};
      }

      var messages = $.extend(
        {
          newWindow: 'Opens in a new window.',
          external: 'Opens external website.',
          newWindowExternal: 'Opens external website in a new window.'
        },
        customMessages
      );

      var container = document.createElement('ul');
      var htmlMessages = '';

      for (var message in messages) {
        htmlMessages +=
          '<li id=' + idSelectors[message] + '>' + messages[message] + '</li>';
      }

      container.setAttribute('hidden', true);
      container.innerHTML = htmlMessages;

      body.appendChild(container);
    }

    function _externalSite($link) {
      var hostname = window.location.hostname;

      return $link[0].hostname !== hostname;
    }

    $.each(options.$links, function() {
      var $link = $(this);
      var target = $link.attr('target');
      var rel = $link.attr('rel');
      var isExternal = _externalSite($link);
      var isTargetBlank = target === '_blank';

      if (isExternal) {
        $link.attr('aria-describedby', idSelectors.external);
      }
      if (isTargetBlank) {
        if (rel === undefined || rel.indexOf('noopener') === -1) {
          $link.attr('rel', function(i, val) {
            var relValue = val === undefined ? '' : val + ' ';
            return relValue + 'noopener';
          });
        }
        $link.attr('aria-describedby', idSelectors.newWindow);
      }
      if (isExternal && isTargetBlank) {
        $link.attr('aria-describedby', idSelectors.newWindowExternal);
      }
    });

    generateHTML(options.messages);
  }
};

/**
 * Image Helper Functions
 * -----------------------------------------------------------------------------
 * A collection of functions that help with basic image operations.
 *
 */

theme.Images = (function() {
  /**
   * Preloads an image in memory and uses the browsers cache to store it until needed.
   *
   * @param {Array} images - A list of image urls
   * @param {String} size - A shopify image size attribute
   */

  function preload(images, size) {
    if (typeof images === 'string') {
      images = [images];
    }

    for (var i = 0; i < images.length; i++) {
      var image = images[i];
      this.loadImage(this.getSizedImageUrl(image, size));
    }
  }

  /**
   * Loads and caches an image in the browsers cache.
   * @param {string} path - An image url
   */
  function loadImage(path) {
    new Image().src = path;
  }

  /**
   * Swaps the src of an image for another OR returns the imageURL to the callback function
   * @param image
   * @param element
   * @param callback
   */
  function switchImage(image, element, callback) {
    var size = this.imageSize(element.src);
    var imageUrl = this.getSizedImageUrl(image.src, size);

    if (callback) {
      callback(imageUrl, image, element); // eslint-disable-line callback-return
    } else {
      element.src = imageUrl;
    }
  }

  /**
   * +++ Useful
   * Find the Shopify image attribute size
   *
   * @param {string} src
   * @returns {null}
   */
  function imageSize(src) {
    var match = src.match(
      /.+_((?:pico|icon|thumb|small|compact|medium|large|grande)|\d{1,4}x\d{0,4}|x\d{1,4})[_\\.@]/
    );

    if (match !== null) {
      if (match[2] !== undefined) {
        return match[1] + match[2];
      } else {
        return match[1];
      }
    } else {
      return null;
    }
  }

  /**
   * +++ Useful
   * Adds a Shopify size attribute to a URL
   *
   * @param src
   * @param size
   * @returns {*}
   */
  function getSizedImageUrl(src, size) {
    if (size === null) {
      return src;
    }

    if (size === 'master') {
      return this.removeProtocol(src);
    }

    var match = src.match(
      /\.(jpg|jpeg|gif|png|bmp|bitmap|tiff|tif)(\?v=\d+)?$/i
    );

    if (match !== null) {
      var prefix = src.split(match[0]);
      var suffix = match[0];

      return this.removeProtocol(prefix[0] + '_' + size + suffix);
    }

    return null;
  }

  function removeProtocol(path) {
    return path.replace(/http(s)?:/, '');
  }

  return {
    preload: preload,
    loadImage: loadImage,
    switchImage: switchImage,
    imageSize: imageSize,
    getSizedImageUrl: getSizedImageUrl,
    removeProtocol: removeProtocol
  };
})();

/**
 * Currency Helpers
 * -----------------------------------------------------------------------------
 * A collection of useful functions that help with currency formatting
 *
 * Current contents
 * - formatMoney - Takes an amount in cents and returns it as a formatted dollar value.
 *
 * Alternatives
 * - Accounting.js - http://openexchangerates.github.io/accounting.js/
 *
 */

theme.Currency = (function() {
  var moneyFormat = money_with_currency_format;//'${{amount}}'; // eslint-disable-line camelcase

  function formatMoney(cents, format) {
    if (typeof cents === 'string') {
      cents = cents.replace('.', '');
    }
    var value = '';
    var placeholderRegex = /\{\{\s*(\w+)\s*\}\}/;
    var formatString = format != "NO_CURRENCY" ? moneyFormat : "${{amount}}";//format || moneyFormat;

    function formatWithDelimiters(number, precision, thousands, decimal) {
      thousands = thousands || ',';
      decimal = decimal || '.';

      if (isNaN(number) || number === null) {
        return 0;
      }

      number = (number / 100.0).toFixed(precision);

      var parts = number.split('.');
      var dollarsAmount = parts[0].replace(
        /(\d)(?=(\d\d\d)+(?!\d))/g,
        '$1' + thousands
      );
      var centsAmount = parts[1] ? decimal + parts[1] : '';

      return centsAmount == ".00" ? dollarsAmount : dollarsAmount + centsAmount;
    }

    switch (formatString.match(placeholderRegex)[1]) {
      case 'amount':
        value = formatWithDelimiters(cents, 2);
        break;
      case 'amount_no_decimals':
        value = formatWithDelimiters(cents, 0);
        break;
      case 'amount_with_comma_separator':
        value = formatWithDelimiters(cents, 2, '.', ',');
        break;
      case 'amount_no_decimals_with_comma_separator':
        value = formatWithDelimiters(cents, 0, '.', ',');
        break;
      case 'amount_no_decimals_with_space_separator':
        value = formatWithDelimiters(cents, 0, ' ');
        break;
      case 'amount_with_apostrophe_separator':
        value = formatWithDelimiters(cents, 2, "'");
        break;
    }

    return formatString.replace(placeholderRegex, value);
  }

  return {
    formatMoney: formatMoney
  };
})();

/**
 * Variant Selection scripts
 * ------------------------------------------------------------------------------
 *
 * Handles change events from the variant inputs in any `cart/add` forms that may
 * exist.  Also updates the master select and triggers updates when the variants
 * price or image changes.
 *
 * @namespace variants
 */

slate.Variants = (function() {
  /**
   * Variant constructor
   *
   * @param {object} options - Settings from `product.js`
   */
  function Variants(options) {
    this.$container = options.$container;
    this.product = options.product;
    this.singleOptionSelector = options.singleOptionSelector;
    this.originalSelectorId = options.originalSelectorId;
    this.enableHistoryState = options.enableHistoryState;
    this.currentVariant = this._getVariantFromOptions();

    $(this.singleOptionSelector, this.$container).on(
      'change',
      this._onSelectChange.bind(this)
    );

    $($('.color-list input:radio'), this.$container).on(
      'change',
      this._onColorChange.bind(this)
    );

     $($('.product-sizes-watch'), this.$container).on(
      'change',
      this._onColorChange.bind(this)
    );
    $($('#Amount'), this.$container).on(
      'change',
      this._onAmountChange.bind(this)
    );
           $($('.product-sizes-protector'), this.$container).on(
      'change',
        this._onSelectChangeNew.bind(this)
    );
  }

  Variants.prototype = _.assignIn({}, Variants.prototype, {
    /**
     * Get the currently selected options from add-to-cart form. Works with all
     * form input elements.
     *
     * @return {array} options - Values of currently selected variants
     */
    _getCurrentOptions: function() {
      var currentOptions = _.map(
        $(this.singleOptionSelector, this.$container),
        function(element) {
          var $element = $(element);
          var type = $element.attr('type');
          var currentOption = {};

          if (type === 'radio' || type === 'checkbox') {
            if ($element[0].checked) {
              currentOption.value = $element.val();
              currentOption.index = $element.data('index');

              return currentOption;
            } else {
              return false;
            }
          } else {
            currentOption.value = $element.val();
            currentOption.index = $element.data('index');

            return currentOption;
          }
        }
      );

      // remove any unchecked input values if using radio buttons or checkboxes
      currentOptions = _.compact(currentOptions);

      return currentOptions;
    },

    /**
     * Find variant based on selected values.
     *
     * @param  {array} selectedValues - Values of variant inputs
     * @return {object || undefined} found - Variant object from product.variants
     */
    _getVariantFromOptions: function() {
      var selectedValues = this._getCurrentOptions();
      var variants = this.product.variants;

      var found = _.find(variants, function(variant) {
        return selectedValues.every(function(values) {
          return _.isEqual(variant[values.index], values.value);
        });
      });

      return found;
    },

    /**
     * Event handler for when a variant input changes.
     */
    _onSelectChange: function() {
      var variant = this._getVariantFromOptions();

      this.$container.trigger({
        type: 'variantChange',
        variant: variant
      });

      if (!variant) {
        return;
      }

      this._updateMasterSelect(variant);
      this._updateTitle(variant);
      this._updateImages(variant);
      this._updatePrice(variant);
      this._updateSKU(variant);
      this.currentVariant = variant;

      if (this.enableHistoryState) {
        this._updateHistoryState(variant);
      }

    },
     _onSelectChangeNew: function() {
      var product = this.product;
      var variants = product.variants;
      var variant = variants[0];
        var selected = $('#size_select_desk').val();
      if(window.matchMedia('(max-width:991px)').matches) {
        selected = $('#size_select_mob').val();
      }
            for (let i = 0; i < variants.length; i++) {
       if(variants[i].option1 == selected) {
        variant = variants[i];
       }
       }
      this.$container.trigger({
        type: 'variantChange',
        variant: variant
      });

      if (!variant) {
        return;
      }

     this._updateMasterSelect(variant);
     this._updateTitle(variant);
     this._updateImages(variant);
     this._updatePrice(variant);
     this._updateSKU(variant);
     this.currentVariant = variant;
    },


    /**
     * Event handler for when a variant input changes.
     */
    _onColorChange: function() {
      var product = this.product;
      var variants = product.variants;
      var variant = variants[0];
      var tag_mym = $('.product-page-tag .saled_img');
      var tag_le = $('.product-page-tag .mds_le');
      var tag_le_b = $('.product-page-tag .mds_le_b');
 	  var is_le = false;
      var tag_disney = $('.product-page-tag .disney_tag');

let pdp_badge = $('.product-page-tag .pdp_badge');
    
      var is_mym = false;
       var is_olym = false;
      var is_coral_blue = false;
       var is_disney = false;
var selector  = '.hide-mobile .product-sizes-watch';
      if(window.matchMedia('(max-width:991px)').matches) {
        selector = '.hide-desktop .product-sizes-watch';
      }
      var selected_size = $(selector).val();
      // CUSTOMIZER
      var selected = document.querySelector('.color-list-product-template input[type="radio"]:checked , .color-list-product-template-bundles input[type="radio"]:checked, .color-list-product-template-holiday input[type="radio"]:checked,.color-list-product-template-jelli input[type="radio"]:checked');
      for (let i = 0; i < variants.length; i++) {
        if(product.type.includes('Watch')) {
          let v_name = '.'+variants[i].option2.replace(/\W+/g, "-").toLowerCase();

          if(variants[i].option1 == selected_size && !variants[i].available) {
          		 $('.color-option '+v_name).addClass('sold-out');
          }
         else if(variants[i].option1 == selected_size && variants[i].available) {
           $('.color-option '+v_name).removeClass('sold-out');
          }
            if(variants[i].option2 == selected.value && variants[i].option1 == selected_size ) {
               variant = variants[i];
          }
        }
        else {
          if(variants[i].option1 == selected.value) {
            variant = variants[i];
          }
        }
      }
      if( (typeof pdp_badge_name != "undefined") && pdp_badge_name == variant.title) {
        $(pdp_badge).removeClass('hide');
      }
      else {
        $(pdp_badge).addClass('hide');
      }
       if(variant.title.includes('Olympic')) {
         is_olym = true;
         is_le = true;
      }
       if(variant.title.includes('Coral Blue')) {
         is_coral_blue = false;
      }
      if(variant.title.includes('MYM')) {
         is_mym = true;
        is_le = true;
      }
      if(variant.title.includes('Orange') || variant.title.includes('Violet') || variant.title.includes('White') || variant.title.includes('Bondi') || variant.title.includes('Fuchsia') || variant.title.includes('Lavender') ) {
         is_le = true;
       }
      if(variant.title.includes('Pluto') || variant.title.includes('Donald') || variant.title.includes('Daisy') || variant.title.includes('Mickey') || variant.title.includes('Minnie') || variant.title.includes('Goofy') ) {
         $(tag_disney).removeClass('hide');
        $('.disney-order-text').removeClass('hide');
        is_disney = true;


       // $('[data-ships-normal]').text('Ships from end of February, 2022');
        $('.sale_img').addClass('hide');

       }
      else{
             //    $('[data-ships-normal]').text('Ships in 5-8 business days');
       
       $(tag_disney).addClass('hide');
        $('.disney-order-text').addClass('hide');
        is_disney = false;
        $('.sale_img').removeClass('hide');
      }
       metafieldCta(variant);


       customizer.change.variant(variant.title);
      // .CUSTOMIZER
      // Stores the color handle
      let colorHandle = variant.title.replace(')', "").replace(/\W+/g, "-").toLowerCase();
            colorHandle.includes('ombr')? colorHandle = colorHandle.replace('ombr','ombré') : colorHandle;

      localStorage.setItem('mdsColor', colorHandle);
      if(document.getElementsByClassName("lp-product-template").length<=0){
        if(this.product.type.includes('Watch')) {
          updateMatchingItems(this.product.type, variant.option2);
        }
        else {
        updateMatchingItems(this.product.type, variant.option1);
        }
   	 }
      if(document.getElementsByClassName("lp-product-template").length >0) {
       let variantTitle = variant.title;
       if(variantTitle.includes('Orange') || variantTitle.includes('Violet') || variantTitle.includes('White') || variantTitle.includes('Bondi') || variantTitle.includes('Fuchsia') || variantTitle.includes('Lavender')) {
       	$('.product-single__title label').removeClass('hide');
       }
      else {
      	$('.product-single__title label').addClass('hide');
      }
        $('.template-page-generic-landing .product-single__title-text, .template-page-mini-tote .product-single__title-text, .template-page-mcb .product-single__title-text, .template-page-mothers .product-single__title-text').text(variant.title);
      }

      if(document.getElementsByClassName("p-slider").length>0){
        filterSliders(colorHandle);
      }
      if(document.getElementsByClassName("product-left--desk").length>0) {
        filterimages(colorHandle);
      }
      initials.load();
      foil.load(false);

      customizer.load(false);
       jQuery('.zodiac-engrave').attr('class', 'zodiac-engrave');


       //  updateMatchingItems(this.product.type, variant.option1);
     var preorder = document.querySelector('#isPreorder');
     let is_preorder = false;
     if(preorder != null) {
        let variants = preorder.value.split(',');
        for(var i = 0; i < variants.length; i++) {
          let values = variants[i].split(':');
          if(values[0] == variant.id) {
            is_preorder = values[1] == "true";
          }
        }
      }
      if(is_preorder) {
			//checkEta(variant.title,product);
      }
      
      if(document.getElementsByClassName("template-product-bundles").length >0) {
        var selected_color = $('.color-list input:checked').val();
        var select_size_1 = $('.bundles_size_1').children("option:selected").val();
        var index_1 = $(".product-1-color[data-variant='"+selected_color+"'][data-size='"+select_size_1+"']").data("index");
        var select_size_2 = $('.bundles_size_2').children("option:selected").val();
        var index_2 = $(".product-2-color[data-variant='"+selected_color+"'][data-size='"+select_size_2+"']").data("index");
        var variant_1_available = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("available");
        var variant_2_available = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("available");

        var variant_1_preorder = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("preorder");
        var variant_2_preorder = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("preorder");
        if($('.product-3-id').length > 0) {  
          var select_size_3 = $('.bundles_size_3').children("option:selected").val();

          var index_3 = $(".product-3-color[data-variant='"+selected_color+"'][data-size='"+select_size_3+"']").data("index");

          var variant_3_preorder = $(".product-3-id[data-index='"+index_3+"'][data-size='"+select_size_3+"']").data("preorder");

        }

  if(variant_1_preorder || variant_2_preorder || variant_3_preorder) {
         $('#bundles').addClass('hide');
          $('#bundles_1').removeClass('hide');
          $('#bundles_0').addClass('hide');
          $('.pre-order-text').removeClass('hide');
   }
   else {
    $('.pre-order-text').addClass('hide');
    if(!variant_1_available || !variant_2_available) {
          $('#bundles').addClass('hide');
          $('#bundles_0').removeClass('hide');
          $('#bundles_1').addClass('hide');
        }
        else {
                    $('#bundles_1').addClass('hide');

          $('#bundles_0').addClass('hide');
           $('#bundles').removeClass('hide');
        }
    }



      }

      // Update tags
      var tags = product.tags;
      
      var is_new = false;
      var is_best = false;
      var on_sale = false;
      var is_low = false;
      var is_high = false;
      var sale_text = '';

      var tag_new = $('.product-page-tag .tag-new');
      var tag_best = $('.product-page-tag .tag-best');
      var tag_sale = $('.product-page-tag .tag-sale');
      var stock_tag = $('.product-page-tag.stock');
	  var preorder = document.querySelector('#isPreorder');
      var stock_tag_red = $('.product-page-tag-red.stock');
      var compare_at_price = variant.compare_at_price;
      var price = variant.price;
  

      if(compare_at_price > price) {
        on_sale = true;

        let price_discount = price / compare_at_price;
        let percent_off = 1 - price_discount;
        sale_text = Math.round(percent_off * 100) + '% OFF';
        let price_saving = compare_at_price - price ;
        $('.earth_tag').addClass('hide');

        if(Math.round(percent_off*100)== 60) {
        	$('.earth_tag.60').removeClass('hide');
           
        }
         if(Math.round(percent_off*100) == 20) {
        	$('.earth_tag.20').removeClass('hide');
           
        }
         if(Math.round(percent_off*100)== 40) {
        	$('.earth_tag.40').removeClass('hide');
           
        }
         if(Math.round(percent_off*100)== 30) {
        	$('.earth_tag.30').removeClass('hide');
           
        }
         if(Math.round(percent_off*100)== 25) {
        	$('.earth_tag.50').removeClass('hide');
           
           
        }
        $('.savings span').removeClass('hide');
        $('.savings span').text('Save ' + theme.Currency.formatMoney(price_saving, theme.moneyFormat).replace('USD',''));
      }
      else {
       $('.savings span').addClass('hide');
         $('.earth_tag').addClass('hide');
      }

      for(let i = 0; i < tags.length; i++) {
        let tag = tags[i];

        if(tag == 'new' && !is_disney && !is_coral_blue) {
          is_new = false;
        }
        if(tag.indexOf('new:') != -1) {
          var handle = tag.replace('new: ', '').replace('new:', '').replace(/\W+/g, "-").toLowerCase();
          if(handle == colorHandle) {
            is_new = false;
          }
        }
        
		if( (!is_preorder)  && variant.available) {
          if(tag == 'stock_high') {
            is_high = true;
          }
          if(tag.indexOf('stock_low:') != -1) {
            var handle = tag.replace('stock_low: ', '').replace('stock_low:', '').replace(/\W+/g, "-").toLowerCase();
          if(handle == colorHandle || colorHandle.includes('ombré')) {
              is_low = true;
            }
          }
      	}
        if(variant.title.includes('Lavender')) {
          is_best = false;
        }
        if(tag.indexOf('best-seller:') != -1) {
          var handle = tag.replace('best-seller: ', '').replace('best-seller:', '').replace(/\W+/g, "-").toLowerCase();
          if(handle == colorHandle) {
            is_best = true;
          }
        }
      }
      if(is_le) {
        $(tag_le).removeClass('hide');
        $(tag_le_b).addClass('hide');

      } 
      else if(is_coral_blue) {
        $(tag_le_b).removeClass('hide');
        $(tag_le).addClass('hide');
      }
      else {
        $(tag_le).addClass('hide');
        $(tag_le_b).addClass('hide');
      }

      checkDisney(is_disney);

      if(is_new) {
     //   $(tag_new).removeClass('hide');
      } else {
        //$(tag_new).addClass('hide');
      }

      if(is_best) {
        $(tag_best).removeClass('hide');
      } else {
        $(tag_best).addClass('hide');
      }

      if(on_sale) {
        $(tag_sale).removeClass('hide');
        $(tag_sale).text(sale_text);
      } else {
        $(tag_sale).addClass('hide');
      }

      if(variant.available) {
        $(stock_tag_red).addClass('hide');
        if(is_low) {
          $(stock_tag).removeClass('hide');
          $('.stock-tag').addClass('yellow');
          $('.stock-tag').removeClass('green');
          $('.stock-text').text('Low Stock');
        } else if(is_high) {
          $(stock_tag).removeClass('hide');
          $('.stock-tag').addClass('green');
          $('.stock-tag').removeClass('yellow');
          $('.stock-text').text('In Stock');
        }
         else {
          $(stock_tag).addClass('hide');
        }
      }
      else {
       
          $(stock_tag).addClass('hide');
          $('.stock-text').text('Out of Stock');
          $(stock_tag_red).removeClass('hide');
      
        
      }

      $('.cp-image').addClass('hide');
      $('.cp-image.' + colorHandle).removeClass('hide');

      this.$container.trigger({
        type: 'variantChange',
        variant: variant
      });

      if (!variant) {
        return;
      }

      this._updateMasterSelect(variant);
      this._updateTitle(variant);
      this._updateImages(variant);
      this._updatePrice(variant);
      this._updateSKU(variant);
      this.currentVariant = variant;

      if (this.enableHistoryState) {
        this._updateHistoryState(variant);
      }
       if(document.getElementsByClassName("template-product-holiday").length != 0) {
        changeHolidayPrice();
      }
       if(document.getElementsByClassName("template-product-bundles").length != 0 && document.getElementsByClassName("template-product-holiday").length == 0 ){
	 		  changeBundlePrice();
      }
    },

    /**
     * Event handler for when a variant input changes.
     */
    _onAmountChange: function() {
      var product = this.product;
      var variants = product.variants;
      var i = document.querySelector('#Amount').selectedIndex - 1;
      var variant = variants[i];

      this.$container.trigger({
        type: 'variantChange',
        variant: variant
      });

      if (!variant) {
        return;
      }

      this._updateMasterSelect(variant);
      this._updateTitle(variant);
      this._updateImagesGift(variant);
      this._updatePrice(variant);
      this._updateSKU(variant);
      this.currentVariant = variant;

      if (this.enableHistoryState) {
        this._updateHistoryState(variant);
      }
    },

    /**
     * Trigger event when variant title changes.
     *
     * @param  {object} variant - Currently selected variant
     * @return {event} variantTitleChange
     */
    _updateTitle: function(variant) {
      if (
        variant.title === this.currentVariant.title
      ) {
        return;
      }

      this.$container.trigger({
        type: 'variantTitleChange',
        variant: variant
      });
    },

    /**
     * Trigger event when variant image changes
     *
     * @param  {object} variant - Currently selected variant
     * @return {event}  variantImageChange
     */
    _updateImages: function(variant) {
      var variantImage = variant.featured_image || {};
      var currentVariantImage = this.currentVariant.featured_image || {};

      if (
        !variant.featured_image ||
        variantImage.src === currentVariantImage.src
      ) {
        return;
      }

      this.$container.trigger({
        type: 'variantImageChange',
        variant: variant
      });
    },

    /**
     * Trigger event when variant price changes.
     *
     * @param  {object} variant - Currently selected variant
     * @return {event} variantPriceChange
     */
    _updatePrice: function(variant) {
      if (
        variant.price === this.currentVariant.price &&
        variant.compare_at_price === this.currentVariant.compare_at_price
      ) {
        return;
      }

      this.$container.trigger({
        type: 'variantPriceChange',
        variant: variant
      });
    },
  
    //gift card changes
   _updateImagesGift: function(variant) {
      if (
        variant.price === this.currentVariant.price &&
        variant.compare_at_price === this.currentVariant.compare_at_price
      ) {
        return;
      }
     
    },

    /**
     * Trigger event when variant sku changes.
     *
     * @param  {object} variant - Currently selected variant
     * @return {event} variantSKUChange
     */
    _updateSKU: function(variant) {
      if (variant.sku === this.currentVariant.sku) {
        return;
      }

      this.$container.trigger({
        type: 'variantSKUChange',
        variant: variant
      });
    },

    /**
     * Update history state for product deeplinking
     *
     * @param  {variant} variant - Currently selected variant
     * @return {k}         [description]
     */
    _updateHistoryState: function(variant) {
      if (!history.replaceState || !variant) {
        return;
      }

      var newurl =
        window.location.protocol +
        '//' +
        window.location.host +
        window.location.pathname +
        '?variant=' +
        variant.id;
      window.history.replaceState({ path: newurl }, '', newurl);
    },

    /**
     * Update hidden master select of variant change
     *
     * @param  {variant} variant - Currently selected variant
     */
    _updateMasterSelect: function(variant) {
      if(this.originalSelectorId == '#ProductSelect-product-template1' || this.originalSelectorId == '#ProductSelect-product-template2' ){
        this.originalSelectorId= '#ProductSelect-product-template';
      }
      $(this.originalSelectorId, this.$container).val(variant.id);
    }
  });

  return Variants;
})();


/* ================ GLOBAL ================ */
/*============================================================================
  Drawer modules
==============================================================================*/
theme.Drawers = (function() {
  function Drawer(id, position, options) {
    var defaults = {
      close: '.js-drawer-close',
      open: '.js-drawer-open-' + position,
      openClass: 'js-drawer-open',
      dirOpenClass: 'js-drawer-open-' + position
    };

    this.nodes = {
      $parent: $('html').add('body'),
      $page: $('#PageContainer')
    };

    this.config = $.extend(defaults, options);
    this.position = position;

    this.$drawer = $('#' + id);

    if (!this.$drawer.length) {
      return false;
    }

    this.drawerIsOpen = false;
    this.init();
  }

  Drawer.prototype.init = function() {
    $(this.config.open).on('click', $.proxy(this.open, this));
    this.$drawer.on('click', this.config.close, $.proxy(this.close, this));
  };

  Drawer.prototype.open = function(evt) {
    // Keep track if drawer was opened from a click, or called by another function
    var externalCall = false;

    // Prevent following href if link is clicked
    if (evt) {
      evt.preventDefault();
    } else {
      externalCall = true;
    }

    // Without this, the drawer opens, the click event bubbles up to nodes.$page
    // which closes the drawer.
    if (evt && evt.stopPropagation) {
      evt.stopPropagation();
      // save the source of the click, we'll focus to this on close
      this.$activeSource = $(evt.currentTarget);
    }

    if (this.drawerIsOpen && !externalCall) {
      return this.close();
    }

    // Add is-transitioning class to moved elements on open so drawer can have
    // transition for close animation
    this.$drawer.prepareTransition();

    this.nodes.$parent.addClass(
      this.config.openClass + ' ' + this.config.dirOpenClass
    );
    this.drawerIsOpen = true;

    // Set focus on drawer
    slate.a11y.trapFocus({
      $container: this.$drawer,
      namespace: 'drawer_focus'
    });

    // Run function when draw opens if set
    if (
      this.config.onDrawerOpen &&
      typeof this.config.onDrawerOpen === 'function'
    ) {
      if (!externalCall) {
        this.config.onDrawerOpen();
      }
    }

    if (this.$activeSource && this.$activeSource.attr('aria-expanded')) {
      this.$activeSource.attr('aria-expanded', 'true');
    }

    this.bindEvents();

    return this;
  };

  Drawer.prototype.close = function() {
    if (!this.drawerIsOpen) {
      // don't close a closed drawer
      return;
    }

    // deselect any focused form elements
    $(document.activeElement).trigger('blur');

    // Ensure closing transition is applied to moved elements, like the nav
    this.$drawer.prepareTransition();

    this.nodes.$parent.removeClass(
      this.config.dirOpenClass + ' ' + this.config.openClass
    );

    if (this.$activeSource && this.$activeSource.attr('aria-expanded')) {
      this.$activeSource.attr('aria-expanded', 'false');
    }

    this.drawerIsOpen = false;

    // Remove focus on drawer
    slate.a11y.removeTrapFocus({
      $container: this.$drawer,
      namespace: 'drawer_focus'
    });

    this.unbindEvents();

    // Run function when draw closes if set
    if (
      this.config.onDrawerClose &&
      typeof this.config.onDrawerClose === 'function'
    ) {
      this.config.onDrawerClose();
    }
  };

  Drawer.prototype.bindEvents = function() {
    this.nodes.$parent.on(
      'keyup.drawer',
      $.proxy(function(evt) {
        // close on 'esc' keypress
        if (evt.keyCode === 27) {
          this.close();
          return false;
        } else {
          return true;
        }
      }, this)
    );

    // Lock scrolling on mobile
    this.nodes.$page.on('touchmove.drawer', function() {
      return false;
    });

    this.nodes.$page.on(
      'click.drawer',
      $.proxy(function() {
        this.close();
        return false;
      }, this)
    );
  };

  Drawer.prototype.unbindEvents = function() {
    this.nodes.$page.off('.drawer');
    this.nodes.$parent.off('.drawer');
  };

  return Drawer;
})();


/* ================ MODULES ================ */
theme.Search = (function() {
  var selectors = {
    search: '.search',
    searchSubmit: '.search__submit',
    searchInput: '.search__input',

    siteHeader: '.site-header',
    siteHeaderSearchToggle: '.site-header__search-toggle',
    siteHeaderSearch: '.site-header__search',

    searchDrawer: '.search-bar',
    searchDrawerInput: '.search-bar__input',

    searchHeader: '.search-header',
    searchHeaderInput: '.search-header__input',
    searchHeaderSubmit: '.search-header__submit',

    searchResultSubmit: '#SearchResultSubmit',
    searchResultInput: '#SearchInput',
    searchResultMessage: '[data-search-error-message]',

    mobileNavWrapper: '.mobile-nav-wrapper'
  };

  var classes = {
    focus: 'search--focus',
    hidden: 'hide',
    mobileNavIsOpen: 'js-menu--is-open',
    searchTemplate: 'template-search'
  };

  function init() {
    if (!$(selectors.siteHeader).length) {
      return;
    }

    this.$searchResultInput = $(selectors.searchResultInput);
    this.$searchErrorMessage = $(selectors.searchResultMessage);

    initDrawer();

    var isSearchPage =
      slate.utils.getParameterByName('q') !== null &&
      $('body').hasClass(classes.searchTemplate);

    if (isSearchPage) {
      validateSearchResultForm.call(this);
    }

    $(selectors.searchResultSubmit).on(
      'click',
      validateSearchResultForm.bind(this)
    );

    $(selectors.searchHeaderInput)
      .add(selectors.searchHeaderSubmit)
      .on('focus blur', function() {
        $(selectors.searchHeader).toggleClass(classes.focus);
      });

    $(selectors.siteHeaderSearchToggle).on('click', function() {
      var searchHeight = $(selectors.siteHeader).outerHeight();
      var searchOffset = $(selectors.siteHeader).offset().top - searchHeight;

      $(selectors.searchDrawer).css({
        height: searchHeight + 'px',
        top: searchOffset + 'px'
      });
    });
  }

  function initDrawer() {
    // Add required classes to HTML
    $('#PageContainer').addClass('drawer-page-content');
    $('.js-drawer-open-top')
      .attr('aria-controls', 'SearchDrawer')
      .attr('aria-expanded', 'false')
      .attr('aria-haspopup', 'dialog');

    theme.SearchDrawer = new theme.Drawers('SearchDrawer', 'top', {
      onDrawerOpen: searchDrawerFocus,
      onDrawerClose: searchDrawerFocusClose
    });
  }

  function searchDrawerFocus() {
    searchFocus($(selectors.searchDrawerInput));

    if ($(selectors.mobileNavWrapper).hasClass(classes.mobileNavIsOpen)) {
      theme.MobileNav.closeMobileNav();
    }
  }

  function searchFocus($el) {
    $el.focus();
    // set selection range hack for iOS
    $el[0].setSelectionRange(0, $el[0].value.length);
  }

  function searchDrawerFocusClose() {
    $(selectors.siteHeaderSearchToggle).focus();
  }

  /**
   * Remove the aria-attributes and hide the error messages
   */
  function hideErrorMessage() {
    this.$searchErrorMessage.addClass(classes.hidden);
    this.$searchResultInput
      .removeAttr('aria-describedby')
      .removeAttr('aria-invalid');
  }

  /**
   * Add the aria-attributes and show the error messages
   */
  function showErrorMessage() {
    this.$searchErrorMessage.removeClass(classes.hidden);
    this.$searchResultInput
      .attr('aria-describedby', 'error-search-form')
      .attr('aria-invalid', true);
  }

  function validateSearchResultForm(evt) {
    var isInputValueEmpty = this.$searchResultInput.val().trim().length === 0;

    if (!isInputValueEmpty) {
      hideErrorMessage.call(this);
      return;
    }

    if (typeof evt !== 'undefined') {
      evt.preventDefault();
    }

    searchFocus(this.$searchResultInput);
    showErrorMessage.call(this);
  }

  return {
    init: init
  };
})();

(function() {
  var selectors = {
    backButton: '.return-link'
  };

  var $backButton = $(selectors.backButton);

  if (!document.referrer || !$backButton.length || !window.history.length) {
    return;
  }

  $backButton.one('click', function(evt) {
    evt.preventDefault();

    var referrerDomain = urlDomain(document.referrer);
    var shopDomain = urlDomain(window.location.href);

    if (shopDomain === referrerDomain) {
      history.back();
    }

    return false;
  });

  function urlDomain(url) {
    var anchor = document.createElement('a');
    anchor.ref = url;

    return anchor.hostname;
  }
})();

theme.Slideshow = (function() {
  this.$slideshow = null;
  var classes = {
    slideshow: 'slideshow',
    slickActiveMobile: 'slick-active-mobile',
    controlsHover: 'slideshow__controls--hover',
    isPaused: 'is-paused'
  };

  var selectors = {
    section: '.shopify-section',
    wrapper: '#SlideshowWrapper-',
    slides: '.slideshow__slide',
    textWrapperMobile: '.slideshow__text-wrap--mobile',
    textContentMobile: '.slideshow__text-content--mobile',
    controls: '.slideshow__controls',
    pauseButton: '.slideshow__pause',
    dots: '.slick-dots',
    arrows: '.slideshow__arrows',
    arrowsMobile: '.slideshow__arrows--mobile',
    arrowLeft: '.slideshow__arrow-left',
    arrowRight: '.slideshow__arrow-right'
  };

  function slideshow(el, sectionId) {
    var $slideshow = (this.$slideshow = $(el));
    this.adaptHeight = this.$slideshow.data('adapt-height');
    this.$wrapper = this.$slideshow.closest(selectors.wrapper + sectionId);
    this.$section = this.$wrapper.closest(selectors.section);
    this.$controls = this.$wrapper.find(selectors.controls);
    this.$arrows = this.$section.find(selectors.arrows);
    this.$arrowsMobile = this.$section.find(selectors.arrowsMobile);
    this.$pause = this.$controls.find(selectors.pauseButton);
    this.$textWrapperMobile = this.$section.find(selectors.textWrapperMobile);
    this.autorotate = this.$slideshow.data('autorotate');
    var autoplaySpeed = this.$slideshow.data('speed');
    var loadSlideA11yString = this.$slideshow.data('slide-nav-a11y');

    this.settings = {
      accessibility: true,
      arrows: false,
      dots: true,
      fade: true,
      draggable: true,
      touchThreshold: 20,
      autoplay: this.autorotate,
      autoplaySpeed: autoplaySpeed,
      // eslint-disable-next-line shopify/jquery-dollar-sign-reference
      appendDots: this.$arrows,
      customPaging: function(slick, index) {
        return (
          '<a href="' +
          selectors.wrapper +
          sectionId +
          '" aria-label="' +
          loadSlideA11yString.replace('[slide_number]', index + 1) +
          '" data-slide-number="' +
          index +
          '"></a>'
        );
      }
    };

    this.$slideshow.on('beforeChange', beforeChange.bind(this));
    this.$slideshow.on('init', slideshowA11ySetup.bind(this));

    // Add class to style mobile dots & show the correct text content for the
    // first slide on mobile when the slideshow initialises
    this.$slideshow.on(
      'init',
      function() {
        this.$mobileDots
          .find('li:first-of-type')
          .addClass(classes.slickActiveMobile);
        this.showMobileText(0);
      }.bind(this)
    );

    // Stop the autorotate when you scroll past the mobile controls, resume when
    // they are scrolled back into view
    if (this.autorotate) {
      $(document).scroll(
        $.debounce(
          250,
          function() {
            if (
              this.$arrowsMobile.offset().top +
                this.$arrowsMobile.outerHeight() <
              window.pageYOffset
            ) {
              $slideshow.slick('slickPause');
            } else if (!this.$pause.hasClass(classes.isPaused)) {
              $slideshow.slick('slickPlay');
            }
          }.bind(this)
        )
      );
    }

    if (this.adaptHeight) {
      this.setSlideshowHeight();
      $(window).resize($.debounce(50, this.setSlideshowHeight.bind(this)));
    }

    this.$slideshow.slick(this.settings);

    // This can't be called when the slick 'init' event fires due to how slick
    // adds a11y features.
    slideshowPostInitA11ySetup.bind(this)();

    this.$arrows.find(selectors.arrowLeft).on('click', function() {
      $slideshow.slick('slickPrev');
    });
    this.$arrows.find(selectors.arrowRight).on('click', function() {
      $slideshow.slick('slickNext');
    });

    this.$pause.on('click', this.togglePause.bind(this));
  }

  function slideshowA11ySetup(event, obj) {
    var $slider = obj.$slider;
    var $list = obj.$list;
    this.$dots = this.$section.find(selectors.dots);
    this.$mobileDots = this.$dots.eq(1);

    // Remove default Slick aria-live attr until slider is focused
    $list.removeAttr('aria-live');

    this.$wrapper.on('keyup', keyboardNavigation.bind(this));
    this.$controls.on('keyup', keyboardNavigation.bind(this));
    this.$textWrapperMobile.on('keyup', keyboardNavigation.bind(this));

    // When an element in the slider is focused
    // pause slideshow and set aria-live.
    this.$wrapper
      .on(
        'focusin',
        function(evt) {
          if (!this.$wrapper.has(evt.target).length) {
            return;
          }

          $list.attr('aria-live', 'polite');
          if (this.autorotate) {
            $slider.slick('slickPause');
          }
        }.bind(this)
      )
      .on(
        'focusout',
        function(evt) {
          if (!this.$wrapper.has(evt.target).length) {
            return;
          }

          $list.removeAttr('aria-live');
          if (this.autorotate) {
            // Only resume playing if the user hasn't paused using the pause
            // button
            if (!this.$pause.is('.is-paused')) {
              $slider.slick('slickPlay');
            }
          }
        }.bind(this)
      );

    // Add arrow key support when focused
    if (this.$dots) {
      this.$dots
        .find('a')
        .each(function() {
          var $dot = $(this);
          $dot.on('click keyup', function(evt) {
            if (
              evt.type === 'keyup' &&
              evt.which !== slate.utils.keyboardKeys.ENTER
            )
              return;

            evt.preventDefault();

            var slideNumber = $(evt.target).data('slide-number');

            $slider.attr('tabindex', -1).slick('slickGoTo', slideNumber);

            if (evt.type === 'keyup') {
              $slider.focus();
            }
          });
        })
        .eq(0)
        .attr('aria-current', 'true');
    }

    this.$controls
      .on('focusin', highlightControls.bind(this))
      .on('focusout', unhighlightControls.bind(this));
  }

  function slideshowPostInitA11ySetup() {
    var $slides = this.$slideshow.find(selectors.slides);

    $slides.removeAttr('role').removeAttr('aria-labelledby');
    this.$dots
      .removeAttr('role')
      .find('li')
      .removeAttr('role')
      .removeAttr('aria-selected')
      .each(function() {
        var $dot = $(this);
        var ariaControls = $dot.attr('aria-controls');
        $dot
          .removeAttr('aria-controls')
          .find('a')
          .attr('aria-controls', ariaControls);
      });
  }

  function beforeChange(event, slick, currentSlide, nextSlide) {
    var $dotLinks = this.$dots.find('a');
    var $mobileDotLinks = this.$mobileDots.find('li');

    $dotLinks
      .removeAttr('aria-current')
      .eq(nextSlide)
      .attr('aria-current', 'true');

    $mobileDotLinks
      .removeClass(classes.slickActiveMobile)
      .eq(nextSlide)
      .addClass(classes.slickActiveMobile);
    this.showMobileText(nextSlide);
  }

  function keyboardNavigation() {
    if (event.keyCode === slate.utils.keyboardKeys.LEFTARROW) {
      this.$slideshow.slick('slickPrev');
    }
    if (event.keyCode === slate.utils.keyboardKeys.RIGHTARROW) {
      this.$slideshow.slick('slickNext');
    }
  }

  function highlightControls() {
    this.$controls.addClass(classes.controlsHover);
  }

  function unhighlightControls() {
    this.$controls.removeClass(classes.controlsHover);
  }

  slideshow.prototype.togglePause = function() {
    var slideshowSelector = getSlideshowId(this.$pause);
    if (this.$pause.hasClass(classes.isPaused)) {
      this.$pause.removeClass(classes.isPaused).attr('aria-pressed', 'false');
      if (this.autorotate) {
        $(slideshowSelector).slick('slickPlay');
      }
    } else {
      this.$pause.addClass(classes.isPaused).attr('aria-pressed', 'true');
      if (this.autorotate) {
        $(slideshowSelector).slick('slickPause');
      }
    }
  };

  slideshow.prototype.setSlideshowHeight = function() {
    var minAspectRatio = this.$slideshow.data('min-aspect-ratio');
    this.$slideshow.height($(document).width() / minAspectRatio);
  };

  slideshow.prototype.showMobileText = function(slideIndex) {
    var $allTextContent = this.$textWrapperMobile.find(
      selectors.textContentMobile
    );
    var currentTextContentSelector =
      selectors.textContentMobile + '-' + slideIndex;
    var $currentTextContent = this.$textWrapperMobile.find(
      currentTextContentSelector
    );
    if (
      !$currentTextContent.length &&
      this.$slideshow.find(selectors.slides).length === 1
    ) {
      this.$textWrapperMobile.hide();
    } else {
      this.$textWrapperMobile.show();
    }
    $allTextContent.hide();
    $currentTextContent.show();
  };

  function getSlideshowId($el) {
    return '#Slideshow-' + $el.data('id');
  }

  return slideshow;
})();

// Youtube API callback
// eslint-disable-next-line no-unused-vars
function onYouTubeIframeAPIReady() {
  theme.Video.loadVideos();
}

theme.Video = (function() {
  var autoplayCheckComplete = false;
  var playOnClickChecked = false;
  var playOnClick = false;
  var youtubeLoaded = false;
  var videos = {};
  var videoPlayers = [];
  var videoOptions = {
    ratio: 16 / 9,
    scrollAnimationDuration: 400,
    playerVars: {
      // eslint-disable-next-line camelcase
      iv_load_policy: 3,
      modestbranding: 1,
      autoplay: 0,
      controls: 0,
      wmode: 'opaque',
      branding: 0,
      autohide: 0,
      rel: 0
    },
    events: {
      onReady: onPlayerReady,
      onStateChange: onPlayerChange
    }
  };
  var classes = {
    playing: 'video-is-playing',
    paused: 'video-is-paused',
    loading: 'video-is-loading',
    loaded: 'video-is-loaded',
    backgroundVideoWrapper: 'video-background-wrapper',
    videoWithImage: 'video--image_with_play',
    backgroundVideo: 'video--background',
    userPaused: 'is-paused',
    supportsAutoplay: 'autoplay',
    supportsNoAutoplay: 'no-autoplay',
    wrapperMinHeight: 'video-section-wrapper--min-height'
  };

  var selectors = {
    section: '.video-section',
    videoWrapper: '.video-section-wrapper',
    playVideoBtn: '.video-control__play',
    closeVideoBtn: '.video-control__close-wrapper',
    pauseVideoBtn: '.video__pause',
    pauseVideoStop: '.video__pause-stop',
    pauseVideoResume: '.video__pause-resume',
    fallbackText: '.icon__fallback-text'
  };

  /**
   * Public functions
   */
  function init($video) {
    if (!$video.length) {
      return;
    }

    videos[$video.attr('id')] = {
      id: $video.attr('id'),
      videoId: $video.data('id'),
      type: $video.data('type'),
      status:
        $video.data('type') === 'image_with_play' ? 'closed' : 'background', // closed, open, background
      $video: $video,
      $videoWrapper: $video.closest(selectors.videoWrapper),
      $section: $video.closest(selectors.section),
      controls: $video.data('type') === 'background' ? 0 : 1
    };

    if (!youtubeLoaded) {
      // This code loads the IFrame Player API code asynchronously.
      var tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      var firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
    }

    playOnClickCheck();
  }

  function customPlayVideo(playerId) {
    // Make sure we have carried out the playOnClick check first
    if (!playOnClickChecked && !playOnClick) {
      return;
    }

    if (playerId && typeof videoPlayers[playerId].playVideo === 'function') {
      privatePlayVideo(playerId);
    }
  }

  function pauseVideo(playerId) {
    if (
      videoPlayers[playerId] &&
      typeof videoPlayers[playerId].pauseVideo === 'function'
    ) {
      videoPlayers[playerId].pauseVideo();
    }
  }

  function loadVideos() {
    for (var key in videos) {
      if (videos.hasOwnProperty(key)) {
        createPlayer(key);
      }
    }

    initEvents();
    youtubeLoaded = true;
  }

  function editorLoadVideo(key) {
    if (!youtubeLoaded) {
      return;
    }
    createPlayer(key);

    initEvents();
  }

  /**
   * Private functions
   */

  function privatePlayVideo(id, clicked) {
    var videoData = videos[id];
    var player = videoPlayers[id];
    var $videoWrapper = videoData.$videoWrapper;

    if (playOnClick) {
      // playOnClick means we are probably on mobile (no autoplay).
      // setAsPlaying will show the iframe, requiring another click
      // to play the video.
      setAsPlaying(videoData);
    } else if (clicked || autoplayCheckComplete) {
      // Play if autoplay is available or clicked to play
      $videoWrapper.removeClass(classes.loading);
      setAsPlaying(videoData);
      player.playVideo();
      return;
    } else {
      player.playVideo();
    }
  }

  function setAutoplaySupport(supported) {
    var supportClass = supported
      ? classes.supportsAutoplay
      : classes.supportsNoAutoplay;
    $(document.documentElement)
      .removeClass(classes.supportsAutoplay)
      .removeClass(classes.supportsNoAutoplay)
      .addClass(supportClass);

    if (!supported) {
      playOnClick = true;
    }

    autoplayCheckComplete = true;
  }

  function playOnClickCheck() {
    // Bail early for a few instances:
    // - small screen
    // - device sniff mobile browser

    if (playOnClickChecked) {
      return;
    }

    if (isMobile()) {
      playOnClick = true;
    }

    if (playOnClick) {
      // No need to also do the autoplay check
      setAutoplaySupport(false);
    }

    playOnClickChecked = true;
  }

  // The API will call this function when each video player is ready
  function onPlayerReady(evt) {
    evt.target.setPlaybackQuality('hd1080');
    var videoData = getVideoOptions(evt);
    var videoTitle = evt.target.getVideoData().title;
    playOnClickCheck();

    // Prevent tabbing through YouTube player controls until visible
    $('#' + videoData.id).attr('tabindex', '-1');

    sizeBackgroundVideos();
    setButtonLabels(videoData.$videoWrapper, videoTitle);

    // Customize based on options from the video ID
    if (videoData.type === 'background') {
      evt.target.mute();
      privatePlayVideo(videoData.id);
    }

    videoData.$videoWrapper.addClass(classes.loaded);
  }

  function onPlayerChange(evt) {
    var videoData = getVideoOptions(evt);
    if (
      videoData.status === 'background' &&
      !isMobile() &&
      !autoplayCheckComplete &&
      (evt.data === YT.PlayerState.PLAYING ||
        evt.data === YT.PlayerState.BUFFERING)
    ) {
      setAutoplaySupport(true);
      autoplayCheckComplete = true;
      videoData.$videoWrapper.removeClass(classes.loading);
    }
    switch (evt.data) {
      case YT.PlayerState.ENDED:
        setAsFinished(videoData);
        break;
      case YT.PlayerState.PAUSED:
        // Seeking on a YouTube video also fires a PAUSED state change,
        // checking the state after a delay prevents us pausing the video when
        // the user is seeking instead of pausing
        setTimeout(function() {
          if (evt.target.getPlayerState() === YT.PlayerState.PAUSED) {
            setAsPaused(videoData);
          }
        }, 200);
        break;
    }
  }

  function setAsFinished(videoData) {
    switch (videoData.type) {
      case 'background':
        videoPlayers[videoData.id].seekTo(0);
        break;
      case 'image_with_play':
        closeVideo(videoData.id);
        toggleExpandVideo(videoData.id, false);
        break;
    }
  }

  function setAsPlaying(videoData) {
    var $videoWrapper = videoData.$videoWrapper;
    var $pauseButton = $videoWrapper.find(selectors.pauseVideoBtn);

    $videoWrapper.removeClass(classes.loading);

    if ($pauseButton.hasClass(classes.userPaused)) {
      $pauseButton.removeClass(classes.userPaused);
    }

    // Do not change element visibility if it is a background video
    if (videoData.status === 'background') {
      return;
    }

    $('#' + videoData.id).attr('tabindex', '0');

    if (videoData.type === 'image_with_play') {
      $videoWrapper.removeClass(classes.paused).addClass(classes.playing);
    }

    // Update focus to the close button so we stay within the video wrapper,
    // allowing time for the scroll animation
    setTimeout(function() {
      $videoWrapper.find(selectors.closeVideoBtn).focus();
    }, videoOptions.scrollAnimationDuration);
  }

  function setAsPaused(videoData) {
    var $videoWrapper = videoData.$videoWrapper;

    // YT's events fire after our click event. This status flag ensures
    // we don't interact with a closed or background video.
    if (videoData.type === 'image_with_play') {
      if (videoData.status === 'closed') {
        $videoWrapper.removeClass(classes.paused);
      } else {
        $videoWrapper.addClass(classes.paused);
      }
    }

    $videoWrapper.removeClass(classes.playing);
  }

  function closeVideo(playerId) {
    var videoData = videos[playerId];
    var $videoWrapper = videoData.$videoWrapper;
    var classesToRemove = [classes.paused, classes.playing].join(' ');

    if (isMobile()) {
      $videoWrapper.removeAttr('style');
    }

    $('#' + videoData.id).attr('tabindex', '-1');

    videoData.status = 'closed';

    switch (videoData.type) {
      case 'image_with_play':
        videoPlayers[playerId].stopVideo();
        setAsPaused(videoData); // in case the video is already paused
        break;
      case 'background':
        videoPlayers[playerId].mute();
        setBackgroundVideo(playerId);
        break;
    }

    $videoWrapper.removeClass(classesToRemove);
  }

  function getVideoOptions(evt) {
    return videos[evt.target.a.id];
  }

  function toggleExpandVideo(playerId, expand) {
    var video = videos[playerId];
    var elementTop = video.$videoWrapper.offset().top;
    var $playButton = video.$videoWrapper.find(selectors.playVideoBtn);
    var offset = 0;
    var newHeight = 0;

    if (isMobile()) {
      video.$videoWrapper.parent().toggleClass('page-width', !expand);
    }

    if (expand) {
      if (isMobile()) {
        newHeight = $(window).width() / videoOptions.ratio;
      } else {
        newHeight = video.$videoWrapper.width() / videoOptions.ratio;
      }
      offset = ($(window).height() - newHeight) / 2;

      video.$videoWrapper
        .removeClass(classes.wrapperMinHeight)
        .animate({ height: newHeight }, 600);

      // Animate doesn't work in mobile editor, so we don't use it
      if (!(isMobile() && Shopify.designMode)) {
        $('html, body').animate(
          {
            scrollTop: elementTop - offset
          },
          videoOptions.scrollAnimationDuration
        );
      }
    } else {
      if (isMobile()) {
        newHeight = video.$videoWrapper.data('mobile-height');
      } else {
        newHeight = video.$videoWrapper.data('desktop-height');
      }

      video.$videoWrapper
        .height(video.$videoWrapper.width() / videoOptions.ratio)
        .animate({ height: newHeight }, 600);
      setTimeout(function() {
        video.$videoWrapper.addClass(classes.wrapperMinHeight);
      }, 600);
      $playButton.focus();
    }
  }

  function togglePause(playerId) {
    var $pauseButton = videos[playerId].$videoWrapper.find(
      selectors.pauseVideoBtn
    );
    var paused = $pauseButton.hasClass(classes.userPaused);
    if (paused) {
      $pauseButton.removeClass(classes.userPaused);
      customPlayVideo(playerId);
    } else {
      $pauseButton.addClass(classes.userPaused);
      pauseVideo(playerId);
    }
    $pauseButton.attr('aria-pressed', !paused);
  }

  function startVideoOnClick(playerId) {
    var video = videos[playerId];

    // add loading class to wrapper
    video.$videoWrapper.addClass(classes.loading);

    // Explicity set the video wrapper height (needed for height transition)
    video.$videoWrapper.attr(
      'style',
      'height: ' + video.$videoWrapper.height() + 'px'
    );

    video.status = 'open';

    switch (video.type) {
      case 'image_with_play':
        privatePlayVideo(playerId, true);
        break;
      case 'background':
        unsetBackgroundVideo(playerId, video);
        videoPlayers[playerId].unMute();
        privatePlayVideo(playerId, true);
        break;
    }

    toggleExpandVideo(playerId, true);

    // esc to close video player
    $(document).on('keydown.videoPlayer', function(evt) {
      var playerId = $(document.activeElement).data('controls');
      if (evt.keyCode !== slate.utils.keyboardKeys.ESCAPE || !playerId) {
        return;
      }

      closeVideo(playerId);
      toggleExpandVideo(playerId, false);
    });
  }

  function sizeBackgroundVideos() {
    $('.' + classes.backgroundVideo).each(function(index, el) {
      sizeBackgroundVideo($(el));
    });
  }

  function sizeBackgroundVideo($videoPlayer) {
    if (!youtubeLoaded) {
      return;
    }

    if (isMobile()) {
      $videoPlayer.removeAttr('style');
    } else {
      var $videoWrapper = $videoPlayer.closest(selectors.videoWrapper);
      var videoWidth = $videoWrapper.width();
      var playerWidth = $videoPlayer.width();
      var desktopHeight = $videoWrapper.data('desktop-height');

      // when screen aspect ratio differs from video, video must center and underlay one dimension
      if (videoWidth / videoOptions.ratio < desktopHeight) {
        playerWidth = Math.ceil(desktopHeight * videoOptions.ratio); // get new player width
        $videoPlayer
          .width(playerWidth)
          .height(desktopHeight)
          .css({
            left: (videoWidth - playerWidth) / 2,
            top: 0
          }); // player width is greater, offset left; reset top
      } else {
        // new video width < window width (gap to right)
        desktopHeight = Math.ceil(videoWidth / videoOptions.ratio); // get new player height
        $videoPlayer
          .width(videoWidth)
          .height(desktopHeight)
          .css({
            left: 0,
            top: (desktopHeight - desktopHeight) / 2
          }); // player height is greater, offset top; reset left
      }

      $videoPlayer.prepareTransition();
      $videoWrapper.addClass(classes.loaded);
    }
  }

  function unsetBackgroundVideo(playerId) {
    // Switch the background video to a chrome-only player once played
    $('#' + playerId)
      .removeClass(classes.backgroundVideo)
      .addClass(classes.videoWithImage);

    setTimeout(function() {
      $('#' + playerId).removeAttr('style');
    }, 600);

    videos[playerId].$videoWrapper
      .removeClass(classes.backgroundVideoWrapper)
      .addClass(classes.playing);

    videos[playerId].status = 'open';
  }

  function setBackgroundVideo(playerId) {
    $('#' + playerId)
      .removeClass(classes.videoWithImage)
      .addClass(classes.backgroundVideo);

    videos[playerId].$videoWrapper.addClass(classes.backgroundVideoWrapper);

    videos[playerId].status = 'background';
    sizeBackgroundVideo($('#' + playerId));
  }

  function isMobile() {
    return $(window).width() < 750 || window.mobileCheck();
  }

  function initEvents() {
    $(document).on('click.videoPlayer', selectors.playVideoBtn, function(evt) {
      var playerId = $(evt.currentTarget).data('controls');

      startVideoOnClick(playerId);
    });

    $(document).on('click.videoPlayer', selectors.closeVideoBtn, function(evt) {
      var playerId = $(evt.currentTarget).data('controls');

      $(evt.currentTarget).blur();
      closeVideo(playerId);
      toggleExpandVideo(playerId, false);
    });

    $(document).on('click.videoPlayer', selectors.pauseVideoBtn, function(evt) {
      var playerId = $(evt.currentTarget).data('controls');
      togglePause(playerId);
    });

    // Listen to resize to keep a background-size:cover-like layout
    $(window).on(
      'resize.videoPlayer',
      $.debounce(200, function() {
        if (!youtubeLoaded) return;
        var key;
        var fullscreen = window.innerHeight === screen.height;

        sizeBackgroundVideos();

        if (isMobile()) {
          for (key in videos) {
            if (videos.hasOwnProperty(key)) {
              if (videos[key].$videoWrapper.hasClass(classes.playing)) {
                if (!fullscreen) {
                  pauseVideo(key);
                  setAsPaused(videos[key]);
                }
              }
              videos[key].$videoWrapper.height(
                $(document).width() / videoOptions.ratio
              );
            }
          }
          setAutoplaySupport(false);
        } else {
          setAutoplaySupport(true);
          for (key in videos) {
            if (
              videos[key].$videoWrapper.find('.' + classes.videoWithImage)
                .length
            ) {
              continue;
            }
            videoPlayers[key].playVideo();
            setAsPlaying(videos[key]);
          }
        }
      })
    );

    $(window).on(
      'scroll.videoPlayer',
      $.debounce(50, function() {
        if (!youtubeLoaded) return;

        for (var key in videos) {
          if (videos.hasOwnProperty(key)) {
            var $videoWrapper = videos[key].$videoWrapper;

            // Close the video if more than 75% of it is scrolled out of view
            if (
              $videoWrapper.hasClass(classes.playing) &&
              ($videoWrapper.offset().top + $videoWrapper.height() * 0.75 <
                $(window).scrollTop() ||
                $videoWrapper.offset().top + $videoWrapper.height() * 0.25 >
                  $(window).scrollTop() + $(window).height())
            ) {
              closeVideo(key);
              toggleExpandVideo(key, false);
            }
          }
        }
      })
    );
  }

  function createPlayer(key) {
    var args = $.extend({}, videoOptions, videos[key]);
    args.playerVars.controls = args.controls;
    videoPlayers[key] = new YT.Player(key, args);
  }

  function removeEvents() {
    $(document).off('.videoPlayer');
    $(window).off('.videoPlayer');
  }

  function setButtonLabels($videoWrapper, title) {
    var $playButtons = $videoWrapper.find(selectors.playVideoBtn);
    var $closeButton = $videoWrapper.find(selectors.closeVideoBtn);
    var $pauseButton = $videoWrapper.find(selectors.pauseVideoBtn);
    var $closeButtonText = $closeButton.find(selectors.fallbackText);
    var $pauseButtonStopText = $pauseButton
      .find(selectors.pauseVideoStop)
      .find(selectors.fallbackText);
    var $pauseButtonResumeText = $pauseButton
      .find(selectors.pauseVideoResume)
      .find(selectors.fallbackText);

    // Insert the video title retrieved from YouTube into the instructional text
    // for each button
    $playButtons.each(function() {
      var $playButton = $(this);
      var $playButtonText = $playButton.find(selectors.fallbackText);

      $playButtonText.text(
        $playButtonText.text().replace('[video_title]', title)
      );
    });
    $closeButtonText.text(
      $closeButtonText.text().replace('[video_title]', title)
    );
    $pauseButtonStopText.text(
      $pauseButtonStopText.text().replace('[video_title]', title)
    );
    $pauseButtonResumeText.text(
      $pauseButtonResumeText.text().replace('[video_title]', title)
    );
  }

  return {
    init: init,
    editorLoadVideo: editorLoadVideo,
    loadVideos: loadVideos,
    playVideo: customPlayVideo,
    pauseVideo: pauseVideo,
    removeEvents: removeEvents
  };
})();

window.theme = window.theme || {};

theme.FormStatus = (function() {
  var selectors = {
    statusMessage: '[data-form-status]'
  };

  function init() {
    this.$statusMessage = $(selectors.statusMessage);

    if (!this.$statusMessage) return;

    this.$statusMessage.attr('tabindex', -1).focus();

    this.$statusMessage.on('blur', handleBlur.bind(this));
  }

  function handleBlur() {
    this.$statusMessage.removeAttr('tabindex');
  }

  return {
    init: init
  };
})();

theme.Hero = (function() {
  var classes = {
    indexSectionFlush: 'index-section--flush'
  };

  var selectors = {
    heroFixedWidthContent: '.hero-fixed-width__content',
    heroFixedWidthImage: '.hero-fixed-width__image'
  };

  function hero(el, sectionId) {
    this.$hero = $(el);
    this.layout = this.$hero.data('layout');
    var $parentSection = $('#shopify-section-' + sectionId);
    var $heroContent = $parentSection.find(selectors.heroFixedWidthContent);
    var $heroImage = $parentSection.find(selectors.heroFixedWidthImage);

    if (this.layout !== 'fixed_width') {
      return;
    }

    $parentSection.removeClass(classes.indexSectionFlush);
    heroFixedHeight();
    $(window).resize(
      $.debounce(50, function() {
        heroFixedHeight();
      })
    );

    function heroFixedHeight() {
      var contentHeight = $heroContent.height() + 50;
      var imageHeight = $heroImage.height();

      if (contentHeight > imageHeight) {
        $heroImage.css('min-height', contentHeight);
      }
    }
  }

  return hero;
})();


/* ================ TEMPLATES ================ */
(function() {
  var $filterBy = $('#BlogTagFilter');

  if (!$filterBy.length) {
    return;
  }

  $filterBy.on('change', function() {
    location.href = $(this).val();
  });
})();

window.theme = theme || {};

theme.customerTemplates = (function() {
  var selectors = {
    RecoverHeading: '#RecoverHeading',
    RecoverEmail: '#RecoverEmail',
    LoginHeading: '#LoginHeading'
  };

  function initEventListeners() {
    this.$RecoverHeading = $(selectors.RecoverHeading);
    this.$RecoverEmail = $(selectors.RecoverEmail);
    this.$LoginHeading = $(selectors.LoginHeading);

    // Show reset password form
    $('#RecoverPassword').on(
      'click',
      function(evt) {
        evt.preventDefault();
        showRecoverPasswordForm();
        this.$RecoverHeading.attr('tabindex', '-1').focus();
      }.bind(this)
    );

    // Hide reset password form
    $('#HideRecoverPasswordLink').on(
      'click',
      function(evt) {
        evt.preventDefault();
        hideRecoverPasswordForm();
        this.$LoginHeading.attr('tabindex', '-1').focus();
      }.bind(this)
    );

    this.$RecoverHeading.on('blur', function() {
      $(this).removeAttr('tabindex');
    });

    this.$LoginHeading.on('blur', function() {
      $(this).removeAttr('tabindex');
    });
  }
  
  // Show signup form
    $('#signUpSwitch , #notaMember').on(
      'click',
      function(evt) {
        evt.preventDefault();
        showSignUpForm();
      }.bind(this)
    );

    // Hide reset password form
    $('#logInSwitch , #alreadyLogIn').on(
      'click',
      function(evt) {
        evt.preventDefault();
        hideSignUpForm();
      }.bind(this)
    );
  
  /**
   *
   *  Show/Hide signup form
   *
   */

  function showSignUpForm() {
    $('#SignUpForm').removeClass('hide');
    $('#logInSwitch').removeClass('selected');
    $('#CustomerLoginForm').addClass('hide');
    $('#RecoverPasswordForm').addClass('hide');
    $('#signUpSwitch').addClass('selected');

    if (this.$RecoverEmail.attr('aria-invalid') === 'true') {
      this.$RecoverEmail.focus();
    }
  }

  function hideSignUpForm() {
    $('#SignUpForm').addClass('hide');
    $('#logInSwitch').addClass('selected');
    $('#RecoverPasswordForm').addClass('hide');
    $('#signUpSwitch').removeClass('selected');
    $('#CustomerLoginForm').removeClass('hide');
  }



  /**
   *
   *  Show/Hide recover password form
   *
   */

  function showRecoverPasswordForm() {
    $('#RecoverPasswordForm').removeClass('hide');
    $('#CustomerLoginForm').addClass('hide');

    if (this.$RecoverEmail.attr('aria-invalid') === 'true') {
      this.$RecoverEmail.focus();
    }
  }

  function hideRecoverPasswordForm() {
    $('#RecoverPasswordForm').addClass('hide');
    $('#CustomerLoginForm').removeClass('hide');
  }

  /**
   *
   *  Show reset password success message
   *
   */
  function resetPasswordSuccess() {
    var $formState = $('.reset-password-success');

    // check if reset password form was successfully submited.
    if (!$formState.length) {
      return;
    }

    // show success message
    $('#ResetSuccess')
      .removeClass('hide')
      .focus();
  }

  /**
   *
   *  Show/hide customer address forms
   *
   */
  function customerAddressForm() {
    var $newAddressForm = $('#AddressNewForm');
    var $newAddressFormButton = $('#AddressNewButton');

    if (!$newAddressForm.length) {
      return;
    }

    // Initialize observers on address selectors, defined in shopify_common.js
    if (Shopify) {
      // eslint-disable-next-line no-new
      new Shopify.CountryProvinceSelector(
        'AddressCountryNew',
        'AddressProvinceNew',
        {
          hideElement: 'AddressProvinceContainerNew'
        }
      );
    }

    // Initialize each edit form's country/province selector
    $('.address-country-option').each(function() {
      var formId = $(this).data('form-id');
      var countrySelector = 'AddressCountry_' + formId;
      var provinceSelector = 'AddressProvince_' + formId;
      var containerSelector = 'AddressProvinceContainer_' + formId;

      // eslint-disable-next-line no-new
      new Shopify.CountryProvinceSelector(countrySelector, provinceSelector, {
        hideElement: containerSelector
      });
    });

    // Toggle new/edit address forms
    $('.address-new-toggle').on('click', function() {
      var isExpanded = $newAddressFormButton.attr('aria-expanded') === 'true';

      $newAddressForm.toggleClass('hide');
      $newAddressFormButton.attr('aria-expanded', !isExpanded).focus();
    });

    $('.address-edit-toggle').on('click', function() {
      var formId = $(this).data('form-id');
      var $editButton = $('#EditFormButton_' + formId);
      var $editAddress = $('#EditAddress_' + formId);
      var isExpanded = $editButton.attr('aria-expanded') === 'true';

      $editAddress.toggleClass('hide');
      $editButton.attr('aria-expanded', !isExpanded).focus();
    });

    $('.address-delete').on('click', function() {
      var $el = $(this);
      var target = $el.data('target');
      var confirmMessage = $el.data('confirm-message');

      // eslint-disable-next-line no-alert
      if (
        confirm(
          confirmMessage || 'Are you sure you wish to delete this address?'
        )
      ) {
        Shopify.postLink(target, {
          parameters: { _method: 'delete' }
        });
      }
    });
  }

  /**
   *
   *  Check URL for reset password hash
   *
   */
  function checkUrlHash() {
    var hash = window.location.hash;

    // Allow deep linking to recover password form
    if (hash === '#recover') {
      showRecoverPasswordForm.bind(this)();
    }
  }

  return {
    init: function() {
      initEventListeners();
      checkUrlHash();
      resetPasswordSuccess();
      customerAddressForm();
    }
  };
})();


/*================ SECTIONS ================*/
window.theme = window.theme || {};

theme.Cart = (function() {
  var selectors = {
    edit: '.js-edit-toggle',
    inputQty: '.cart__qty-input',
    thumbnails: '.cart__image',
    item: '.cart__row'
  };

  var config = {
    showClass: 'cart__update--show',
    showEditClass: 'cart__edit--active',
    cartNoCookies: 'cart--no-cookies'
  };

  function Cart(container) {
    this.$container = $(container);
    this.$edit = $(selectors.edit, this.$container);
    this.$inputQuantities = $(selectors.inputQty, this.$container);
    this.$thumbnails = $(selectors.thumbnails, this.$container);

    if (!this.cookiesEnabled()) {
      this.$container.addClass(config.cartNoCookies);
    }

    this.$edit.on('click', this._onEditClick);
    this.$inputQuantities.on('change', this._handleInputQty);

    this.$thumbnails.css('cursor', 'pointer');
    this.$thumbnails.on('click', this._handleThumbnailClick);
  }

  Cart.prototype = _.assignIn({}, Cart.prototype, {
    onUnload: function() {
      this.$edit.off('click', this._onEditClick);
    },

    _onEditClick: function(evt) {
      var $evtTarget = $(evt.target);
      var $updateLine = $('.' + $evtTarget.data('target'));
      var isExpanded = $evtTarget.attr('aria-expanded') === 'true';

      $evtTarget
        .toggleClass(config.showEditClass)
        .attr('aria-expanded', !isExpanded);
      $updateLine.toggleClass(config.showClass);
    },

    _handleInputQty: function(evt) {
      var $input = $(evt.target);
      var value = $input.val();
      var itemKey = $input.data('quantity-item');
      var $itemQtyInputs = $('[data-quantity-item=' + itemKey + ']');
      $itemQtyInputs.val(value);
    },

    _handleThumbnailClick: function(evt) {
      var url = $(evt.target).data('item-url');

      window.location.href = url;
    },

    cookiesEnabled: function() {
      var cookieEnabled = navigator.cookieEnabled;

      if (!cookieEnabled) {
        document.cookie = 'testcookie';
        cookieEnabled = document.cookie.indexOf('testcookie') !== -1;
      }
      return cookieEnabled;
    }
  });

  return Cart;
})();

// Cart start
function addMatchingItem(btn, variant, is_art_series, is_zodiac_series,is_upsell,productType,preorder_text) {
  btn.addEventListener('click', function(e) {

 e.preventDefault();
     $('.matching-heading').trigger('click');
    $(".matching__atc").addClass('hide');
    $(".adding_atc").removeClass('hide');
    $(".adding_atc").attr('disabled',true);
    let btn_text = $(this).find('[data-add-to-cart-text]')[0];
    let btn_loader = $(this).find('[data-loader]')[0];
    if(btn_text != null && btn_loader != null) {
      btn_text.classList.add('hide');
      btn_loader.classList.remove('hide');
    }
    
    let props = {
       'Foil Color': foil.get(),
      'Text': initials.get(productType),
     
      'Pre-order':preorder_text
    };
    
    if($(btn).hasClass('upsell_item--add')){
       props = {
      'Text': '',
      'Foil Color': ''
    	};
   	}
    if(is_art_series) {
      props = {
        'Artwork': artwork.get(),
        'Foil Color': 'Gold'
      };
    }

    //Zodiac
    if(is_zodiac_series) {
      props = {
        'Zodiac': zodiac.get(),
        'Foil Color': 'Gold'
      };
    }

    $.post('/cart/add.js', {
      quantity: 1,
      id: variant.id,
      properties: props
    }, function(item) {
      loadCart(0);
      if(btn_text != null && btn_loader != null) {
        btn_text.classList.remove('hide');
        btn_loader.classList.add('hide');
      }
    }, "json");
  });
  
}
$(document).on('change','.dropdown-btn',function(e){
  var variantid = $('option:selected', this).attr('variantid');
    $.post('/cart/add.js', {
          quantity: 1,
          id: variantid
        }, function(item) {
          loadCart(0);
        }, "json");
});

function checkForMatch(cart, product, itemToMatch) {
  let notInCart = cart.items.filter(function(line_item) { return line_item.product_id == product.id; }).length <= 0;
  let differentType = product.product_type != itemToMatch.product_type;
  let typeNotInCart = cart.items.filter(function(line_item) { return line_item.product_type == product.product_type; }).length <= 0;
if(product.product_type == 'Screen Protector') { typeNotInCart = true;differentType=true;}

  return notInCart && differentType && typeNotInCart;
}

function getMatchingItems(container, cart) {
  
  var itemindex=0;
  if(cart.items[0].product_type=="Gift" && cart.items[1]!=null) {
  	itemindex=1;
  }
  const itemToMatch = cart.items[itemindex];
  let colour = itemToMatch.variant_options[itemToMatch.variant_options.length - 1];
    colour = colour.includes('Ombré')? 'Black Caviar': colour ;
  colour = colour.includes('Laguna')? 'Sky Blue': colour ;
  colour = colour.includes('Kiwi')? 'Emerald Green': colour ;
  colour = colour.includes('Viola')? 'Lavender Purple': colour ;
  const upsellTag = "upsell2";
  const forMatchTag = "formatch";
  const forNotMatchTag = "notmatch2"; //for airpods
	//matchingCondition 0 for upsell
  	//1 for color
  	//2 for specific tag
  let var_id = 8;
  function renderProduct(product,matchingCondition,model ='') {
    //console.log(model);
     let variant=null;
    if(model.includes('iPhone 11') || model.includes('iPhone XR Case')){
    	var_id = 3;
    }
     if( model.includes('iPhone 12') ||  model.includes('iPhone 13')){
    	var_id = 6;
    }
    if(model == 'iPhone 7/8 Case' || model ==  'iPhone SE Case'){
    	var_id = 0;
    }
    if(model == 'iPhone 7/8 Plus Case' ){
    	var_id = 1;
    }
    if( model.includes('iPhone 11 Pro') || model ==  'iPhone X/XS Case'){
    	var_id = 2;
    }
       if( model.includes('iPhone 12 Pro') || model.includes('iPhone 13 Pro')){
    	var_id = 6;
    }
    if( model.includes('iPhone 12 Pro Max') || model.includes('iPhone 13 Pro Max') ){
    	var_id = 7;
    }
   
 
    if( model.includes('iPhone 12 Mini') ||  model.includes('iPhone 13 Mini')){
    	var_id = 5;
    }
    if( model.includes('iPhone XS Max ') ||  model.includes('iPhone 11 Pro Max')){
    	var_id = 4;
    }

    if(model == 'iPhone 14 Case' || model == "The Sling Phone Case - iPhone 14" || model == "The Jelligrain™ Phone Case - iPhone 14"){
      var_id = 11;
    }
    if(model == "iPhone 14 Plus Case" || model == "The Sling Phone Case - iPhone 14 Plus" || model == "The Jelligrain™ Phone Case - iPhone 14 Plus"){
      var_id = 10;
    }
    if(model == "The Sling Phone Case - iPhone 14 Pro Max" || model == 'iPhone 14 Pro Max Case' || model == "The Jelligrain™ Phone Case - iPhone 14 Pro Max") {
      var_id = 8;
    }
    if(model == "The Sling Phone Case - iPhone 14 Pro" || model == "The Jelligrain™ Phone Case - iPhone 14 Pro" || model == "iPhone 14 Pro Case") {
      var_id = 9;
    }  
    
   if(model=='watch_protector')
        {var_id = 0;
         }
     if(matchingCondition==0) {   
        variant = product.variants[var_id];
     }
    
     if(matchingCondition==1) {
       if(product.title.includes('Day Card')) {

      variant = product.variants[0];
    }
    else {
       if(colour.includes('Tempered')) {
       	colour = cart.items[cart.items.length - 1].variant_options[0];
       }
       colour =   checkdisneycolour(colour);
       if(product.product_type.includes('Watch')){ 
              variant = product.variants.filter(function(variant) { return variant.option2 == colour; })[0];

       }
       else {
       variant = product.variants.filter(function(variant) { return variant.option1 == colour; })[0];
       }
     }
     }
   if(matchingCondition==2) {
     var preorder="none";
     for (var i=0; i<product.variants.length;i++){
      //  preorder = product.tags.indexOf("pre order") != -1;
     	if(product.variants[i].available){
       		 variant = product.variants[i];
          	 break;
       }
     }
      
   }
        if(matchingCondition==3) {
      
       variant = product.variants[0];
     }
     if(variant == null) { return; }
    if(!variant.available) { return; }
    let matching_item = document.createElement('div');
    let variantURL = '/products/' + product.handle + '?variant=' + variant.id;
    if(matchingCondition==0) {
     let puzzle_description="Tempered Glass";
     let puzzle_price= "<span class='upsell_deiscount'>"+ theme.Currency.formatMoney(variant.price, "NO_CURRENCY") + "</span>";
  
      	puzzle_description="Tempered Glass";
        puzzle_price =   puzzle_price + "<span class='free_puzzle'>" + theme.Currency.formatMoney(variant.compare_at_price, "NO_CURRENCY") + " </span>" ;
      
      matching_item.classList.add('css-slider_slide');
      matching_item.classList.add('slider_matching--items');
      matching_item.classList.add('screen-protector-upsell');
      
      let matching__outer = document.createElement('div');
      matching__outer.classList.add('matching_itemcart_main');
      matching_item.appendChild(matching__outer);
      
      let matching__inner = document.createElement('div');
      matching__inner.classList.add('matching__item__image');
      matching__inner.classList.add('cart__item__image' + variant.title.replace(/ /g,"-"));
      matching__outer.appendChild(matching__inner);

      let image_link = document.createElement('a');
      image_link.classList.add('product-image-fix');
      image_link.classList.add('matching-image-fix-link');
      
      matching__inner.appendChild(image_link);

      let image_wrap = document.createElement('div');
      image_wrap.classList.add('relative');
      image_link.appendChild(image_wrap);

      let matching_item_image = document.createElement('img');
      let image_src = variant.featured_image != null ? variant.featured_image.src : product.images[0].src;
      matching_item_image.setAttribute('src', image_src.replace('.jpg', '_360x.jpg'));
      matching_item_image.setAttribute('alt', variant.title);
      image_wrap.appendChild(matching_item_image);

      let matching_form = document.createElement('div');
      matching_form.classList.add('cart__item__details');
      matching_form.classList.add('matching-details__form');
      matching__outer.appendChild(matching_form);

      let variant_info = document.createElement('div');
      variant_info.classList.add('matching__product-info');
      matching_form.appendChild(variant_info);

      let variant_title = document.createElement('a');
      variant_title.classList.add('matching__product-title');
      variant_title.innerHTML = product.title;
      variant_info.appendChild(variant_title);

      let description = document.createElement('span');
      description.classList.add('description');
      description.classList.add('puzzle_description');
      description.innerHTML = puzzle_description;
      variant_info.appendChild(description);

      let price_wrapper = document.createElement('div');
      price_wrapper.classList.add('cart__price-wrapper');
      price_wrapper.classList.add('price_matching_item');
      variant_info.appendChild(price_wrapper);



      let variant_price = document.createElement('span');
      variant_price.classList.add('price');
      variant_price.classList.add('price__upsell');
      variant_price.innerHTML = puzzle_price;
      price_wrapper.appendChild(variant_price);
       if(model=='watch_protector') {
      let atc_size_btn = document.createElement('select');
        atc_size_btn.classList.add('btn');
      atc_size_btn.classList.add('btn--alternate');
      atc_size_btn.classList.add('matching__atc');
      atc_size_btn.classList.add('dropdown-btn');
    var atc_size_option_default = document.createElement("option");
atc_size_option_default.value = "Select Size";
atc_size_option_default.text = "+ ADD";
 atc_size_option_default.setAttribute('disabled', true);
  atc_size_option_default.setAttribute('selected', true);
  atc_size_btn.appendChild(atc_size_option_default);
     for(var atc_i = 0; atc_i < product.variants.length ; atc_i++ ){
      variantURL = '/products/' + product.handle + '?variant=' + product.variants[atc_i].id;

    var atc_size_option = document.createElement("option");
    var option_text = product.variants[atc_i].option1;

      if(!product.variants[atc_i].available) {
     atc_size_option.setAttribute('disabled', true);
     option_text = option_text + '(Out of Stock)';
   }
    atc_size_option.value = product.variants[atc_i].option1;;
    atc_size_option.text = option_text;
      atc_size_option.setAttribute('variantID', product.variants[atc_i].id);


    atc_size_btn.appendChild(atc_size_option);
    
    }
    matching_form.appendChild(atc_size_btn);
  }
  else {

      let atc = document.createElement('a');
      atc.classList.add('btn');
      atc.classList.add('btn--alternate');
      atc.classList.add('matching__atc');
      atc.classList.add('upsell_item--add');
      atc.setAttribute('href', variantURL);
      addMatchingItem(atc, variant, false, false,'upsell',product.product_type,preorder_text);
      matching_form.appendChild(atc);
      
      let adding_atc = document.createElement('a');
      adding_atc.classList.add('btn');
      adding_atc.classList.add('btn--alternate');
      adding_atc.classList.add('adding_atc');
      adding_atc.classList.add('hide');
      adding_atc.setAttribute('href', '#');
      matching_form.appendChild(adding_atc);

      let atc_text = document.createElement('span');
      atc_text.setAttribute('data-add-to-cart-text', '');
      atc_text.innerHTML = cart_add;
      atc.appendChild(atc_text);

      let atc_loader = document.createElement('span');
      atc_loader.setAttribute('data-loader', '');
      atc_loader.classList.add('hide');
      atc.appendChild(atc_loader);

      let atc_loader_svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      atc_loader_svg.classList.add('icon');
      atc_loader_svg.classList.add('icon-spinner');
      atc_loader.appendChild(atc_loader_svg);

      let atc_loader_path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      atc_loader_path.setAttribute('d', 'M7.229 1.173a9.25 9.25 0 1 0 11.655 11.412 1.25 1.25 0 1 0-2.4-.698 6.75 6.75 0 1 1-8.506-8.329 1.25 1.25 0 1 0-.75-2.385z');
      atc_loader_svg.appendChild(atc_loader_path);
      adding_atc.innerHTML = '';
      adding_atc.appendChild(atc_loader_svg);
  }
    
   } //matching item is upsell
    
    if(matchingCondition==1 || matchingCondition==2 || matchingCondition==3) {
      let is_art_series = product.tags.indexOf('amber-vittoria') != -1;
    // zodiac
      let is_zodiac_series = product.tags.indexOf('zodiac-series') != -1;
      var preorder_matching = document.querySelector('#preorder'+product.id);
      let is_preorder_matching = false;
      var preorder_text=null;
      if(preorder_matching != null) {
        let variants_matching = preorder_matching.value.split(',');
       //  console.log(variants_matching);
        for(var i = 0; i < variants_matching.length; i++) {
          let values = variants_matching[i].split(':');
          if(values[0] == variant.id) {
            preorder_matching = values[1] == "true";
          }
        }
      }
      if(preorder_matching) {
      
          for(i=0;i<product.tags.length;i++) {
            if(product.tags[i].includes('eta:')) {
              preorder_text=product.tags[i].split(':')[1];
            }
        }
      }
      matching_item.classList.add('css-slider_slide');
      matching_item.classList.add('slider_matching--items');
      matching_item.classList.add(product.product_type.toLowerCase().replaceAll(' ', '-'));

      let matching__outer = document.createElement('div');
      matching__outer.classList.add('matching_itemcart_main');
      matching_item.appendChild(matching__outer);
      
      let matching__inner = document.createElement('div');
      matching__inner.classList.add('matching__item__image');
      matching__inner.classList.add('cart__item__image');  //for color
      matching__inner.classList.add(variant.title.toLowerCase().replaceAll(' ','-'));
      matching__outer.appendChild(matching__inner);

      let image_link = document.createElement('a');
      image_link.classList.add('product-image-fix');
      image_link.classList.add('matching-image-fix-link');
      image_link.setAttribute('href', variantURL);
      matching__inner.appendChild(image_link);

      let image_wrap = document.createElement('div');
      image_wrap.classList.add('relative');
      image_link.appendChild(image_wrap);

      let matching_item_image = document.createElement('img');
      let image_src = variant.featured_image != null ? variant.featured_image.src : product.images[0].src;
      matching_item_image.setAttribute('src', image_src.replace('.jpg', '_360x.jpg'));
      matching_item_image.setAttribute('alt', variant.title);
      image_wrap.appendChild(matching_item_image);

      let engraving = document.createElement('div');
      engraving.classList.add('matching-engrave');
      engraving.classList.add('engrave');

      if(is_art_series) {
        engraving.classList.add('artwork-engrave')
      } else if (is_zodiac_series){
        engraving.classList.add('zodiac-engrave')
        } else {
        engraving.classList.add('icon-chess-piece');
      }
      engraving.classList.add(product.product_type.toLowerCase().replaceAll(' ', '-'));
      if(is_art_series) {
        engraving.classList.add(artwork.get().toLowerCase().replaceAll(/ /g, '-'));
      } else if (is_zodiac_series) {
        engraving.classList.add(zodiac.get().toLowerCase().replaceAll(/ /g, '-'));
      } else {
        engraving.classList.add(foil.get().toLowerCase());
        if(product.product_type == 'Airpods')
        {engraving.innerHTML = initials.get('shortMonogram2');}
      else {
        engraving.innerHTML = initials.get(product.product_type);
      }
      }
      image_wrap.appendChild(engraving);

      let matching_form = document.createElement('div');
      matching_form.classList.add('cart__item__details');
      matching__outer.appendChild(matching_form);

      let variant_info = document.createElement('div');
      variant_info.classList.add('matching__product-info');
      matching_form.appendChild(variant_info);

      let variant_title = document.createElement('a');
      variant_title.classList.add('cart__product-title');
      variant_title.classList.add('md_text');
      variant_title.classList.add('bold');
      variant_title.setAttribute('href', variantURL);
     // variant_title.innerHTML = product.title + " - " + variant.title;
      variant_title.innerHTML = product.title ;
      variant_info.appendChild(variant_title);
      
      let variant_color = document.createElement('span');
      variant_color.classList.add('cart_text');
     // variant_title.innerHTML = product.title + " - " +
      if(product.product_type  == 'Gift Boxes & Tins') {
        var limited_text = 'Complimentary when you purchase 2 items';
        if(product.title.includes('Laptop')) {
           limited_text = 'Complimentary when you purchase a laptop case';
        }
           if(product.title.includes('Tote')) {
           limited_text = 'Complimentary when you purchase a mini tote';
        }
      	 variant_color.innerHTML = '<br>' + variant.title + '<p class="gift-boxes-free">' + limited_text + '</p>';
      }
      else {
      	variant_color.innerHTML = '<br>' + variant.title;
      }
      variant_title.appendChild(variant_color);

      let price_wrapper = document.createElement('div');
      price_wrapper.classList.add('cart__price-wrapper');
      price_wrapper.classList.add('price_matching_item');
      
      matching_form.appendChild(price_wrapper);
      
      if(variant.compare_at_price != null) {
         let variant_compare_price = document.createElement('span');
         variant_compare_price.classList.add('price');
         variant_compare_price.classList.add('compare_price_matching');
         variant_compare_price.classList.add('cart_text');
         variant_compare_price.innerHTML = theme.Currency.formatMoney(variant.compare_at_price,"NO_CURRENCY");
         price_wrapper.appendChild(variant_compare_price);
      }

      let variant_price = document.createElement('span');
      variant_price.classList.add('price');
      variant_price.classList.add('cart_text');
       if(variant.compare_at_price != null) {
        variant_price.classList.add('compare_price_color');
      }
	  if(product.product_type  != 'Gift Boxes & Tins') {
      	variant_price.innerHTML = theme.Currency.formatMoney(variant.price,"NO_CURRENCY");
      }
      else {
      variant_price.innerHTML = 'Free';
      }
      price_wrapper.appendChild(variant_price);
   

      let atc = document.createElement('a');
      atc.classList.add('btn');
      atc.classList.add('btn--alternate');
      atc.classList.add('matching__atc');
      atc.setAttribute('href', variantURL);
      addMatchingItem(atc, variant, is_art_series, is_zodiac_series,false,product.product_type,preorder_text);
      matching_form.appendChild(atc);
      
          
      let adding_atc = document.createElement('a');
      adding_atc.classList.add('btn');
      adding_atc.classList.add('btn--alternate');
      adding_atc.classList.add('adding_atc');
      adding_atc.classList.add('hide');
      adding_atc.setAttribute('href', '#');
      matching_form.appendChild(adding_atc);      

      let atc_text = document.createElement('span');
      atc_text.setAttribute('data-add-to-cart-text', '');
      atc_text.innerHTML = preorder_matching ? "Pre-Order" : cart_add;
      atc.appendChild(atc_text);

      let atc_loader = document.createElement('span');
      atc_loader.setAttribute('data-loader', '');
      atc_loader.classList.add('hide');
      atc.appendChild(atc_loader);

      let atc_loader_svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      atc_loader_svg.classList.add('icon');
      atc_loader_svg.classList.add('icon-spinner');
      atc_loader.appendChild(atc_loader_svg);

      let atc_loader_path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      atc_loader_path.setAttribute('d', 'M7.229 1.173a9.25 9.25 0 1 0 11.655 11.412 1.25 1.25 0 1 0-2.4-.698 6.75 6.75 0 1 1-8.506-8.329 1.25 1.25 0 1 0-.75-2.385z');
      atc_loader_svg.appendChild(atc_loader_path);
      adding_atc.innerHTML = '';
      adding_atc.appendChild(atc_loader_svg);
    }//if matching item ==1 means color or 2 meansfor match tag
    return matching_item;
 }

  //"/recommendations/products.json?product_id=" + itemToMatch.product_id
$.getJSON('/collections/matching-slider/products.json', function(recommendations) {
  const limit = 7; //setting the limit
  var shown = 0;
  let upsell_tag_watch_show = true;
 let upsell_tag_phone_show = true;

  var type=0;
    let compare_shown = 0;
  var matchtag = 0;
  let formatchitem =[];
  let upsellfirst=[];
  let notInProductType=["nothing"];
  
  var recommendedProducts = recommendations.products.filter(function(product) { return checkForMatch(cart, product, itemToMatch); });
  container.innerHTML = "";
  if(recommendedProducts.length > 0) {
  document.querySelector('.cart__matching').classList.remove('hide');
  recommendedProducts.map(function(product) {
    let upsell_tag = false;
    let upsell_tag_watch = false;
    let forMatch_tag = false;
    let sameColour = false;
    let render = null;
    let model = null;
        let notincart =true;
        let disney_color = false;
    let notincart2 =true;
    let phone_cases_qty = 0;
    let card_qty = 0;
    
 let gift_box = false;
    let gift_box_render = false;

    if(!(product.tags.indexOf(forNotMatchTag) != -1)) {	 //for airpods / not match tag check 
        upsell_tag = product.tags.indexOf(upsellTag) != -1;

     	upsell_tag=false;
     for(var x=0; x < cart.items.length;x++) {

      if(cart.items[x].product_title.includes('13') || cart.items[x].product_title.includes('14') || cart.items[x].product_title.includes('SE') || cart.items[x].product_title.includes('11') || cart.items[x].product_title.includes('12') || cart.items[x].product_title.includes('7/8') || cart.items[x].product_title.includes('XS') || cart.items[x].product_title.includes('XR')) {
        if(upsell_tag == false) {
        model= cart.items[x].product_title;
        }
        upsell_tag=true;
        	
        }
       if(cart.items[x].product_type.includes('Apple Watch') ) {
        upsell_tag_watch=true;
          
        }
      }
      
      for(var x=0; x < cart.items.length;x++) { 
    //  console.log(cart.items[x]);
        if(cart.items[x].handle.includes('easy-apply-screen-protector-1')){
        	notincart = false;
        }
        if(cart.items[x].handle.includes('apple-watch-screen-protector')){
          notincart2 = false;
        }
      	
      }
     if(!upsell_tag || !upsell_tag_watch || shown != compare_shown || (!notincart)  || (!notincart2)){ 

        sameColour = product.options[0].values.indexOf(colour) != -1;
      if(sameColour && product.tags.indexOf(forMatchTag) != -1) {
        for(var i=0;i<product.variants.length;i++){
          if((!product.variants[i].available) && product.variants[i].option1 == colour){
           	sameColour=false;
     
          }
        }
       
      }
      	
    }
            if(product.product_type.includes('Watch')){
        sameColour =true;
      }
    if(!sameColour){
        forMatch_tag = product.tags.indexOf(forMatchTag) != -1;
     }


   disney_color = checkDisneycolor(colour);

   if((sameColour || disney_color ) && shown < limit ) {
      if (product.product_type != "Airpods") {
       notInProductType[type++]=product.product_type;
     }
       render = renderProduct(product,1);
     
   }
      if(shown < limit && upsell_tag && shown <= 2 && notincart && upsell_tag_phone_show ) {
  render = renderProduct(product,0,model);
     if(product.handle.includes('easy-apply-screen-protector-1')) {
       shown += 1;
       upsell_tag_phone_show  = false;
      }
    }
       if(shown < limit && upsell_tag_watch && upsell_tag_watch_show &&  shown <=2 && notincart2) {
		console.log('erere');
       render = renderProduct(product,0,'watch_protector');
      if(product.handle.includes('apple-watch-screen-protector')) {
       shown += 1;
       upsell_tag_watch_show = false;
      }
    }
   if(shown < limit  && forMatch_tag ) {
     formatchitem[matchtag++] = renderProduct(product,2);
    }
    if(render != null) {
      
      if((!gift_box_render) ) {
        shown += 1;
      }

      container.appendChild(render);
    }
    }
 });
}
else {
  $('.cart__has-items').addClass('hide');
  } 

var formatchcounter=shown;
var formatchFound=false;
if(formatchitem !=null) {
  for(var i=0; formatchcounter < limit ;i++){

    if(formatchitem.length>i) {
       container.appendChild(formatchitem[i]);
        formatchFound=true;
  
    }
     formatchcounter += 1;

  }
  //container.appendChild(formatchitem);
}
if(upsellfirst !=null) {
    container.prepend(upsellfirst);
}
if(shown == 0 && (!formatchFound)) {
	document.querySelector('.cart__matching').classList.add('hide');
}
});
  if(container.childElementCount === 0) {
    container.parentElement.classList.add('hide');
    $('.cart__matching').addClass('hide');
  }
  
  $('.cart__matching').removeClass('hide');
}
function checkDisneycolor(col) {
   if(col.includes('Pluto') || col.includes('Donald') || col.includes('Daisy') || col.includes('Mickey') || col.includes('Minnie') || col.includes('Goofy') || col.includes('Tempered') ) {

	return true;
}
  return false;
}

function checkdisneycolour(col) {

  if(col.includes('Pluto')) {
	return 'Emerald Green';
}
  if(col.includes('Donald')) {
  	return 'Sky Blue';
  }
  if(col.includes('Daisy')) {
  	return 'Lavender Purple';
  }
  if(col.includes('Mickey')) {
  	return 'Pomegranate Red';
  }
  if(col.includes('Minnie')) {
  	return 'Pink Lily';
  }
  if(col.includes('Goofy')) {
  	return 'Manhattan Orange';
  }
  
  return col;
}
function calcCompareAtPrice(product) {
  var varID = product.variant_id;
  var comparePrice;
  $.ajax({
    url: '/products/' + product.handle + '.js',
    dataType: 'json',
    async: false,
    success: function(product){
      product["compare_at_price"] = 0;
      product.variants.forEach(function(variant) {
        if ( variant.id == varID && variant.compare_at_price !== 0){
          comparePrice = variant.compare_at_price;
        }
      });
    }

  });
   return comparePrice;
}

$('#bundles,#bundles_1').click(function(){
  	$(this).html('<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-spinner" viewBox="0 0 20 20"><path d="M7.229 1.173a9.25 9.25 0 1 0 11.655 11.412 1.25 1.25 0 1 0-2.4-.698 6.75 6.75 0 1 1-8.506-8.329 1.25 1.25 0 1 0-.75-2.385z" fill="#919EAB"></path></svg>');
  	//$('#bundles svg').removeClass('hide');
  
     var monogram1 =$('.customizer__text--preset').text();
  var monogram2 =$('.customizer__text--preset').text();
  var monogram3= $('.customizer__text--preset').text();
    if($('.p-type').text().includes('Style')) {
      if(monogram1.length > 1) {
      monogram2 = monogram1[0] + monogram1[1];
      }
      $('.js-form-discount').val('Style_Set');
    }
    if($('.p-type').text().includes('Go-to')) {
      if(monogram1.length > 1) {
      monogram2 = monogram1[0] + monogram1[1];
      }
       if(monogram1.length >2) {
      	monogram2 = monogram1[0] + monogram1[1] + monogram1[2];
      }
      $('.js-form-discount').val('Go-to_Set');
    }
    if($('.p-type').text().includes('Tech')) {
      if(monogram1.length > 1 && monogram1.length <=2) {
        monogram3 = monogram1[0] + monogram1[1];
        monogram1 = monogram1[0] + monogram1[1];
      }
       if(monogram1.length > 2 || checkDot(monogram1)) {
         console.log(monogram1);
      	monogram3 = monogram1[0] + monogram1[1] + monogram1[2];
        
         if(checkDot(monogram1)) {
            monogram1 = monogram1[0] + monogram1[1] + monogram1[2];
         }
         else {
           monogram1 = monogram1[0] + monogram1[1];}
      }
      $('.js-form-discount').val('Tech_Set');
    }
    if($('.p-type').text().includes('Twin')) {
      $('.js-form-discount').val('Twin_Set');
    }
    if($('.p-type').text().includes('Essentials')) {
      if(monogram1.length > 1) {
      monogram3 = monogram1[0] + monogram1[1];
        
      }
        if(monogram1.length >2) {
      	monogram3 = monogram1[0] + monogram1[1] + monogram1[2];
      }
      $('.js-form-discount').val('Essentials_Set');
    }
  if($('.customizer__text--preset').text().length <= 0){
    monogram1 = monogram2 = monogram3 = '';
  }
   if(monogram1[1] == 'undefined' || monogram1[1] == null || monogram1[1].length == 0 && (monogram1[0] != null )){

  	monogram2 =  monogram3 = monogram1[0];
  }
 
  
//   if(localStorage.getItem('mdsEngraving').length == 1){
//     monogram1 = monogram2 = monogram3 = localStorage.getItem('mdsEngraving');
//   }
    var foil = 'gold';
    if(localStorage.getItem('mdsFoil') != null) {
      foil = localStorage.getItem('mdsFoil').toLowerCase();
    }
    var selected_color = $('.color-list input:checked').val();
    var select_size_1 = $('.bundles_size_1').children("option:selected").val();
    var index_1 = $(".product-1-color[data-variant='"+selected_color+"'][data-size='"+select_size_1+"']").data("index");
    var variant_1 = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("variant");
  if($('.product-sizes-watch').length > 0 ) {
    var variant_option_1 = $('.product-sizes-watch').find(":selected").text();
    if(variant_option_1.includes('42/44/45')) {
      index_1 = index_1 + 11;
    }
    variant_1 = $(".product-1-id[data-index='"+index_1+"'][data-variant1='"+variant_option_1+"'][data-size='"+select_size_1+"']").data("variant");

}
    var select_size_2 = $('.bundles_size_2').children("option:selected").val();
    var index_2 = $(".product-2-color[data-variant='"+selected_color+"'][data-size='"+select_size_2+"']").data("index");
    var variant_2 = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("variant");
    var variant_1_available = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("available");
    var variant_2_available = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("available");

    var variant_1_preorder = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("preorder");

    var variant_2_preorder = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("preorder");
  var pre1,pre2,pre3 = null;
  if(variant_1_preorder) {
    pre1 = 'Ships from 30th September';
  }
  if(variant_2_preorder) {
    pre2 = 'Ships from 30th September';
  }
    if($('.product-3-id').length > 0) {  
      var select_size_3 = $('.bundles_size_3').children("option:selected").val();
      var index_3 = $(".product-3-color[data-variant='"+selected_color+"'][data-size='"+select_size_3+"']").data("index");
      var variant_3 = $(".product-3-id[data-index='"+index_3+"'][data-size='"+select_size_3+"']").data("variant");
      var variant_3_preorder = $(".product-3-id[data-index='"+index_3+"'][data-size='"+select_size_3+"']").data("preorder");


  if(monogram1[1] == 'undefined' || monogram1[1] == null || monogram1[1].length == 0 && (monogram1[0] != null )){

  	monogram2 =  monogram3 = monogram1[0];
  }

  if(variant_3_preorder) {
    pre3 = 'Ships from 30th September';
  }


   
  $.post('/cart/add.js', {
            'items': [{
            'id': variant_1,
            'quantity': 1,
            properties: {
                'Text': monogram1,
                 'Foil Color':foil,
                 'Pre-order': pre1,
              }
            },
            {
            'id': variant_2,
            'quantity': 1,
             properties: {
                'Text': monogram2,
                'Foil Color':foil,
                'Pre-order': pre2,
              }
            },
            {
            'id': variant_3,
            'quantity': 1,
             properties: {
                'Text': monogram3,
                'Foil Color':foil,
                'Pre-order': pre3,

              }
            }]
             
            }, function(item) {
              
              $('button[name="checkout"]').trigger('click');
              loadCart(0);
            }, "json");
    }
    else {
      $.post('/cart/add.js', {
            'items': [{
            'id': variant_1,
            'quantity': 1,
            properties: {
                'Text': monogram1,
                 'Foil Color':foil,
                 'Pre-order': pre1
              }
            },
            {
            'id': variant_2,
            'quantity': 1,
             properties: {
                'Text': monogram2,
                'Foil Color':foil,
                'Pre-order': pre2
              }
            }]
             
            }, function(item) {
              $('button[name="checkout"]').trigger('click');
              loadCart(0);
            }, "json");
    }
});

$('.bundles_size_1,.bundles_size_2,.bundles_size_3').on('change', function() {
  const terms = ["7", "SE", "XS","XR"];
  const result1 = terms.some(term => $('.bundles_size_1').children("option:selected").val().includes(term));
  const result2 = terms.some(term =>  $('.bundles_size_2').children("option:selected").val().includes(term));
  if(result1 || result2) {
    $('.limited-edition-color').addClass('hide');
    $('label[for="customizer-color_manhattan-orange"]').addClass('hide');
    $('label[for="customizer-color_bondi-blue"]').addClass('hide');
    $('label[for="customizer-color_shibuya-fuchsia"]').addClass('hide');
    $('#color-black-caviar').trigger('click');
  }
  else {
    $('.limited-edition-color').removeClass('hide');
    $('label[for="customizer-color_manhattan-orange"]').removeClass('hide');
    $('label[for="customizer-color_bondi-blue"]').removeClass('hide');
    $('label[for="customizer-color_shibuya-fuchsia"]').removeClass('hide');
  }
    var selected_color = $('.color-list input:checked').val();
    var select_size_1 = $('.bundles_size_1').children("option:selected").val();
    var index_1 = $(".product-1-color[data-variant='"+selected_color+"'][data-size='"+select_size_1+"']").data("index");
    var select_size_2 = $('.bundles_size_2').children("option:selected").val();
    var index_2 = $(".product-2-color[data-variant='"+selected_color+"'][data-size='"+select_size_2+"']").data("index");
    var variant_1_available = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("available");
    var variant_2_available = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("available");
    var variant_1_preorder = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("preorder");

    var variant_2_preorder = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("preorder");

    if($('.product-3-id').length > 0) {  
          var select_size_3 = $('.bundles_size_3').children("option:selected").val();

          var index_3 = $(".product-3-color[data-variant='"+selected_color+"'][data-size='"+select_size_3+"']").data("index");

          var variant_3_preorder = $(".product-3-id[data-index='"+index_3+"'][data-size='"+select_size_3+"']").data("preorder");

          
        }
   if(variant_1_preorder || variant_2_preorder || variant_3_preorder) {
         $('#bundles').addClass('hide');
          $('#bundles_1').removeClass('hide');
          $('#bundles_0').addClass('hide');
          $('.pre-order-text').removeClass('hide');
   }
   else {
    $('.pre-order-text').addClass('hide');
    if(!variant_1_available || !variant_2_available) {
          $('#bundles').addClass('hide');
          $('#bundles_0').removeClass('hide');
          $('#bundles_1').addClass('hide');
        }
        else {
                    $('#bundles_1').addClass('hide');

          $('#bundles_0').addClass('hide');
           $('#bundles').removeClass('hide');
        }
    }
  });




let valGiftQty = 0;

function valetineGiftCheck(product,valGiftCounter,i) {

 valGiftCounter[0] = valGiftCounter[0] + product.quantity;
  return  0;
}


// hasMatchingItems
// 0 means load a new set of items
// 1 keep old set and don't hide
// 2 hide matching items
// matchingfilter
// 0 mean upsell
// 1 color
// 2 mean specific tag
function updateCartItems(cart, hasMatchingItems) {
 let valGiftCounter = new Array(1);
 valGiftCounter.fill(0);
 let valInCart = false;
 let valInCart2 = false;
 let valInCart3 = false;
 let alreadyIncart = false;
 let addFreeItem=false;

 let valId = "41108196393142";
 let valId3 = "41108196425910";
 let valId2 = "3955601139320ddd6";
  let card_id = "";
 let valQty = 0;
 let val2Qty = 0;
 let val3Qty = 0;
    let emerald=0;
  let gift_outer = null;
    var gift_counter = 0; 
  let gift_line_item = new Array(15);
 let counter=0;
let card_qty = 0;
let phone_cases_qty = 0;
    let protector_is = 0;
  let card_qty_id = 0;
  let pro_var_id = ''; 
  let phone_case = false;
    let sticker_qty = 0;
    for(var x=0; x < cart.items.length;x++) {
      //console.log(cart.items[x]);
 if(cart.items[x].variant_options[0].includes('Emerald')){ 
      emerald = 1;
      }
       if(cart.items[x].handle.includes('disney-leather-sticker')){ 
      sticker_qty = cart.items[x].quantity + sticker_qty;
      }
      if(cart.items[x].id == valId){
         valInCart = true;
         valQty = cart.items[x].quantity;
        }
      if(cart.items[x].id == valId2){
         valInCart2 = true;
         val2Qty = cart.items[x].quantity;
        }
      if(cart.items[x].id == valId3){
         valInCart3 = true;
         val3Qty = cart.items[x].quantity;
        
        }
      if(cart.items[x].handle.includes('easy-apply-screen-protector-1')) {
          protector_is = cart.items[x].quantity;
        pro_var_id = cart.items[x].variant_id;
         }
       if(cart.items[x].product_type == 'Phone Case' || cart.items[x].product_type == 'Sling Phone Case' || cart.items[x].product_type == 'Silicone Phone Case'){
         phone_case = true;
        }
      if(cart.items[x].product_title.includes('Day Card')){
          card_qty = card_qty + cart.items[x].quantity;
                  card_qty_id = cart.items[x].variant_id;

        
        }
        if(cart.items[x].product_title.includes('Phone')){
          phone_cases_qty = phone_cases_qty + cart.items[x].quantity;
        }
      }


  if(protector_is > 0 && phone_case == false ) {
  		$.post('/cart/change.js', {
          quantity: 0,
          id: pro_var_id,
          properties: ""
        }, function(item) {
          loadCart(0);
        }, "json");
  }
  if(sticker_qty !=0 && cart.item_count == sticker_qty) {
  $.post('/cart/clear.js',function(cart) {
            updateCartItems(cart,2);
          },"json");
  }
   if(card_qty > 0 && phone_case == false ) {
      $.post('/cart/change.js', {
          quantity: 0,
          id: card_qty_id,
          properties: ""
        }, function(item) {
          loadCart(0);
        }, "json");
  }
  if(card_qty > phone_cases_qty && phone_case  ) {
      $.post('/cart/change.js', {
          quantity: phone_cases_qty,
          id: card_qty_id,
          properties: ""
        }, function(item) {
          loadCart(0);
        }, "json");
  }
  let caritemCount = cart.item_count;
  if(alreadyIncart) {
    caritemCount = caritemCount - 1;
  }


  let matchingFilter=0;
  let total_save = 0;
  const cartMenu = document.querySelector('#cartMenu');
  const cartContents = cartMenu.querySelector('.cart__contents');
  const emptyCartContents = cartMenu.querySelector('.emptycart__contents');
  const matchingItems = cartMenu.querySelector('.cart-matching-slider');
  const cartPrice = cartMenu.querySelector('.cart-subtotal__price');
  const ap_Price = cartMenu.querySelector('.cart-ap-price');
  const cartDiscount = cartMenu.querySelector('.cart-discount');
  var cart_price = theme.Currency.formatMoney(cart.total_price, theme.moneyFormat);
  if(cartContents != null) {
    cartContents.innerHTML = "";
    emptyCartContents.innerHTML="";
    
  }
  $('[data-cart-count]').text(cart.item_count);
  if(cart.items.length > 0) {
    $('.main_emptycart').addClass('hide');
    $('[data-cart-count-bubble], .cart__has-items, .checkout-wrap, .cart-banner').removeClass('hide');
    for(var i = cart.items.length-1; i>=0; i--) {
      let line_item = cart.items[i];
      valGiftCounter = valetineGiftCheck(line_item,valGiftCounter,i);
      let pop_up = false;
      let small_leather_limit =0;
      if($('#gift_redirect').length == 0) {
        small_leather_limit =0.5;
      }
        for(var pop = 0; pop < valGiftCounter.length; pop++) {
          if(valGiftCounter[pop] > small_leather_limit ){
            pop_up = true;
            break;
          }
        }
        if( pop_up && i==0 && !valInCart && !valInCart2 && !valInCart3){
         // $('.valentine_card').fadeIn(400);
         if($('#bp_gift').length > 0 || $('.lp-product-1').length > 0) { }
        else {
         if($('#gift_redirect').length > 0 ) {
            $('.btn--val').trigger('click');
          }
         else {
            $('.valentine_card').fadeIn(400);
            $('.checkout-wrap').addClass('borderunset');
         }
       }
        }
        else if(i==0 && (valInCart || valInCart2 || valInCart3) || !pop_up ){
          $('.valentine_card').fadeOut(400);
           $('.checkout-wrap').removeClass('borderunset');
        }
      let props = line_item.properties;
      let cart_item = document.createElement('div');
       let compare_at_price = calcCompareAtPrice(line_item);
       if(compare_at_price > line_item.original_price) {
        total_save = total_save + (compare_at_price - line_item.original_price)* line_item.quantity;
       }

      if(cart.items[i].product_type=="Gift") {
       if(cart.item_count==1) {
            $.post('/cart/clear.js',function(cart) {
            updateCartItems(cart,2);
          },"json");
        }
      } //gifting ends here
      else {
  
        cart_item.classList.add('cart__item');
        
		if(!line_item.product_type.toLowerCase() == 'gift card') {
        cart_item.classList.add(line_item.product_type.toLowerCase().replace(/ /g, '-'));
       }
        cart_item.classList.add('item' + i.toString());
        cart_item.classList.add('border-bottom');
        cartContents.appendChild(cart_item);
        
        let loading_cart = document.createElement('div');
        loading_cart.classList.add('cart__loading');
        loading_cart.classList.add('hide');
        var loading_icon = '<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-spinner" viewBox="0 0 20 20"><path d="M7.229 1.173a9.25 9.25 0 1 0 11.655 11.412 1.25 1.25 0 1 0-2.4-.698 6.75 6.75 0 1 1-8.506-8.329 1.25 1.25 0 1 0-.75-2.385z" fill="#919EAB"></path></svg>';
        loading_cart.innerHTML = loading_icon;
        cart_item.appendChild(loading_cart);

        let cart_remove = document.createElement('div');
        cart_remove.classList.add('cart__remove');
        cart_item.appendChild(cart_remove);

        let cart_remove_btn = document.createElement('a');
        cart_remove_btn.setAttribute('href', window.location.origin + '/cart/change?line=' + i.toString() + '&amp;quantity=0');
        var trash ='<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1080 1080" style="enable-background:new 0 0 1080 1080;" xml:space="preserve">';
	  	trash = trash + '<g id="Layer_1" class="st0">';
	  	trash = trash + '<path class="trash1" d="M208.3,205.1l53.3,758.2c1.8,19.6,16.8,34.6,34.7,34.6h244.2h244.2c17.9,0,32.9-14.9,34.7-34.6l53.3-758.2"/>';
    	trash = trash + '<path class="trash2" d="M907.6,206.1H540.5c0,0-367.1,0-367.1,0"/><path class="trash1" d="M672.9,206.1v-42.6c0-36.7-26.9-66.5-60.2-66.5h-72.2h-72.2c-33.2,0-60.2,29.8-60.2,66.5v42.6"/>';
		trash = trash + '<line class="trash3" x1="540.5" y1="343" x2="540.5" y2="860.5"/><line class="trash3" x1="692.9" y1="343" x2="672.9" y2="860.5"/><line class="trash3" x1="388.1" y1="343" x2="408.1" y2="860.5"/>';
    	trash=trash+ '</g> </svg>';
    	cart_remove_btn.innerHTML = ' ' +trash;
        cart_remove.appendChild(cart_remove_btn);
        setQty(cart_remove_btn, i, null, 0,1);

      let engraving = '';
      let foil = '';
      let art = '';
      let zod = '';
      let v = '';
     
      if(props != null) {
        
        if(props['Foil Color'] != null) {
          foil = props['Foil Color'];
        }
        if(props['Text'] != null) {
          engraving = props['Text'];
        }

        if(props['Zodiac'] != null) {
          zod = props['Zodiac'];
        }

      }
        let cart_item_image = document.createElement('div');
        cart_item_image.classList.add('cart__item__image');
        cart_item.appendChild(cart_item_image);

        let image_link = document.createElement('a');
        image_link.classList.add('product-image-fix');
        if(! (line_item.product_type.includes('Screen') || line_item.product_type.includes('Gift'))) {
          image_link.setAttribute('href', line_item.url);
        }
        cart_item_image.appendChild(image_link);
        
 

        let image_wrapper = document.createElement('div');
        image_wrapper.classList.add('relative');
        image_link.appendChild(image_wrapper);

        let item_image = document.createElement('img');
        item_image.classList.add('active');
        item_image.setAttribute('src', line_item.featured_image.url.replaceAll('.jpg', '_360x.jpg'));
        image_wrapper.appendChild(item_image);

        if(art != '') {
          let image_text = document.createElement('div');
          image_text.classList.add('cart-engrave');
          image_text.classList.add('artwork-engrave');
          image_text.classList.add(line_item.product_type.toLowerCase().replace(/ /g, '-'));
          image_text.classList.add(art.toLowerCase().replace(/ /g, '-'));
          image_wrapper.appendChild(image_text);
        } else if(zod != '') {
          let image_text = document.createElement('div');
          image_text.classList.add('cart-engrave');
          image_text.classList.add('zodiac-engrave');
          image_text.classList.add(line_item.product_type.toLowerCase().replace(/ /g, '-'));
          image_text.classList.add(zod.toLowerCase().replace(/ /g, '-').replace("'",''));
          image_text.classList.add(foil.toLowerCase().replace(' ', '-'));
          image_wrapper.appendChild(image_text);

        } else {
          if(engraving != '' && foil != '') {
            let image_text = document.createElement('div');
            image_text.classList.add('cart-engrave');
            image_text.classList.add('icon-chess-piece');
            image_text.classList.add('engrave');
            image_text.classList.add(line_item.product_type.toLowerCase().replace(/ /g, '-'));
            image_text.classList.add(foil.toLowerCase().replace(' ', '-'));
            image_text.innerHTML = engraving;
            image_wrapper.appendChild(image_text);

            
          }
          if(v != '') {
              let valentine_text = document.createElement('div');
              valentine_text.classList.add('cart-engrave');
              valentine_text.classList.add('engrave');
              valentine_text.classList.add('valentine-engrave');
              if(foil.toLowerCase().replace(/ /g, '-') == 'gold') {
                  valentine_text.classList.add('silver');
                  valentine_text.classList.add('fake');
              }
              else {
                valentine_text.classList.add(foil.toLowerCase().replace(/ /g, '-'));
            }
              valentine_text.classList.add('him-her');
              image_wrapper.appendChild(valentine_text);
            }
        }

        let item_details = document.createElement('div');
        item_details.classList.add('cart__item__details');
                		item_details.classList.add(line_item.product_type.split(" ")[0]);

        cart_item.appendChild(item_details);

        let title_link = document.createElement('a');
        title_link.classList.add('cart__product-title');
        title_link.classList.add('md_text');
        title_link.classList.add('bold');
        if(! (line_item.product_type.includes('Screen') || line_item.product_type.includes('Gift'))) {
          title_link.setAttribute('href', line_item.url);
        }
         if(line_item.gift_card) {
          title_link.innerHTML = line_item.product_title;
        } 
        else if ( line_item.product_type.includes('Screen')) {
            title_link.innerHTML = line_item.title.replace(' - ','<br><span class="cart_text">');

        }
        else if(line_item.product_type.includes('Gift Boxes') && (!line_item.url.includes('love-club'))) {
           title_link.innerHTML = line_item.product_title + '<br> <p class="free_gift"> Free <span>' + theme.Currency.formatMoney(compare_at_price,"NO_CURRENCY")  + '</span></p><p class="free-price"> Complimentary Free Express Shipping </p>';
        }
        else {
   			  title_link.innerHTML = line_item.title.replace(/-/,'<br><span class="cart_text">');
        	}
        item_details.appendChild(title_link);

        let item_price_wrapper = document.createElement('div');
        item_price_wrapper.classList.add('cart__price-wrapper');
        item_price_wrapper.classList.add('cart_text');
        item_details.appendChild(item_price_wrapper);


        let item_price = document.createElement('span');
        item_price.classList.add('price');
        item_price.classList.add('cart_text');
        item_price.innerHTML = theme.Currency.formatMoney(line_item.original_price,"NO_CURRENCY"); // original_line_price
        item_price_wrapper.appendChild(item_price);
		if(compare_at_price > line_item.original_price) {
          item_price_wrapper.classList.add('cart__price-wrapper_discount');
          let item_price_discount = document.createElement('span');
          item_price_discount.classList.add('price');
          item_price_discount.classList.add('compare_price');
          item_price_discount.innerHTML = theme.Currency.formatMoney(compare_at_price,"NO_CURRENCY"); // original_line_price
          item_price_wrapper.appendChild(item_price_discount);
          let price_discount = line_item.original_price / compare_at_price;
          let percent_off = 1 - price_discount;
          let item_percent_discount = document.createElement('span');
          item_percent_discount.classList.add('discount_percent');
          item_percent_discount.innerHTML = Math.round(percent_off * 100) + '% OFF';
          item_price_wrapper.appendChild(item_percent_discount);
        }
        if(props != null) {
          let cart_props = document.createElement('div');
          cart_props.classList.add('cart__props');
          item_details.appendChild(cart_props);

          if(props['Artwork'] != null) {
            let cart_props_artwork = document.createElement('div');
            cart_props_artwork.classList.add('cart__prop');
            cart_props_artwork.classList.add('cart_text');
            cart_props.appendChild(cart_props_artwork);

            let cart_props_artwork_name = document.createElement('span');
            cart_props_artwork_name.innerHTML = "Artwork:";
            cart_props_artwork.appendChild(cart_props_artwork_name);

            let cart_props_artwork_text = document.createElement('span');
            cart_props_artwork_text.innerHTML = art;
            cart_props_artwork.appendChild(cart_props_artwork_text);
          } else if(props['Zodiac'] != null && props['Zodiac'] != '') {
            let cart_props_zodiac = document.createElement('div');
            cart_props_zodiac.classList.add('cart__prop');
            cart_props_zodiac.classList.add('cart_text');
            cart_props.appendChild(cart_props_zodiac);

            let cart_props_zodiac_name = document.createElement('span');
            cart_props_zodiac_name.innerHTML = "Personalization:";
            cart_props_zodiac.appendChild(cart_props_zodiac_name);

            let cart_props_zodiac_text = document.createElement('span');
            cart_props_zodiac_text.innerHTML = zod;
            cart_props_zodiac.appendChild(cart_props_zodiac_text);

            if(props['Foil Color'] != null) {
              let cart_props_foil = document.createElement('div');
              cart_props_foil.classList.add('cart__prop');
              cart_props_foil.classList.add('cart_text');
			cart_props_zodiac.appendChild(cart_props_foil);

              

              let cart_props_foil_text = document.createElement('span');
              cart_props_foil_text.classList.add('cart-colour');
              
              cart_props_foil_text.classList.add(foil.toLowerCase().replace(' ', '-'));
cart_props_zodiac.appendChild(cart_props_foil_text);            }
          } else {
            if(props['Text'] != null && engraving != '') {
              let cart_props_engraving = document.createElement('div');
              cart_props_engraving.classList.add('cart__prop');
              cart_props_engraving.classList.add('cart_text');
              cart_props.appendChild(cart_props_engraving);

              let cart_props_engraving_name = document.createElement('span');
              let cart_props_foil_text = document.createElement('span');
              cart_props_engraving_name.innerHTML = "Personalization:";
              cart_props_engraving.appendChild(cart_props_engraving_name);

              let cart_props_engraving_text = document.createElement('span');
              cart_props_engraving_text.classList.add('text-upper');
              cart_props_engraving_text.innerHTML = engraving != '' ? engraving : 'No Personalization';
              cart_props_foil_text.classList.add('cart-colour');
              cart_props_engraving_text.classList.add('chess_text');
              if(foil.toLowerCase().replace(' ', '-') != '') {
             	 cart_props_foil_text.classList.add(foil.toLowerCase().replace(' ', '-'));
              }
              cart_props_engraving.appendChild(cart_props_engraving_text);
              cart_props_engraving.appendChild(cart_props_foil_text);
            }

          }
          if(props['Pre-order'] != null && props['Pre-order'].length>0) {
            let cart_props_preorder = document.createElement('div');
            cart_props_preorder.classList.add('cart__prop');
            cart_props_preorder.classList.add('cart_text');
            cart_props.appendChild(cart_props_preorder);

            let cart_props_preorder_name = document.createElement('span');
            cart_props_preorder_name.innerHTML = "Preorder:";
            cart_props_preorder.appendChild(cart_props_preorder_name);

            let cart_props_preorder_text = document.createElement('span');
            cart_props_preorder_text.innerHTML = props['Pre-order'];
            cart_props_preorder.appendChild(cart_props_preorder_text);
          }
        }
       
if(!line_item.product_type.includes('Gift Boxes')) {
        let item_qty = document.createElement('div');
        item_qty.classList.add('cart__qty');
        item_details.appendChild(item_qty);

        let qty_num = document.createElement('span');
        qty_num.classList.add('qty-num');
        qty_num.innerHTML = line_item.quantity;
        qty_num.dataset.qty = line_item.quantity;

        let qty_down = document.createElement('a');
        qty_down.classList.add('qty-btn');
        qty_down.classList.add('qty-down');
        qty_down.innerHTML = "-";
        qty_down.setAttribute('href', 'javascript:void(0);');
        item_qty.appendChild(qty_down);
        setQty(qty_down, i, qty_num, -1,1);
        item_qty.appendChild(qty_num);

        let qty_up = document.createElement('a');
        qty_up.classList.add('qty-btn');
        qty_up.classList.add('qty-up');
        qty_up.innerHTML = "+";
        qty_up.setAttribute('href', 'javascript:void(0);');
        item_qty.appendChild(qty_up);
        setQty(qty_up, i, qty_num, 1,1); //last 1 is for color filter
      }
      }

     $('.btn--val').removeClass('hide');
     $('.btn--val-load').addClass('hide');
     var small_leather = valGiftCounter[0] + valGiftCounter[1] + valGiftCounter[2];
     if($('#gift_redirect').length == 0) {
      small_leather = valGiftCounter[0];
     }
     if(small_leather > 0) {
      $('.btn--val').attr('data-val','true');
      if((!valInCart) && (valInCart3 || valInCart2) && i == 0) {
       }
      else if(valInCart && small_leather != valQty && i == 0 ) {
      }
     }
     else {
      $('.btn--val').attr('data-val','false');
     }
     if(valGiftCounter[3] > 0 ) {
      $('.btn--val').attr('data-val1','true');
      if((!valInCart2) && (valInCart || valInCart3) && i == 0) {
       }
      else if(valInCart2 && valGiftCounter[3] != val2Qty && i == 0 ) {
      }
     }
     else {
      $('.btn--val').attr('data-val1','false');
     }
     if(valGiftCounter[4] > 0 ) {
      $('.btn--val').attr('data-val2','true');
      if((!valInCart3) && (valInCart || valInCart2) && i == 0) {
         // addFreeGift(valId3);
       }
      else if(valInCart3 && valGiftCounter[4] != val3Qty && i == 0 ) {
      }
     }
     else {
      $('.btn--val').attr('data-val2','false');
     }
     if(pop_up && i==0 && (valInCart || valInCart2 || valInCart3)) {
      // valGiftItem(cartContents,line_item,small_leather +  valGiftCounter[3] + valGiftCounter[4]);
       $('.valentine_card').fadeOut(400);
     }
     if(!pop_up && $('.valentine_card').is(':visible') ) {
      	$('.valentine_card').fadeOut(400);
     }
     if(small_leather <= small_leather_limit && i==0 && valInCart) {
      $.post('/cart/change.js', {
          quantity: 0,
          id: valId,
          properties: ""
        }, function(item) {
         loadCart(0);
        }, "json");
     }
     if(valGiftCounter[3] <= 0 && i==0 && valInCart2) {
      $.post('/cart/change.js', {
          quantity: 0,
          id: valId2,
          properties: ""
        }, function(item) {
         loadCart(0);
        }, "json");
     }
     if(valGiftCounter[4] <= 0 && i==0 && valInCart3) {
      $.post('/cart/change.js', {
          quantity: 0,
          id: valId3,
          properties: ""
        }, function(item) {
         loadCart(0);
        }, "json");
     }
    }
     if(cartPrice != null) {
      var itemCounter = cart.item_count;
       ap_Price.innerHTML=cart.total_price/400;
      if(total_save > 0 ) {
    cartPrice.innerHTML = cart_price;
       }
       else {
         cartPrice.innerHTML = cart_price;
         cartDiscount.classList.add('hide');
       }
       if(emerald > 0 ) {
      // $('.cart-banner p:first-child').addClass('hide');
      $('.cart-banner p:not(:first-child)').removeClass('hide');

      }
      else {
       $('.cart-banner p:first-child').removeClass('hide');
           $('.cart-banner p:not(:first-child)').addClass('hide');
      
      }
        if(itemCounter >= 2 ) {
            $('.progressbar__cart--fill').addClass('full-bar');
           
            $('.progressbar__cart--fill').removeClass('full-bar-down');
        }
        else if(cart.item_count == 1 ) {
          if($('.progressbar__cart--fill').hasClass('full-bar')) {
                $('.progressbar__cart--fill').removeClass('full-bar');
                $('.progressbar__cart--fill').addClass('full-bar-down');
          }
          else {
                $('.progressbar__cart--fill').removeClass('full-bar-down');
          }
               
          	  
      }
        else {
           $('.progressbar__cart--fill').removeClass('full-bar-down');
           $('.progressbar__cart--fill').removeClass('full-bar');

        }
  	}

    if(hasMatchingItems == 0) {
      $( ".cart-matching-slider" ).scrollLeft(0);
      getMatchingItems(matchingItems, cart);
    } else if(hasMatchingItems == 1) {
      // do nothing
    } else if(hasMatchingItems == 2) {
      $('.cart__matching').addClass('hide');
    }
  } else {
    $('.cart__has-items, .checkout-wrap, .cart-banner').addClass('hide');
    cartContents.innerHTML = '';
    emptyCartContents.innerHTML =$('.main_emptycart').html();
    emptyCartContents.classList.remove('hide');
  }
}

function setQty(btn, key, qty_num, to_add,filterMatchingItems) {
   if(filterMatchingItems==0){
  	 localStorage.setItem('puzzleDelete','true');
    }
    btn.addEventListener('click', function(e) {
    if($(this).hasClass('qty-btn')) {
      $(this).parent().parent().parent().addClass('cart_loading');
      $(this).parent().parent().parent().find('.cart__loading').removeClass('hide');
    }
    else {
        $(this).parent().parent().addClass('cart_loading');
        $(this).parent().parent().find('.cart__loading').removeClass('hide');
    }
    e.preventDefault();
    let qty = to_add;
    if(qty_num != null) {
      qty = parseInt(qty_num.dataset.qty) + parseInt(to_add);
    }
    // show cart loader
    $.post('/cart/change.js', { quantity: qty, line: key + 1 }, function(cart) {
      updateCartItems(cart, 0);
      var shippingtext = $('#min_shipping').attr('data-varlu');
      $(this).find('.dyn_price').text(shippingtext);
       var final_total = cart.total_price.toFixed(2) / 100
        if(final_total < shippingtext){
        var diff_price = Math.round(shippingtext - final_total);
         $(".fullprogressbar").addClass('hide');
        $(".customprogressbar").removeClass('hide'); 
         $('.progress-bar__fill').removeClass('full-bar');
         $('.progress-bar__fill').addClass('full-bar-down');
          $('.dyn_price').html(diff_price);
          
        }
        else {
          $(".fullprogressbar").removeClass('hide');
          $(".customprogressbar").addClass('hide');  
          $('.progress-bar__fill').addClass('full-bar');
         $('.progress-bar__fill').removeClass('full-bar-down');
        }
      // hide cart loader
    }, "json");
  });
}

function loadCart(hasMatchingItems) {
  $.getJSON('/cart.js').then(
    function(cart) {
      updateCartItems(cart, 0);//last 0 is for upsell
      var shippingtext = $('#min_shipping').attr('data-varlu');
      $(this).find('.dyn_price').text(shippingtext);
      console.log(shippingtext);
       var final_total = cart.total_price.toFixed(2) / 100
        if(final_total < shippingtext){
          var diff_price = Math.round(shippingtext - final_total);
          console.log (Math.round(diff_price));
         $(".fullprogressbar").addClass('hide');
          $(".customprogressbar").removeClass('hide');
          $('.progress-bar__fill').removeClass('full-bar');
           $('.progress-bar__fill').removeClass('full-bar');
         $('.progress-bar__fill').addClass('full-bar-down');
          $('.dyn_price').html(diff_price);
        }
        else {
          $(".fullprogressbar").removeClass('hide');
          $(".customprogressbar").addClass('hide'); 
           $('.progress-bar__fill').addClass('full-bar');
         $('.progress-bar__fill').removeClass('full-bar-down');
        }
    }.bind(this)
  );
}
loadCart(0);
// Cart end

window.theme = window.theme || {};

theme.Filters = (function() {
  var settings = {
    // Breakpoints from src/stylesheets/global/variables.scss.liquid
    mediaQueryMediumUp: 'screen and (min-width: 750px)'
  };

  var constants = {
    SORT_BY: 'sort_by'
  };

  var selectors = {
    mainContent: '#MainContent',
    filterSelection: '#FilterTags',
    sortSelection: '#SortBy'
  };

  var data = {
    sortBy: 'data-default-sortby'
  };

  function Filters(container) {
    var $container = (this.$container = $(container));

    this.$filterSelect = $(selectors.filterSelection, $container);
    this.$sortSelect = $(selectors.sortSelection, $container);
    this.$selects = $(selectors.filterSelection, $container).add(
      $(selectors.sortSelection, $container)
    );

    this.defaultSort = this._getDefaultSortValue();
    this.$selects.removeClass('hidden');

    this.$filterSelect.on('change', this._onFilterChange.bind(this));
    this.$sortSelect.on('change', this._onSortChange.bind(this));
    this._initBreakpoints();
  }

  Filters.prototype = _.assignIn({}, Filters.prototype, {
    _initBreakpoints: function() {
      var self = this;

      enquire.register(settings.mediaQueryMediumUp, {
        match: function() {
          self._resizeSelect(self.$selects);
        }
      });
    },

    _onSortChange: function() {
      var sort = this._sortValue();
      var url = window.location.href.replace(window.location.search, '');
      var queryStringValue = slate.utils.getParameterByName('q');
      var query = queryStringValue !== null ? queryStringValue : '';

      if (sort.length) {
        var urlStripped = url.replace(window.location.hash, '');
        query = query !== '' ? '?q=' + query + '&' : '?';

        window.location.href =
          urlStripped + query + sort + selectors.mainContent;
      } else {
        // clean up our url if the sort value is blank for default
        window.location.href = url;
      }
    },

    _onFilterChange: function() {
      var filter = this._getFilterValue();

      // remove the 'page' parameter to go to the first page of results
      var search = document.location.search.replace(/\?(page=\w+)?&?/, '');

      // only add the search parameters to the url if they exist
      search = search !== '' ? '?' + search : '';

      document.location.href = filter + search + selectors.mainContent;
    },

    _getFilterValue: function() {
      return this.$filterSelect.val();
    },

    _getSortValue: function() {
      return this.$sortSelect.val() || this.defaultSort;
    },

    _getDefaultSortValue: function() {
      return this.$sortSelect.attr(data.sortBy);
    },

    _sortValue: function() {
      var sort = this._getSortValue();
      var query = '';

      if (sort !== this.defaultSort) {
        query = constants.SORT_BY + '=' + sort;
      }

      return query;
    },

    _resizeSelect: function($selection) {
      $selection.each(function() {
        var $this = $(this);
        var arrowWidth = 10;
        // create test element
        var text = $this.find('option:selected').text();
        var $test = $('<span>').html(text);

        // add to body, get width, and get out
        $test.appendTo('body');
        var width = $test.width();
        $test.remove();

        // set select width
        $this.width(width + arrowWidth);
      });
    },

    onUnload: function() {
      this.$filterSelect.off('change', this._onFilterChange);
      this.$sortSelect.off('change', this._onSortChange);
    }
  });

  return Filters;
})();

window.theme = window.theme || {};

theme.HeaderSection = (function() {
  function Header() {
    theme.Search.init();
  }

  Header.prototype = _.assignIn({}, Header.prototype, {
    onUnload: function() {
      theme.Header.unload();
    }
  });

  return Header;
})();

theme.Maps = (function() {
  var config = {
    zoom: 14
  };
  var apiStatus = null;
  var mapsToLoad = [];

  var errors = {
    addressNoResults: theme.strings.addressNoResults,
    addressQueryLimit: theme.strings.addressQueryLimit,
    addressError: theme.strings.addressError,
    authError: theme.strings.authError
  };

  var selectors = {
    section: '[data-section-type="map"]',
    map: '[data-map]',
    mapOverlay: '[data-map-overlay]'
  };

  var classes = {
    mapError: 'map-section--load-error',
    errorMsg: 'map-section__error errors text-center'
  };

  // Global function called by Google on auth errors.
  // Show an auto error message on all map instances.
  // eslint-disable-next-line camelcase, no-unused-vars
  window.gm_authFailure = function() {
    if (!Shopify.designMode) {
      return;
    }

    $(selectors.section).addClass(classes.mapError);
    $(selectors.map).remove();
    $(selectors.mapOverlay).after(
      '<div class="' +
        classes.errorMsg +
        '">' +
        theme.strings.authError +
        '</div>'
    );
  };

  function Map(container) {
    this.$container = $(container);
    this.$map = this.$container.find(selectors.map);
    this.key = this.$map.data('api-key');

    if (typeof this.key === 'undefined') {
      return;
    }

    if (apiStatus === 'loaded') {
      this.createMap();
    } else {
      mapsToLoad.push(this);

      if (apiStatus !== 'loading') {
        apiStatus = 'loading';
        if (typeof window.google === 'undefined') {
          $.getScript(
            'https://maps.googleapis.com/maps/api/js?key=' + this.key
          ).then(function() {
            apiStatus = 'loaded';
            initAllMaps();
          });
        }
      }
    }
  }

  function initAllMaps() {
    // API has loaded, load all Map instances in queue
    $.each(mapsToLoad, function(index, instance) {
      instance.createMap();
    });
  }

  function geolocate($map) {
    var deferred = $.Deferred();
    var geocoder = new google.maps.Geocoder();
    var address = $map.data('address-setting');

    geocoder.geocode({ address: address }, function(results, status) {
      if (status !== google.maps.GeocoderStatus.OK) {
        deferred.reject(status);
      }

      deferred.resolve(results);
    });

    return deferred;
  }

  Map.prototype = _.assignIn({}, Map.prototype, {
    createMap: function() {
      var $map = this.$map;

      return geolocate($map)
        .then(
          function(results) {
            var mapOptions = {
              zoom: config.zoom,
              center: results[0].geometry.location,
              draggable: false,
              clickableIcons: false,
              scrollwheel: false,
              disableDoubleClickZoom: true,
              disableDefaultUI: true
            };

            var map = (this.map = new google.maps.Map($map[0], mapOptions));
            var center = (this.center = map.getCenter());

            //eslint-disable-next-line no-unused-vars
            var marker = new google.maps.Marker({
              map: map,
              position: map.getCenter()
            });

            google.maps.event.addDomListener(
              window,
              'resize',
              $.debounce(250, function() {
                google.maps.event.trigger(map, 'resize');
                map.setCenter(center);
                $map.removeAttr('style');
              })
            );
          }.bind(this)
        )
        .fail(function() {
          var errorMessage;

          switch (status) {
            case 'ZERO_RESULTS':
              errorMessage = errors.addressNoResults;
              break;
            case 'OVER_QUERY_LIMIT':
              errorMessage = errors.addressQueryLimit;
              break;
            case 'REQUEST_DENIED':
              errorMessage = errors.authError;
              break;
            default:
              errorMessage = errors.addressError;
              break;
          }

          // Show errors only to merchant in the editor.
          if (Shopify.designMode) {
            $map
              .parent()
              .addClass(classes.mapError)
              .html(
                '<div class="' +
                  classes.errorMsg +
                  '">' +
                  errorMessage +
                  '</div>'
              );
          }
        });
    },

    onUnload: function() {
      if (this.$map.length === 0) {
        return;
      }
      google.maps.event.clearListeners(this.map, 'resize');
    }
  });

  return Map;
})();

/* eslint-disable no-new */
theme.Product = (function() {
  function Product(container) {
    var $container = (this.$container = $(container));
    var sectionId = $container.attr('data-section-id');
    this.ajaxEnabled = $container.data('ajax-enabled');

    this.settings = {
      // Breakpoints from src/stylesheets/global/variables.scss.liquid
      mediaQueryMediumUp: 'screen and (min-width: 750px)',
      mediaQuerySmall: 'screen and (max-width: 749px)',
      bpSmall: false,
      enableHistoryState: $container.data('enable-history-state') || false,
      namespace: '.slideshow-' + sectionId,
      sectionId: sectionId,
      sliderActive: false,
      zoomEnabled: false
    };

    this.selectors = {
      addToCart: '[data-add-to-cart]',
      addToCartText: '[data-add-to-cart-text]',
      cartCount: '[data-cart-count]',
      cartCountBubble: '[data-cart-count-bubble]',
      cartPopup: '[data-cart-popup]',
      cartPopupCartQuantity: '[data-cart-popup-cart-quantity]',
      cartPopupClose: '[data-cart-popup-close]',
      cartPopupDismiss: '[data-cart-popup-dismiss]',
      cartPopupImage: '[data-cart-popup-image]',
      cartPopupImageWrapper: '[data-cart-popup-image-wrapper]',
      cartPopupImagePlaceholder: '[data-cart-popup-image-placeholder]',
      cartPopupPlaceholderSize: '[data-placeholder-size]',
      cartPopupProductDetails: '[data-cart-popup-product-details]',
      cartPopupQuantity: '[data-cart-popup-quantity]',
      cartPopupQuantityLabel: '[data-cart-popup-quantity-label]',
      cartPopupTitle: '[data-cart-popup-title]',
      cartPopupWrapper: '[data-cart-popup-wrapper]',
      loader: '[data-loader]',
      loaderStatus: '[data-loader-status]',
      quantity: '[data-quantity-input]',
      SKU: '.variant-sku',
      productStatus: '[data-product-status]',
      originalSelectorId: '#ProductSelect-' + sectionId,
      productForm: '[data-product-form]',
      errorMessage: '[data-error-message]',
      errorMessageWrapper: '[data-error-message-wrapper]',
      productImageWraps: '.product-single__photo',
      productThumbImages: '.product-single__thumbnail--' + sectionId,
      productThumbs: '.product-single__thumbnails-' + sectionId,
      productThumbListItem: '.product-single__thumbnails-item',
      productFeaturedImage: '.product-featured-img',
      productThumbsWrapper: '.thumbnails-wrapper',
      saleLabel: '.product-price__sale-label-' + sectionId,
      singleOptionSelector: '.single-option-selector-' + sectionId,
      shopifyPaymentButton: '.shopify-payment-button',
      titleContainer: '.product-single__title-text',
      priceContainer: '[data-price]',
      regularPrice: '[data-regular-price]',
      salePrice: '[data-sale-price]',
      unitPrice: '[data-unit-price]',
      unitPriceBaseUnit: '[data-unit-price-base-unit]',
      afterPayPrice: '[data-afterpay-price]'
    };

    this.classes = {
      cartPopupWrapperHidden: 'cart-popup-wrapper--hidden',
      hidden: 'hide',
      inputError: 'input--error',
      productOnSale: 'price--on-sale',
      productUnitAvailable: 'price--unit-available',
      productUnavailable: 'price--unavailable',
      cartImage: 'cart-popup-item__image',
      productFormErrorMessageWrapperHidden:
        'product-form__error-message-wrapper--hidden',
      activeClass: 'active-thumb'
    };

    this.$quantityInput = $(this.selectors.quantity, $container);
    this.$errorMessageWrapper = $(
      this.selectors.errorMessageWrapper,
      $container
    );
    this.$addToCart = $(this.selectors.addToCart, $container);
    this.$addToCartText = $(this.selectors.addToCartText, this.$addToCart);
    this.$loader = $(this.selectors.loader, this.$addToCart);
    this.$loaderStatus = $(this.selectors.loaderStatus, $container);
    this.$shopifyPaymentButton = $(
      this.selectors.shopifyPaymentButton,
      $container
    );

    // Stop parsing if we don't have the product json script tag when loading
    // section in the Theme Editor
    if (!$('#ProductJson-' + sectionId).html()) {
      return;
    }

    this.productSingleObject = JSON.parse(
      document.getElementById('ProductJson-' + sectionId).innerHTML
    );

    this.settings.zoomEnabled = $(this.selectors.productImageWraps).hasClass(
      'js-zoom-enabled'
    );

    this._initBreakpoints();
    this._stringOverrides();
    this._initVariants();
    this._initImageSwitch();
    this._initAddToCart();
    this._setActiveThumbnail();
  }

  Product.prototype = _.assignIn({}, Product.prototype, {
    _stringOverrides: function() {
      theme.productStrings = theme.productStrings || {};
      $.extend(theme.strings, theme.productStrings);
    },

    _initBreakpoints: function() {
      var self = this;

      enquire.register(this.settings.mediaQuerySmall, {
        match: function() {
          // initialize thumbnail slider on mobile if more than three thumbnails
          if ($(self.selectors.productThumbImages).length > 3) {
            self._initThumbnailSlider();
          }

          // destroy image zooming if enabled
          if (self.settings.zoomEnabled) {
            $(self.selectors.productImageWraps).each(function() {
              _destroyZoom(this);
            });
          }

          self.settings.bpSmall = true;
        },
        unmatch: function() {
          if (self.settings.sliderActive) {
            self._destroyThumbnailSlider();
          }

          self.settings.bpSmall = false;
        }
      });

      enquire.register(this.settings.mediaQueryMediumUp, {
        match: function() {
          if (self.settings.zoomEnabled) {
            $(self.selectors.productImageWraps).each(function() {
              _enableZoom(this);
            });
          }
        }
      });
    },

    _initVariants: function() {
      var options = {
        $container: this.$container,
        enableHistoryState:
          this.$container.data('enable-history-state') || false,
        singleOptionSelector: this.selectors.singleOptionSelector,
        originalSelectorId: this.selectors.originalSelectorId,
        product: this.productSingleObject
      };

      this.variants = new slate.Variants(options);

      this.$container.on(
        'variantChange' + this.settings.namespace,
        this._updateAvailability.bind(this)
      );
      this.$container.on(
        'variantTitleChange' + this.settings.namespace,
        this._updateTitle.bind(this)
      );
      this.$container.on(
        'variantImageChange' + this.settings.namespace,
        this._updateImages.bind(this)
      );
      this.$container.on(
        'variantPriceChange' + this.settings.namespace,
        this._updatePrice.bind(this)
      );
      this.$container.on(
        'variantSKUChange' + this.settings.namespace,
        this._updateSKU.bind(this)
      );
    },

    _initImageSwitch: function() {
      if (!$(this.selectors.productThumbImages).length) {
        return;
      }

      var self = this;

      $(this.selectors.productThumbImages)
        .on('click', function(evt) {
          evt.preventDefault();
          var $el = $(this);

          var imageId = $el.data('thumbnail-id');

          self._switchImage(imageId);
          self._setActiveThumbnail(imageId);
        })
        .on('keyup', self._handleImageFocus.bind(self));
    },

    _initAddToCart: function() {
      $(this.selectors.productForm, this.$container).on(
        'submit',
        function(evt) {
          evt.preventDefault();

          if (this.$addToCart.is('[aria-disabled]')) {
            return;
          }

          this.$previouslyFocusedElement = $(':focus');

          var isInvalidQuantity = this.$quantityInput.val() <= 0;

          if (isInvalidQuantity) {
            this._showErrorMessage(theme.strings.quantityMinimumMessage);
            return;
          }

          if (!isInvalidQuantity && this.ajaxEnabled) {
            // disable the addToCart and dynamic checkout button while
            // request/cart popup is loading and handle loading state
            this._handleButtonLoadingState(true);
            var $data = $(this.selectors.productForm, this.$container);
            this._addItemToCart($data);
            return;
          }

          if (!isInvalidQuantity && !this.ajaxEnabled) {
            // submit the product form and get redirected to cart
            evt.target.submit();
          }
        }.bind(this)
      );
    },

    _addItemToCart: function(data) {
      let is_first = localStorage.getItem('mdsGift-'+$('#gift_redirect').val()) == "first";
       if(is_first && $('#gift_redirect').length > 0) {
        // redirect
        $('#shopify-section-product-template').css('opacity',0.5);
        $('.gift_icon_loader').removeClass('hide');
      }
      var params = {
        url: '/cart/add.js',
        data: $(data).serialize(),
        dataType: 'json'
      };

      $.post(params)
        .done(
          function(item) {
            $('#shopify-section-product-template').css('opacity',1);
            $('.gift_icon_loader').addClass('hide');
            this._hideErrorMessage();
            this._setupCartPopup(item);
          }.bind(this)
        )
        .fail(
          function(response) {
            this.$previouslyFocusedElement.focus();
            this._showErrorMessage(response.responseJSON.description);
            this._handleButtonLoadingState(false);
          }.bind(this)
        );
    },

    _handleButtonLoadingState: function(isLoading) {
      if (isLoading) {
        this.$addToCart.attr('aria-disabled', true);
        this.$addToCartText.addClass(this.classes.hidden);
        this.$loader.removeClass(this.classes.hidden);
        this.$shopifyPaymentButton.attr('disabled', true);
        this.$loaderStatus.attr('aria-hidden', false);
      } else {
        this.$addToCart.removeAttr('aria-disabled');
        this.$addToCartText.removeClass(this.classes.hidden);
        this.$loader.addClass(this.classes.hidden);
        this.$shopifyPaymentButton.removeAttr('disabled');
        this.$loaderStatus.attr('aria-hidden', true);
      }
    },

    _showErrorMessage: function(errorMessage) {
      $(this.selectors.errorMessage, this.$container).html(errorMessage);

      if (this.$quantityInput.length !== 0) {
        this.$quantityInput.addClass(this.classes.inputError);
      }

      this.$errorMessageWrapper
        .removeClass(this.classes.productFormErrorMessageWrapperHidden)
        .attr('aria-hidden', true)
        .removeAttr('aria-hidden');
    },

    _hideErrorMessage: function() {
      this.$errorMessageWrapper.addClass(
        this.classes.productFormErrorMessageWrapperHidden
      );

      if (this.$quantityInput.length !== 0) {
        this.$quantityInput.removeClass(this.classes.inputError);
      }
    },

    _setupCartPopup: function(item) {
      this.$cartPopup = this.$cartPopup || $(this.selectors.cartPopup);
      this.$cartPopupWrapper =
        this.$cartPopupWrapper || $(this.selectors.cartPopupWrapper);
      this.$cartPopupTitle =
        this.$cartPopupTitle || $(this.selectors.cartPopupTitle);
      this.$cartPopupQuantity =
        this.$cartPopupQuantity || $(this.selectors.cartPopupQuantity);
      this.$cartPopupQuantityLabel =
        this.$cartPopupQuantityLabel ||
        $(this.selectors.cartPopupQuantityLabel);
      this.$cartPopupClose =
        this.$cartPopupClose || $(this.selectors.cartPopupClose);
      this.$cartPopupDismiss =
        this.cartPopupDismiss || $(this.selectors.cartPopupDismiss);
      this.$cartPopupImagePlaceholder =
        this.$cartPopupImagePlaceholder ||
        $(this.selectors.cartPopupImagePlaceholder);

      this._setupCartPopupEventListeners();

      this._updateCartPopupContent(item);
    },

    _updateCartPopupContent: function(item) {
      var quantity = this.$quantityInput.length ? this.$quantityInput.val() : 1;

      this.$cartPopupTitle.text(item.product_title);
      this.$cartPopupQuantity.text(quantity);
      this.$cartPopupQuantityLabel.text(
        theme.strings.quantityLabel.replace('[count]', quantity)
      );

      this._setCartPopupPlaceholder(
        item.featured_image.url,
        item.featured_image.aspect_ratio
      );
      this._setCartPopupImage(item.featured_image.url, item.featured_image.alt);
      this._setCartPopupProductDetails(
        item.product_has_only_default_variant,
        item.options_with_values,
        item.properties
      );

      loadCart(0);
      this._showCartPopup();
    },

    _setupCartPopupEventListeners: function() {
      this.$cartPopupWrapper.on(
        'keyup',
        function(event) {
          if (event.keyCode === slate.utils.keyboardKeys.ESCAPE) {
            this._hideCartPopup(event);
          }
        }.bind(this)
      );

      this.$cartPopupClose.on('click', this._hideCartPopup.bind(this));
      this.$cartPopupDismiss.on('click', this._hideCartPopup.bind(this));
      $('body').on('click', this._onBodyClick.bind(this));
    },

    _setCartPopupPlaceholder: function(imageUrl, imageAspectRatio) {
      this.$cartPopupImageWrapper =
        this.$cartPopupImageWrapper || $(this.selectors.cartPopupImageWrapper);

      if (imageUrl === null) {
        this.$cartPopupImageWrapper.addClass(this.classes.hidden);
        return;
      }

      var $placeholder = $(this.selectors.cartPopupPlaceholderSize);
      var maxWidth = 95 * imageAspectRatio;
      var heightRatio = 100 / imageAspectRatio;

      this.$cartPopupImagePlaceholder.css('max-width', maxWidth);

      $placeholder.css('padding-top', heightRatio + '%');
    },

    _setCartPopupImage: function(imageUrl, imageAlt) {
      if (imageUrl === null) return;

      this.$cartPopupImageWrapper.removeClass(this.classes.hidden);
      var sizedImageUrl = theme.Images.getSizedImageUrl(imageUrl, '200x');
      var image = document.createElement('img');
      image.src = sizedImageUrl;
      image.alt = imageAlt;
      image.classList.add(this.classes.cartImage);
      image.dataset.cartPopupImage = '';

      image.onload = function() {
        this.$cartPopupImagePlaceholder.addClass(this.classes.hidden);
        this.$cartPopupImageWrapper.append(image);
      }.bind(this);
    },

    _setCartPopupProductDetails: function(
      product_has_only_default_variant,
      options,
      properties
    ) {
      this.$cartPopupProductDetails =
        this.$cartPopupProductDetails ||
        $(this.selectors.cartPopupProductDetails);
      var variantPropertiesHTML = '';

      if (!product_has_only_default_variant) {
        variantPropertiesHTML =
          variantPropertiesHTML + this._getVariantOptionList(options);
      }

      if (properties !== null && Object.keys(properties).length !== 0) {
        variantPropertiesHTML =
          variantPropertiesHTML + this._getPropertyList(properties);
      }

      if (variantPropertiesHTML.length === 0) {
        this.$cartPopupProductDetails.html('');
        this.$cartPopupProductDetails.attr('hidden', '');
      } else {
        this.$cartPopupProductDetails.html(variantPropertiesHTML);
        this.$cartPopupProductDetails.removeAttr('hidden');
      }
    },

    _getVariantOptionList: function(variantOptions) {
      var variantOptionListHTML = '';

      variantOptions.forEach(function(variantOption) {
        variantOptionListHTML =
          variantOptionListHTML +
          '<li class="product-details__item product-details__item--variant-option">' +
          variantOption.name +
          ': ' +
          variantOption.value +
          '</li>';
      });

      return variantOptionListHTML;
    },

    _getPropertyList: function(properties) {
      var propertyListHTML = '';

      function getEntries(obj){
        var ownProps = Object.keys( obj ),
          i = ownProps.length,
          resArray = new Array(i);
        while (i--)
          resArray[i] = [ownProps[i], obj[ownProps[i]]];

        return resArray;
      }

      var propertiesArray = getEntries(properties);

      for(let i = 0; i < propertiesArray.length; i++) {
        let property = propertiesArray[i];

        // Line item properties prefixed with an underscore are not to be displayed
        if (property[0].charAt(0) === '_') return;

        // if the property value has a length of 0 (empty), don't display it
        if (property[1].length === 0) return;

        propertyListHTML =
          propertyListHTML +
          '<li class="product-details__item product-details__item--property">' +
          '<span class="product-details__property-label">' +
          property[0] +
          ': </span>' +
          property[1];
        ': ' + '</li>';
      }
      /*
      propertiesArray.forEach(function(property) {
        // Line item properties prefixed with an underscore are not to be displayed
        if (property[0].charAt(0) === '_') return;

        // if the property value has a length of 0 (empty), don't display it
        if (property[1].length === 0) return;

        propertyListHTML =
          propertyListHTML +
          '<li class="product-details__item product-details__item--property">' +
          '<span class="product-details__property-label">' +
          property[0] +
          ': </span>' +
          property[1];
        ': ' + '</li>';
      });
      */

      return propertyListHTML;
    },

    _setCartQuantity: function(quantity) {
      this.$cartPopupCartQuantity =
        this.$cartPopupCartQuantity || $(this.selectors.cartPopupCartQuantity);
      var ariaLabel;

      if (quantity === 1) {
        ariaLabel = theme.strings.oneCartCount;
      } else if (quantity > 1) {
        ariaLabel = theme.strings.otherCartCount.replace('[count]', quantity);
      }

      this.$cartPopupCartQuantity.text(quantity).attr('aria-label', ariaLabel);
    },

    _setCartCountBubble: function(quantity) {
      this.$cartCountBubble =
        this.$cartCountBubble || $(this.selectors.cartCountBubble);
      this.$cartCount = this.$cartCount || $(this.selectors.cartCount);

      this.$cartCountBubble.removeClass(this.classes.hidden);
      this.$cartCount.text(quantity);
    },

    _showCartPopup: function() {
     let is_first = localStorage.getItem('mdsGift-'+$('#gift_redirect').val()) == "first";
       if(localStorage.getItem('mdsGift-'+$('#gift_redirect').val()) == 'second' && $('#gift_redirect').length > 0 ) {

        localStorage.setItem('mdsGift-'+$('#gift_redirect').val(),'third');
        $('[data-gift-set-count]').addClass('hide');
        $('[data-gift-text],[data-atc-text]').text('Add to Cart');
        // $('.valentine_card').addClass('hide');
      }
      if(is_first && $('#gift_redirect').length > 0) {
        // redirect
        localStorage.setItem('mdsGift-'+$('#gift_redirect').val(),'second');
        $('[data-gift-set-count]').text('2: Second item in the cart');
        $('[data-gift-text],[data-atc-text]').text(getGiftText());

      } else {
        // show menu
        $('.gift_preorder').addClass('hide');
        $('#cartMenu').addClass('open');
        $('html').addClass('no-scroll');
      }
      this._handleButtonLoadingState(false);
    },

    _hideCartPopup: function(event) {
      var setFocus = event.detail === 0 ? true : false;
      this.$cartPopupWrapper
        .prepareTransition()
        .addClass(this.classes.cartPopupWrapperHidden);

      $(this.selectors.cartPopupImage).remove();
      this.$cartPopupImagePlaceholder.removeClass(this.classes.hidden);

      slate.a11y.removeTrapFocus({
        $container: this.$cartPopupWrapper,
        namespace: 'cartPopupFocus'
      });

      if (setFocus) this.$previouslyFocusedElement[0].focus();

      this.$cartPopupWrapper.off('keyup');
      this.$cartPopupClose.off('click');
      this.$cartPopupDismiss.off('click');
      $('body').off('click');
    },

    _onBodyClick: function(event) {
      var $target = $(event.target);

      if (
        $target[0] !== this.$cartPopupWrapper[0] &&
        !$target.parents(this.selectors.cartPopup).length
      ) {
        this._hideCartPopup(event);
      }
    },

    _setActiveThumbnail: function(imageId) {
      // If there is no element passed, find it by the current product image
      if (typeof imageId === 'undefined') {
        imageId = $(
          this.selectors.productImageWraps + ':not(.hide)',
          this.$container
        ).data('image-id');
      }

      var $thumbnailWrappers = $(
        this.selectors.productThumbListItem + ':not(.slick-cloned)',
        this.$container
      );

      var $activeThumbnail = $thumbnailWrappers.find(
        this.selectors.productThumbImages +
          "[data-thumbnail-id='" +
          imageId +
          "']"
      );

      $(this.selectors.productThumbImages)
        .removeClass(this.classes.activeClass)
        .removeAttr('aria-current');

      $activeThumbnail.addClass(this.classes.activeClass);
      $activeThumbnail.attr('aria-current', true);

      if (!$thumbnailWrappers.hasClass('slick-slide')) {
        return;
      }

      var slideIndex = $activeThumbnail.parent().data('slick-index');

      $(this.selectors.productThumbs).slick('slickGoTo', slideIndex, true);
    },

    _switchImage: function(imageId) {
      var $newImage = $(
        this.selectors.productImageWraps + "[data-image-id='" + imageId + "']",
        this.$container
      );
      var $otherImages = $(
        this.selectors.productImageWraps +
          ":not([data-image-id='" +
          imageId +
          "'])",
        this.$container
      );

      $newImage.removeClass(this.classes.hidden);
      $otherImages.addClass(this.classes.hidden);
    },

    _handleImageFocus: function(evt) {
      if (evt.keyCode !== slate.utils.keyboardKeys.ENTER) return;

      $(this.selectors.productFeaturedImage + ':visible').focus();
    },

    _initThumbnailSlider: function() {
      var options = {
        slidesToShow: 4,
        slidesToScroll: 3,
        infinite: false,
        prevArrow: '.thumbnails-slider__prev--' + this.settings.sectionId,
        nextArrow: '.thumbnails-slider__next--' + this.settings.sectionId,
        responsive: [
          {
            breakpoint: 321,
            settings: {
              slidesToShow: 3
            }
          }
        ]
      };

      $(this.selectors.productThumbs).slick(options);

      // Accessibility concerns not yet fixed in Slick Slider
      $(this.selectors.productThumbsWrapper, this.$container)
        .find('.slick-list')
        .removeAttr('aria-live');
      $(this.selectors.productThumbsWrapper, this.$container)
        .find('.slick-disabled')
        .removeAttr('aria-disabled');

      this.settings.sliderActive = true;
    },

    _destroyThumbnailSlider: function() {
      $(this.selectors.productThumbs).slick('unslick');
      this.settings.sliderActive = false;

      // Accessibility concerns not yet fixed in Slick Slider
      $(this.selectors.productThumbsWrapper, this.$container)
        .find('[tabindex="-1"]')
        .removeAttr('tabindex');
    },

    _liveRegionText: function(variant) {
      // Dummy content for live region
      var liveRegionText =
        '[Availability] [Regular] [$$] [Sale] [$]. [UnitPrice] [$$$]';

      if (!variant) {
        liveRegionText = theme.strings.unavailable;
        return liveRegionText;
      }

      // Update availability
      var availability = variant.available ? '' : theme.strings.soldOut + ',';
      liveRegionText = liveRegionText.replace('[Availability]', availability);

      // Update pricing information
      var regularLabel = '';
      var regularPrice = theme.Currency.formatMoney(
        variant.price,
        theme.moneyFormat
      );
      var saleLabel = '';
      var salePrice = '';
      var unitLabel = '';
      var unitPrice = '';

      if (variant.compare_at_price > variant.price) {
        regularLabel = theme.strings.regularPrice;
        regularPrice =
          theme.Currency.formatMoney(
            variant.compare_at_price,
            theme.moneyFormat
          ) + ',';
        saleLabel = theme.strings.sale;
        salePrice = theme.Currency.formatMoney(
          variant.price,
          theme.moneyFormat
        );
      }

      if (variant.unit_price) {
        unitLabel = theme.strings.unitPrice;
        unitPrice =
          theme.Currency.formatMoney(variant.unit_price, theme.moneyFormat) +
          ' ' +
          theme.strings.unitPriceSeparator +
          ' ' +
          this._getBaseUnit(variant);
      }

      liveRegionText = liveRegionText
        .replace('[Regular]', regularLabel)
        .replace('[$$]', regularPrice)
        .replace('[Sale]', saleLabel)
        .replace('[$]', salePrice)
        .replace('[UnitPrice]', unitLabel)
        .replace('[$$$]', unitPrice)
        .trim();

      return liveRegionText;
    },

    _updateLiveRegion: function(evt) {
      var variant = evt.variant;
      var liveRegion = this.container.querySelector(
        this.selectors.productStatus
      );
      liveRegion.textContent = this._liveRegionText(variant);
      liveRegion.setAttribute('aria-hidden', false);

      // hide content from accessibility tree after announcement
      setTimeout(function() {
        liveRegion.setAttribute('aria-hidden', true);
      }, 1000);
    },

    _updateAddToCart: function(evt) {
      var variant = evt.variant;
      $('.placebo-atc').removeClass('hide');

      var preorder = document.querySelector('#isPreorder');
     var isnotifyemail = document.querySelector('#is_signup_email');
       if(isnotifyemail !=null) {
      isnotifyemail = isnotifyemail.value;
      }
      var productcolor= document.querySelector('#product_color'); 
      if(productcolor !=null) {
        productcolor.value =variant.title;
      }
	  var notifybtn =  document.querySelector('.notifydiv');

      let is_preorder = false;

      if(preorder != null) {
        let variants = preorder.value.split(',');
        for(var i = 0; i < variants.length; i++) {
          let values = variants[i].split(':');
          if(values[0] == variant.id) {
            is_preorder = values[1] == "true";
          }
        }
      }

      var preorderText = document.getElementById('pre-order');
      if(preorderText != null) {
        if(is_preorder) {
          preorderText.removeAttribute('disabled');
        } else {
          preorderText.setAttribute('disabled', true);
        }
      }
     
      if (variant) {

          if (variant.available || is_preorder) {
           if($('#gift_redirect').length < 1) {
            this.$addToCart.removeClass('hide');
            this.$addToCart.show();

            this.$addToCart
              .removeAttr('id');
            this.$addToCart
              .removeAttr('aria-disabled')
              .attr('aria-label', is_preorder ? theme.strings.preorder : theme.strings.addToCart);
            $(this.selectors.addToCartText, this.$container).text(
              is_preorder ? theme.strings.preorder : theme.strings.addToCart
            );
            $('[data-atc-text]').text(is_preorder ? theme.strings.preorder : theme.strings.addToCart);

            /*
            let button_price = document.createElement('span');
            button_price.classList.add('btn-price');
            button_price.classList.add('hide-desktop');
            button_price.innerHTML = ' - ';
            let button_price_text = document.createElement('span');
            button_price_text.classList.add('price');
            button_price_text.setAttribute('data-price', '');
            button_price_text.innerHTML = theme.Currency.formatMoney(
              variant.price,
              theme.moneyFormat
            );
            button_price.appendChild(button_price_text);
            $(this.selectors.addToCartText, this.$container).append(button_price);
            */

            $(this.selectors.addToCartText, this.$container);
            this.$shopifyPaymentButton.show();
           }
           if($('#gift_redirect').length > 0) {
              if(localStorage.getItem('mdsGift-'+$('#gift_redirect').val()).includes("sec")) {
                $('[data-gift-set-count]').text('Add Second Item to Bag');
                this.$addToCart
                  .removeAttr('aria-disabled');
                $(this.selectors.addToCartText, this.$container).text('Add Second Item to Bag');
              }
              if(localStorage.getItem('mdsGift-'+$('#gift_redirect').val()).includes("first")) {
                this.$addToCart
                  .removeAttr('aria-disabled');
                $(this.selectors.addToCartText, this.$container).text('Add First Item to Bag');
              }
         	}
          } else {
            // The variant doesn't exist, disable submit button and change the text.
            // This may be an error or notice that a specific variant is not available.
            if(isnotifyemail=='true') { 
                  this.$addToCart.hide(); 
                  notifybtn.classList.remove("hide");
                  $('.placebo-atc').addClass('hide');
                  $('.sold-out-info').removeClass("hide");
                  $('.product-benefits').addClass("hide");
              }
              else {
            this.$addToCart
                .attr('id', 'BIS_trigger')
                .attr('aria-label', theme.strings.notify).attr('data-variant-id',variant.id);
            $(this.selectors.addToCartText, this.$container).text(
              theme.strings.notify
            );
            this.$shopifyPaymentButton.hide();
            }
          }
      } else {
        this.$addToCart
          .attr('aria-disabled', true)
          .attr('aria-label', theme.strings.unavailable);
        $(this.selectors.addToCartText, this.$container).text(
          theme.strings.unavailable
        );
        this.$shopifyPaymentButton.hide();
      }
    },

    _updateAvailability: function(evt) {
      // remove error message if one is showing
      this._hideErrorMessage();

      // update form submit
      this._updateAddToCart(evt);
      // update live region
      this._updateLiveRegion(evt);

      this._updatePrice(evt);
    },

    _updateTitle: function(evt) {
      var variant = evt.variant;

      var $titleContainer = $(this.selectors.titleContainer, this.$container);

      $('.product-form__item .variant-color').text('Color - '+ variant.title.split("mm / ").pop());
    },

    _updateImages: function(evt) {
      var variant = evt.variant;
      var imageId = variant.featured_image.id;

      this._switchImage(imageId);
      this._setActiveThumbnail(imageId);
    },

    _updatePrice: function(evt) {
      var variant = evt.variant;

      var $priceContainer = $(this.selectors.priceContainer, this.$container);
      var $regularPrice = $(this.selectors.regularPrice, $priceContainer);
      var $salePrice = $(this.selectors.salePrice, $priceContainer);
      var $unitPrice = $(this.selectors.unitPrice, $priceContainer);
      var $afterPayPrice = $(this.selectors.afterPayPrice);
      var $unitPriceBaseUnit = $(
        this.selectors.unitPriceBaseUnit,
        $priceContainer
      );

      // Reset product price state
      $priceContainer
        .removeClass(this.classes.productUnavailable)
        .removeClass(this.classes.productOnSale)
        .removeClass(this.classes.productUnitAvailable)
        .removeAttr('aria-hidden');

      // Unavailable
      if (!variant) {
        $priceContainer
          .addClass(this.classes.productUnavailable)
          .attr('aria-hidden', true);
        return;
      }

      // On sale
      if (variant.compare_at_price > variant.price) {
        $regularPrice.html(
          theme.Currency.formatMoney(
            variant.compare_at_price,
            theme.moneyFormat
          )
        );
        $salePrice.html(
          theme.Currency.formatMoney(variant.price, theme.moneyFormat)
        );
        $afterPayPrice.html(
          theme.Currency.formatMoney(variant.price/4, "NO_CURRENCY")
        );
        $priceContainer.addClass(this.classes.productOnSale);
      } else {
        // Regular price
        $regularPrice.html(
          theme.Currency.formatMoney(variant.price, theme.moneyFormat)
        );
        $afterPayPrice.html(
          theme.Currency.formatMoney(variant.price/4, "NO_CURRENCY")
        );
      }

      // Unit price
      if (variant.unit_price) {
        $unitPrice.html(
          theme.Currency.formatMoney(variant.unit_price, theme.moneyFormat)
        );
        $unitPriceBaseUnit.html(this._getBaseUnit(variant));
        $priceContainer.addClass(this.classes.productUnitAvailable);
      }
    },

    _getBaseUnit: function(variant) {
      return variant.unit_price_measurement.reference_value === 1
        ? variant.unit_price_measurement.reference_unit
        : variant.unit_price_measurement.reference_value +
            variant.unit_price_measurement.reference_unit;
    },

    _updateSKU: function(evt) {
      var variant = evt.variant;

      // Update the sku
      $(this.selectors.SKU).html(variant.sku);
    },

    onUnload: function() {
      this.$container.off(this.settings.namespace);
    }
  });

  function _enableZoom(el) {
    var zoomUrl = $(el).data('zoom');
    $(el).zoom({
      url: zoomUrl
    });
  }

  function _destroyZoom(el) {
    $(el).trigger('zoom.destroy');
  }

  return Product;
})();

theme.ProductRecommendations = (function() {
  var selectors = {
    productCard: '[data-product-card]'
  };

  function ProductRecommendations(container) {
    this.$container = $(container);

    var productId = this.$container.data('productId');
    var recommendationsSectionUrl =
      '/recommendations/products?&section_id=product-recommendations&product_id=' +
      productId +
      '&limit=4';

    $.get(recommendationsSectionUrl).then(
      function(section) {
        var recommendationsMarkup = $(section).html();
        if (recommendationsMarkup.trim() !== '') {
          this.$container.html(recommendationsMarkup);
          this.sendTrekkieEvent();
        }
      }.bind(this)
    );
  }

  ProductRecommendations.prototype = _.assignIn(
    {},
    ProductRecommendations.prototype,
    {
      sendTrekkieEvent: function() {
        if (
          !window.ShopifyAnalytics ||
          !window.ShopifyAnalytics.lib ||
          !window.ShopifyAnalytics.lib.track
        ) {
          return;
        }

        var didPageJumpOccur =
          this.$container[0].getBoundingClientRect().top <= window.innerHeight;
        var numberOfRecommendationsDisplayed = this.$container.find(
          selectors.productCard
        ).length;

        window.ShopifyAnalytics.lib.track('Product Recommendations Displayed', {
          theme: 'debut',
          didPageJumpOccur: didPageJumpOccur,
          numberOfRecommendationsDisplayed: numberOfRecommendationsDisplayed
        });
      }
    }
  );

  return ProductRecommendations;
})();

theme.Quotes = (function() {
  var config = {
    mediaQuerySmall: 'screen and (max-width: 749px)',
    mediaQueryMediumUp: 'screen and (min-width: 750px)',
    slideCount: 0
  };
  var defaults = {
    accessibility: true,
    arrows: false,
    dots: true,
    autoplay: false,
    touchThreshold: 20,
    slidesToShow: 3,
    slidesToScroll: 3
  };

  function Quotes(container) {
    var $container = (this.$container = $(container));
    var sectionId = $container.attr('data-section-id');
    var wrapper = (this.wrapper = '.quotes-wrapper');
    var slider = (this.slider = '#Quotes-' + sectionId);
    var $slider = $(slider, wrapper);

    var sliderActive = false;
    var mobileOptions = $.extend({}, defaults, {
      slidesToShow: 1,
      slidesToScroll: 1,
      adaptiveHeight: true
    });

    config.slideCount = $slider.data('count');

    // Override slidesToShow/Scroll if there are not enough blocks
    if (config.slideCount < defaults.slidesToShow) {
      defaults.slidesToShow = config.slideCount;
      defaults.slidesToScroll = config.slideCount;
    }

    $slider.on('init', this.a11y.bind(this));

    enquire.register(config.mediaQuerySmall, {
      match: function() {
        initSlider($slider, mobileOptions);
      }
    });

    enquire.register(config.mediaQueryMediumUp, {
      match: function() {
        initSlider($slider, defaults);
      }
    });

    function initSlider(sliderObj, args) {
      if (sliderActive) {
        sliderObj.slick('unslick');
        sliderActive = false;
      }

      sliderObj.slick(args);
      sliderActive = true;
    }
  }

  Quotes.prototype = _.assignIn({}, Quotes.prototype, {
    onUnload: function() {
      enquire.unregister(config.mediaQuerySmall);
      enquire.unregister(config.mediaQueryMediumUp);

      $(this.slider, this.wrapper).slick('unslick');
    },

    onBlockSelect: function(evt) {
      // Ignore the cloned version
      var $slide = $(
        '.quotes-slide--' + evt.detail.blockId + ':not(.slick-cloned)'
      );
      var slideIndex = $slide.data('slick-index');

      // Go to selected slide, pause autoplay
      $(this.slider, this.wrapper).slick('slickGoTo', slideIndex);
    },

    a11y: function(event, obj) {
      var $list = obj.$list;
      var $wrapper = $(this.wrapper, this.$container);

      // Remove default Slick aria-live attr until slider is focused
      $list.removeAttr('aria-live');

      // When an element in the slider is focused set aria-live
      $wrapper.on('focusin', function(evt) {
        if ($wrapper.has(evt.target).length) {
          $list.attr('aria-live', 'polite');
        }
      });

      // Remove aria-live
      $wrapper.on('focusout', function(evt) {
        if ($wrapper.has(evt.target).length) {
          $list.removeAttr('aria-live');
        }
      });
    }
  });

  return Quotes;
})();

theme.slideshows = {};

theme.SlideshowSection = (function() {
  function SlideshowSection(container) {
    var $container = (this.$container = $(container));
    var sectionId = $container.attr('data-section-id');
    var slideshow = (this.slideshow = '#Slideshow-' + sectionId);

    theme.slideshows[slideshow] = new theme.Slideshow(slideshow, sectionId);
  }

  return SlideshowSection;
})();

theme.SlideshowSection.prototype = _.assignIn(
  {},
  theme.SlideshowSection.prototype,
  {
    onUnload: function() {
      delete theme.slideshows[this.slideshow];
    },

    onBlockSelect: function(evt) {
      var $slideshow = $(this.slideshow);
      var adaptHeight = $slideshow.data('adapt-height');

      if (adaptHeight) {
        theme.slideshows[this.slideshow].setSlideshowHeight();
      }

      // Ignore the cloned version
      var $slide = $(
        '.slideshow__slide--' + evt.detail.blockId + ':not(.slick-cloned)'
      );
      var slideIndex = $slide.data('slick-index');

      // Go to selected slide, pause auto-rotate
      $slideshow.slick('slickGoTo', slideIndex).slick('slickPause');
    },

    onBlockDeselect: function() {
      // Resume auto-rotate
      $(this.slideshow).slick('slickPlay');
    }
  }
);

theme.slideshows = {};

theme.VideoSection = (function() {
  function VideoSection(container) {
    var $container = (this.$container = $(container));

    $('.video', $container).each(function() {
      var $el = $(this);
      theme.Video.init($el);
      theme.Video.editorLoadVideo($el.attr('id'));
    });
  }

  return VideoSection;
})();

theme.VideoSection.prototype = _.assignIn({}, theme.VideoSection.prototype, {
  onUnload: function() {
    theme.Video.removeEvents();
  }
});

theme.heros = {};

theme.HeroSection = (function() {
  function HeroSection(container) {
    var $container = (this.$container = $(container));
    var sectionId = $container.attr('data-section-id');
    var hero = '#Hero-' + sectionId;
    theme.heros[hero] = new theme.Hero(hero, sectionId);
  }

  return HeroSection;
})();


$(document).ready(function() {
  var sections = new theme.Sections();

  sections.register('cart-template', theme.Cart);
  sections.register('product', theme.Product);
  sections.register('collection-template', theme.Filters);
  sections.register('product-template', theme.Product);
  sections.register('header-section', theme.HeaderSection);
  sections.register('map', theme.Maps);
  sections.register('slideshow-section', theme.SlideshowSection);
  sections.register('video-section', theme.VideoSection);
  sections.register('quotes', theme.Quotes);
  sections.register('hero-section', theme.HeroSection);
  sections.register('product-recommendations', theme.ProductRecommendations);
});

theme.init = function() {
  theme.customerTemplates.init();

  // Theme-specific selectors to make tables scrollable
  var tableSelectors = '.rte table,' + '.custom__item-inner--html table';

  slate.rte.wrapTable({
    $tables: $(tableSelectors),
    tableWrapperClass: 'scrollable-wrapper'
  });

  // Theme-specific selectors to make iframes responsive
  var iframeSelectors =
    '.rte iframe[src*="youtube.com/embed"],' +
    '.rte iframe[src*="player.vimeo"],' +
    '.custom__item-inner--html iframe[src*="youtube.com/embed"],' +
    '.custom__item-inner--html iframe[src*="player.vimeo"]';

  slate.rte.wrapIframe({
    $iframes: $(iframeSelectors),
    iframeWrapperClass: 'video-wrapper'
  });

  // Common a11y fixes
  slate.a11y.pageLinkFocus($(window.location.hash));

  $('.in-page-link').on('click', function(evt) {
    slate.a11y.pageLinkFocus($(evt.currentTarget.hash));
  });

  $('a[href="#"]').on('click', function(evt) {
    evt.preventDefault();
  });

  slate.a11y.accessibleLinks({
    messages: {
      newWindow: theme.strings.newWindow,
      external: theme.strings.external,
      newWindowExternal: theme.strings.newWindowExternal
    },
    $links: $('a[href]:not([aria-describedby], .product-single__thumbnail)')
  });

  theme.FormStatus.init();

  var selectors = {
    image: '[data-image]',
    imagePlaceholder: '[data-image-placeholder]',
    imageWithPlaceholderWrapper: '[data-image-with-placeholder-wrapper]'
  };

  var classes = {
    hidden: 'hide'
  };

  $(document).on('lazyloaded', function(e) {
    var $target = $(e.target);

    if (!$target.is(selectors.image)) {
      return;
    }

    $target
      .closest(selectors.imageWithPlaceholderWrapper)
      .find(selectors.imagePlaceholder)
      .addClass(classes.hidden);
  });

  // When the theme loads, lazysizes might load images before the "lazyloaded"
  // event listener has been attached. When this happens, the following function
  // hides the loading placeholders.
  function onLoadHideLazysizesAnimation() {
    $(selectors.image + '.lazyloaded')
      .closest(selectors.imageWithPlaceholderWrapper)
      .find(selectors.imagePlaceholder)
      .addClass(classes.hidden);
  }

  onLoadHideLazysizesAnimation();
};

$(theme.init);

function createFlickity(carousel) {
  var autoplay = $(carousel).hasClass('autoplay') ? 3000 : false;
  var alignment = $(carousel).hasClass('lefty') ? 'left' : 'center';
  var isZodiac = $(carousel).hasClass('zodiac-slider');
  if($('body').hasClass('template-list-collections')){
  	alignment = "left"; //collection page changes
  }
  $(carousel).flickity({
    freeScroll: true,
    contain: true,
    cellAlign: alignment,
    wrapAround: isZodiac,
    groupCells: !isZodiac,
    prevNextButtons: !isZodiac,
    pageDots: false,
    arrowShape: "M 15,50 L 65,100 L 65,90 L 25,50  L 65,10 L 65,0 Z",
    autoPlay: autoplay
  });

  $(carousel).on( 'dragStart.flickity', function( event, pointer ) {
    document.ontouchmove = function (e) {
      e.preventDefault();
    }
  });
  $(carousel).on( 'dragEnd.flickity', function( event, pointer ) {
    document.ontouchmove = function (e) {
      return true;
    }
  });
}

function generateMatchingItems(items, parent_class, item_class, colour) {
  let output = document.createElement('div');
  output.setAttribute('class', parent_class);
  if(items.length == 1) {
    output.classList.add('lefty');
  }

  const limit = 4;
  let toShow = items.length < limit ? items.length : limit;

  for(let i = 0; i < toShow; i++) {
    let product = items[i];
let variant = '';
    if(product.product_type.includes('Watch')) {
        variant = product.variants.filter(function(variant) { return variant.option2 == colour; })[0];

    }
    else {
    	variant = product.variants.filter(function(variant) { return variant.option1 == colour; })[0];
    }    let varURL = '/products/' + product.handle + '?variant=' + variant.id;
    
    var preorder_matching = document.querySelector('#preorder'+product.id);
    let is_preorder_matching = false;
    var preorder_text=null;
     if(preorder_matching != null) {
       let variants_matching = preorder_matching.value.split(',');
       //  console.log(variants_matching);
       for(var j = 0; j < variants_matching.length; j++) {
          let values = variants_matching[j].split(':');
          if(values[0] == variant.id) {
            preorder_matching = values[1] == "true";
          }
        }
      }
    if(preorder_matching) {
          for(var x=0; x<product.tags.length;x++) {
            if(product.tags[x].includes('eta:')) {
              preorder_text=product.tags[x].split(':')[1];
            }
        }
    }

    let product_wrapper = document.createElement('div');
    product_wrapper.setAttribute('class', item_class);
    output.appendChild(product_wrapper);
    
    let featured_item = document.createElement('div');
    featured_item.classList.add('featured-item');
    product_wrapper.appendChild(featured_item);

    let featured_product_image = document.createElement('div');
    featured_product_image.classList.add('feautred-product-image');
    featured_item.appendChild(featured_product_image);

    let image_link = document.createElement('a');
    image_link.classList.add('image-link');
    image_link.setAttribute('href', varURL);
    featured_product_image.appendChild(image_link);

    let image_wrapper = document.createElement('div');
    image_wrapper.setAttribute('class', 'grid-view-item__image-wrapper product-card__image-wrapper js product-image-fix');
    image_wrapper.classList.add(variant.option1.replace(/ /g, '-').toLowerCase());
    image_link.appendChild(image_wrapper);

    let rel = document.createElement('div');
    rel.classList.add('relative');
    image_wrapper.appendChild(rel);

    let image = document.createElement('img');
    image.setAttribute('class', 'grid-view-item__image active');
    image.setAttribute('src', variant.featured_image.src);
    rel.appendChild(image);

    let is_art_series = product.tags.indexOf('customize_artwork') != -1;
    // zodiac
    let is_zodiac_series = product.tags.indexOf('customize_zodiac') != -1;
    
    let is_airpods_pro = product.tags.indexOf('airpods_pro') != -1;
    let mini_clutch = product.tags.indexOf('mini_clutch') != -1;

    let eng = is_zodiac_series ? 'engrave icon-chess-piece' : is_art_series ? 'artwork-engrave' : is_airpods_pro ? 'engrave icon-chess-piece airpods-pro' : mini_clutch ? 'engrave icon-chess-piece mini-clutch' : 'engrave icon-chess-piece';


    let text_class = eng +  ' ' + product.product_type.replace(/ /g, '-').toLowerCase() + ' ' + foil.get();
    let text = document.createElement('div');

    if(is_zodiac_series) {
      text.classList.add(zodiac.get().replace(/ /g, '-').toLowerCase());
    }
    if(is_art_series){
      text.classList.add(artwork.get().replace(/ /g, '-').toLowerCase());
    } else {
      text.innerText = initials.get(product.product_type); 
    }
    text.setAttribute('class', text_class);
    rel.appendChild(text);

    let featured_details = document.createElement('div');
    featured_details.classList.add('featured-details');
    featured_details.classList.add('rte');
    featured_item.appendChild(featured_details);

    let p_link = document.createElement('a');
    p_link.setAttribute('href', varURL);
    featured_details.appendChild(p_link);

    let p_title = document.createElement('h4');
    p_title.innerHTML = variant.option1 + '<br>' + product.title;
    p_link.appendChild(p_title);

    let p_price_wrap = document.createElement('div');
    p_price_wrap.classList.add('price');
    featured_details.appendChild(p_price_wrap);
    
    if(variant.compare_at_price != null && product.product_type  != 'Gift Boxes & Tins' ) {
         let variant_compare_price = document.createElement('span');
         variant_compare_price.classList.add('price');
         variant_compare_price.classList.add('compare_price_matching');
         variant_compare_price.classList.add('cart_text');
         variant_compare_price.innerHTML = theme.Currency.formatMoney(variant.compare_at_price,"NO_CURRENCY");
         p_price_wrap.appendChild(variant_compare_price);
      }

    let p_price = document.createElement('span');
    p_price.setAttribute('class', 'price-item price-item--regular');
    if(variant.compare_at_price != null) { 
    	p_price.setAttribute('class', 'compare_price_color');
    }
    p_price.innerText = theme.Currency.formatMoney(parseInt(variant.price) * 100, theme.moneyFormat);
    p_price_wrap.appendChild(p_price);

    let p_info = document.createElement('p');
    p_info.innerHTML = product.body_html;
    
    p_info.innerHTML = mdsProductDes(product.product_type,mini_clutch);
    featured_details.appendChild(p_info);
    p_info.outerHTML += "<br>";

    let p_add = document.createElement('a');
    p_add.setAttribute('class', 'btn btn--pill text-upper add-to-bag ajax-atc');
    p_add.setAttribute('href', varURL);
    p_add.setAttribute('data-variant', variant.id);
    p_add.setAttribute('data-art', is_art_series);
    p_add.setAttribute('data-zodiac', is_zodiac_series);
    p_add.setAttribute('p-type',product.product_type);
    p_add.setAttribute('preorder-text',preorder_text);
    p_add.innerText =preorder_matching ? "Pre-Order":  cart_add;
    featured_details.appendChild(p_add);
  }
  
  return output;
}

function updateMatchingItems(type, colour) {
  const forNotMatchTag = "notmatch2"; //for airpods
  $.getJSON('/collections/matching-slider/products.json', function(recommendations) {
    var items = [];
    var recommendedProducts = recommendations.products.filter(function(product) { return product.product_type != type; });
    if(recommendedProducts.length > 0) {
      recommendedProducts.map(function(product) {
       if(!(product.tags.indexOf(forNotMatchTag) != -1)) { //for airpods
          let sameColour = product.options[product.options.length-1].values.indexOf(colour) != -1;
        if(sameColour) {
          items.push(product);
        }
       }
      });

      if(items.length > 0) {
        let matching_items_desktop = generateMatchingItems(items, 'grid grid--uniform', 'grid__item medium-up--one-half', colour);
        let matching_items_mobile = generateMatchingItems(items, 'css-slider', 'css-slider_slide', colour);
  
        document.querySelector('#product-matching-desktop').innerHTML = matching_items_desktop.outerHTML;
        document.querySelector('#product-matching-mobile').innerHTML = matching_items_mobile.outerHTML;
  
        $('.ajax-atc').click(function(e) {
          e.preventDefault();
  
          let props = {
            'Text': initials.get($(this).attr('p-type')),
            'Foil Color': foil.get(),
            'Pre-order': $(this).attr('preorder-text')!="null" ? $(this).attr('preorder-text'):''
          };
          if(this.dataset.art == "true") {
            props = {
              'Artwork': artwork.get(),
              'Foil Color': 'Gold'
            };
          }
          if(this.dataset.zodiac == "true") {
            props = {
              'Zodiac': zodiac.get(),
              'Foil Color': foil.get()
            };
          }
  
          let form_data = {
            quantity: 1,
            id: this.dataset.variant,
            properties: props
          }
          
          $.post('/cart/add.js', form_data, function(item) {
            loadCart(2);
            
            $('#cartMenu').addClass('open');
            $('html').addClass('no-scroll');
          }, "json");
        });
  
        //createFlickity(matching_items_mobile);
      } else {
        updateMatchingItems(type, 'Black Caviar');
      }
    }
  });
}

// MAISON
$(document).ready(function() {
  // percent: Amount of element required in view:
  // 0.5 - half of the element
  // 1.0 - the entire element
  $.fn.isInViewport = function(percent) {
    var elementTop = $(this).offset().top;
    var elementBottom = elementTop + ($(this).outerHeight() * percent);

    var viewportTop = $(window).scrollTop();
    var viewportBottom = viewportTop + $(window).height();

    return (elementBottom > viewportTop && elementBottom < viewportBottom) || viewportTop > elementBottom;
  };
  // es: jQuery query selector for the elements
  // c: The animation class to toggle
  // p: percent to be in view
  function shouldAnimate(es, c, p) {
    var elements = $(es);
    for(var i = 0; i < elements.length; i++) {
        var element = elements[i];
        if($(element).isInViewport(p)) {
            $(element).addClass(c);
        } else {
            $(element).removeClass(c);
        }
    }
  }

  function checkScroll() {
    shouldAnimate('.line', 'anim', 1);
  }

  // elem: The current price object being updated
  // price: The new price value in money
  function changePrice(elem, price, comparePrice) {
    let regular = elem.querySelector('[data-regular-price]');
    let sale = elem.querySelector('[data-sale-price]');
    let onSale = price < comparePrice;
    if(onSale) {
      elem.classList.add('price--on-sale');
      regular.innerHTML = comparePrice;
      sale.innerHTML = price;
      regular.outerHTML = regular.outerHTML.replace("<span ", "<s ").replace(" span>", " s>");
    } else {
      elem.classList.remove('price--on-sale');
      regular.innerHTML = price;
      sale.innerHTML = price;
      regular.outerHTML = regular.outerHTML.replace("<s ", "<span ").replace(" s>", " span>");
    }
  }
  
  // elem: The swatch button that contains the data attributes we need
  function changeSwatch(elem) {
    if($(elem).hasClass('active')) return;
    let id = elem.dataset.id;
    let target = $('#Target-' + id);
    let target_mob = $('.css-slider ' + '#Target-' + id +',.carousel-cell-mobile ' + '#Target-' + id);
    let img = $('#ProductCardImage-' + id);
    let title = document.querySelectorAll('#Colour-' + id);
    
    let index = elem.dataset.index;
    let imgs1 = $('.list-collections  #ProductCardImageWrapper-' + id).find('.variant-images img');
    let imgs2 = $('.carousel-cell-mobile  #ProductCardImageWrapper-' + id).find('.variant-images img');
    $(imgs1).removeClass('active');
    let image1 = imgs1[index];
    $(image1).addClass('active');

    $(imgs2).removeClass('active');
    let image2 = imgs2[index];
    $(image2).addClass('active');

    let imgs3 = $('.collection-list .carousel #ProductCardImageWrapper-' + id).find('.variant-images img');
    let imgs4 = $('.collection-list .css-slider #ProductCardImageWrapper-' + id).find('.variant-images img');
    $(imgs3).removeClass('active');
    let image3 = imgs3[index];
    $(image3).addClass('active');

    $(imgs4).removeClass('active');
    let image4 = imgs4[index];
    $(image4).addClass('active');
   let imgs5 = $('.collection-list-custom .carousel-custom #ProductCardImageWrapper-' + id).find('.variant-images img');
    $(imgs5).removeClass('active');
    let image5 = imgs5[index];
    $(image5).addClass('active');
    
    let tags = $('#Tags-' + id);

    let new_tag = $(tags).find('.tag-new');
    let new_tag_value = elem.dataset.tagNew;
    if(new_tag_value != null) {
      $(new_tag).removeClass('hide');
      $(new_tag).text(new_tag_value);
    } else {
      $(new_tag).addClass('hide');
    }

    let best_tag = $(tags).find('.tag-best');
    let best_tag_value = elem.dataset.tagBest;
    if(best_tag_value != null) {
      $(best_tag).removeClass('hide');
      $(best_tag).text(best_tag_value);
    } else {
      $(best_tag).addClass('hide');
    }

    let sale_tag = $(tags).find('.tag-sale');
    let sale_tag_value = elem.dataset.tagSale;
    if(sale_tag_value != null) {
      $(sale_tag).removeClass('hide');
     // $(sale_tag).text(sale_tag_value);
    } else {
      $(sale_tag).addClass('hide');
    }
    
    let colour = elem.dataset.colour;
    $('.collection-list .css-slider #ProductCardImageWrapper-' + id).find('.engrave-collection').attr('id',"mono-"+colour.toLowerCase().replace(" ", "-"));
    $('.collection-list .carousel #ProductCardImageWrapper-' + id).find('.engrave-collection').attr('id',"mono-"+colour.toLowerCase().replace(" ", "-"));
    let href = elem.dataset.href;
    $(target).attr('href', href);
    $(target_mob).attr('href', href);
    $(title).html(colour);

    $('.color-swatch-link.active').removeClass('active');
    $(elem).addClass('active');
  }
  $('.color-swatch-link').click(function() {
    changeSwatch(this);
  });
  $('.color-swatch-link').hover(function() {
    changeSwatch(this);
  });

  $(".initials").on('keydown', function(e) {
    if(e.key.length == 2) {
      e.preventDefault();
    } else {
      if(!regex.test(e.key)) {
        customizer.validation.text(true);
      }
    }
  });
  $(document).on('input','.initials', function(e) {
    customizer.change.text(e);
  });
  $(document).on('click','.insert-heart',function() {
    let monogram = document.querySelector('.initials');
    if(monogram.value.length < 4) {
      initials.set(monogram.value + "\u2661");
      initials.update();
    }
    initials.showSlide();
  });
  $( document ).on('mousedown','.initials-heart',function() {
     customizer.change.heart();
  });
   $( document ).on('mousedown',".initials-emoji",function() {
     customizer.change.emoji(this);
  });

  $(document).on('click','.insert-emoji',function() {
    let monogram = document.querySelector('.initials');
    if(monogram.value.length < 4) {
      initials.set(monogram.value + "\u0025");
      initials.update();
    }
    initials.showSlide();
  });
  

  // Navigation Menus
  $('.site-nav--has-dropdown button').click(function() {
    if(isIE()) {
      window.location = this.dataset.href;
    } else {
      let isActive = $(this).parent().hasClass('site-nav--active-dropdown');
      if(!isActive) {
        $('.site-nav--active-dropdown').removeClass('site-nav--active-dropdown');
      }
      $(this).parent().toggleClass('site-nav--active-dropdown');
    }
  });
  $(document).click(function(e) {
    let mega = $(e.target).closest('.mega-menu')[0];
    if(mega == null) {
      $('.site-nav--has-dropdown').removeClass('site-nav--active-dropdown');
    }
  });
  $('.js-modal-open-login-modal').click(function(e) {
    e.preventDefault();
    $('#LoginModal').addClass('show');
  })
  $('.js-modal-close').click(function(e) {
    e.preventDefault();
    $(this).closest('.modal').removeClass('show');
  })

  $('.foil-list input').change(function() {
    foil.set(this.value);
  });

  $('#mobile_sizes').change(function() {
    let url = window.location.origin + this.value;
    window.location = url;
  });

  // Tabs
  function changeTab(tab, link) {
    $('.tabs .active').removeClass('active');

    $(link).parent().addClass('active');
    $(tab).addClass('active');

    let w = 100 / 4;
    let line = $('.tab-active-display .line-wrap');
    $(line).css('left', (link.dataset.index * w) + '%');
    $(line).addClass('sliding');
    setTimeout(function() { $(line).removeClass('sliding'); }, 200);
  }
  $('.tabs ul a, .info-dot').click(function(e) {
    e.preventDefault();
    changeTab($(this.getAttribute('href')), this);
    $('.info-dot.active').removeClass('active');
    $('.info-dot[data-index='+this.dataset.index+']').addClass('active');
  });

  function fixTabHeight() {
    let tabs = $('.tabs-content .tab');
    if(tabs.length) {
      let maxTab = null;
      let height = 0;
      for(let i = 0; i < tabs.length; i++) {
        let rte = $(tabs[i]).find('.rte');
        let h = rte[0].clientHeight;
        if(h > height) {
          height = h;
          maxTab = tabs[i];
        }
      }
      $(maxTab).addClass('bigboy');
    }
  }
  fixTabHeight();

  $('.product-tabs ul a').click(function(e) {
    e.preventDefault();
    if(this.dataset.type != "reviews") {
    	$('.product-tabs .active').removeClass('active');
      $(this).parent().addClass('active');
      $(this.getAttribute('href')).addClass('active');
    }
  });
    
  $('.product-tab-link').click(function(e) {
    if(this.dataset.type == "reviews") {
      document.querySelector('.okeReviews-reviewsSummary').click();
    }
  });

// Collection filters
 let span_filters = $('.collection__filters__selected--options');
  let collection_items = $('.collection__grid .item');

  $('.filter-colour-title').click(function() {
     $(this).parent().find('.filter-btn').trigger('click');
  });

  $('.collection-nav li').click(function() {
      $('input:checkbox').removeAttr('checked');
      $('span,li').removeClass('active');
      setFilter('size','clear',null);
    if($(this).hasClass('bold')) {
        $(this).removeClass('bold');
    }
    else {
      $('.collection-nav li').removeClass('bold');
     let datasize = this.dataset.filter;
     let nav_filter = document.querySelector('.filter-btn[data-type="size"][data-filter="'+datasize+'"][data-device="mobile"]');
     $(nav_filter).trigger('click');
   }

  });

  $('#clear_all,#clear_all_mob').click(function() {
      $('input:checkbox').removeAttr('checked');
      $('span,li').removeClass('active');
      $('.collection-nav li').removeClass('bold');
      setFilter('size','clear',null);
  });

  $(document).on('click','.filter_by', function() {
     let remove_filter = document.querySelector('.filter-btn[data-type="'+$(this).attr('data-type')+'"][data-filter="'+$(this).attr('data-filter')+'"][data-device="'+$(this).attr('data-device')+'"]');
     $(remove_filter).trigger('click');
  });

  $(document).on('click','.sizes-filter input:checkbox', function() {
     let click_btn = document.querySelector('.filter-btn[data-type="'+$(this).attr('data-type')+'"][data-filter="'+$(this).attr('data-filter')+'"][data-device="'+$(this).attr('data-device')+'"]');
    if(!($(this).prop('checked'))) {
        $(this).prop('checked',true);
      }
      else {
         $(this).prop('checked',false);
      }
      $(click_btn).trigger('click');
  });
$(document).on('click','.prices-filter input:checkbox', function() {
     let click_btn = document.querySelector('.filter-btn[data-type="'+$(this).attr('data-type')+'"][data-filter="'+$(this).attr('data-filter')+'"][data-device="'+$(this).attr('data-device')+'"]');
    if(!($(this).prop('checked'))) {
        $(this).prop('checked',true);
      }
      else {
         $(this).prop('checked',false);
      }
      $(click_btn).trigger('click');
  });
  function setFilterSelection(name = null, type= null, filter=null,device=null ) {
    span_filters.parent().removeClass('hide');
    var close_icon = '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><g id="Group_67" data-name="Group 67" transform="translate(3668 755)"><circle id="Ellipse_44" data-name="Ellipse 44" cx="50" cy="50" r="50" transform="translate(-3668 -755)" fill="#676c6f"/> <g id="Group_66" data-name="Group 66" transform="matrix(1, -0.017, 0.017, 1, 14.727, -61.241)"><line id="Line_29" data-name="Line 29" x2="40.487" y2="40.487" transform="translate(-3641.5 -727.5)" fill="none" stroke="#fff" stroke-width="8"/><line id="Line_30" data-name="Line 30" x1="40.487" y2="40.487" transform="translate(-3641.5 -727.5)" fill="none" stroke="#fff" stroke-width="8"/></g></g></svg>';
    if(name != null) {
      $('<span class="filter_by" data-device="'+ device + '" data-type="'+ type + '" data-filter="'+ filter + '" href="javascript:void(0);">' + name + close_icon+'</span>' ).appendTo(span_filters);
    }
  }

  if(collection_items.length > 0) {
    function setFilter(type, value,device) {

      span_filters.empty();
      let btn = document.querySelector('.filter-btn[data-type="'+type+'"][data-filter="'+value+'"]');
      let collection_nav_filter = document.querySelector('.collection-nav li[data-type="'+type+'"][data-filter="'+value+'"]');
      $(collection_nav_filter).toggleClass('bold');
      $('.collection__filters__colours').removeClass('hide');
      if(btn != null || value == 'clear') {
         $('.collection__grid').addClass('filter-' + type);
         collection_items.filter('[data-more-color = true]').removeClass('hide');
         collection_items.filter('[data-extra-color = true]').addClass('hide');
         let size_counter=0;
         let color_counter=0;
        let price_counter= 0;
          collection_items.addClass('hide-'+type);
          $('.collection-product-heading').addClass('hide');
          $('.filter-btn-li input').each(function() {
            if($(this).prop('checked')) {
              if($(this).attr('size') != null) {
                type = 'size';
                value = $(this).attr('size');
                setFilterSelection($.trim($(this).parent().text()),type,value,device);
                size_counter = size_counter + 1;
              }
 if($(this).attr('price') != null) {
                type = 'price';
                value = $(this).attr('price');
                setFilterSelection($.trim($(this).parent().text()),type,value,device);
                price_counter = price_counter + 1;
              }

              if($(this).attr('colour') != null)  {
                type = 'colour';
                value = $(this).attr('colour');
                setFilterSelection(value.replace('-', ' '),type,value,device);
                color_counter = color_counter + 1;
                 //showMoreCollection(value,type);
              }
             
              collection_items.filter('[data-more-color = true][data-' + type + '="' + value  + '"]').addClass('hide');
              collection_items.filter('[data-extra-color = true]').removeClass('hide');
              $('.collection-product-heading').filter('[data-size="' + $(this).attr('size')  + '"]').removeClass('hide');
             $('.collection-heading-all').filter('[data-heading="' + $(this).attr('heading')  + '"]').removeClass('hide');

              // collection_items.filter('[data-size="' + $(this).attr('size') + '"]').removeClass('hide-'+type);
              collection_items.filter('[data-' + type + '="' + value  + '"]').removeClass('hide-' + type);
            }
          });
          if(size_counter == 0 && color_counter==0 && price_counter==0) {
            $('.collection__filters__selected #clear_all, .collection__filters__selected #clear_all_mob').addClass('hide');
            $('.collection__filters__selected--options').addClass('hide');
            $('.item-hide-mob').addClass('hide-mobile');
          }
          else {
            $('.item-hide-mob').removeClass('hide-mobile');
            $('.collection__filters__selected #clear_all , .collection__filters__selected #clear_all_mob').removeClass('hide');
            $('.collection__filters__selected--options').removeClass('hide')
          }
          if(size_counter == 0 ) {
             $('.collection-product-heading').removeClass('hide');
             collection_items.removeClass('hide-size');
          }
          if(color_counter == 0 ) {
            // $('.collection-product-heading').removeClass('hide');
             collection_items.removeClass('hide-colour');
             //$('.collection__filters__selected').addClass('hide');
          }
        if(price_counter == 0 ) {
            // $('.collection-product-heading').removeClass('hide');
             collection_items.removeClass('hide-price');
             //$('.collection__filters__selected').addClass('hide');
          }
          else {
            $('.collection-product-heading').addClass('hide');
          }
      }
    }
    $('.filter-btn').click(function() {
      if(! ($(this).prev('input').prop('checked'))) {
        $(this).prev('input').prop('checked',true);
        $(this).parent().addClass('active');
        $(this).parent().parent().find('.filter-colour-title').addClass('bold');
      }
      else {
        $(this).prev('input').prop('checked',false);
        $(this).parent().removeClass('active');
        $(this).parent().parent().find('.filter-colour-title').removeClass('bold');
      }
      let type = this.dataset.type;
      let filter = this.dataset.filter;
      let device = this.dataset.device;

      setFilter(type, filter,device);

      if(window.matchMedia('(max-width:991px)').matches) {
        $('#refine').removeClass('is-open');
        $('#refine').toggle('height'); //filter collection changes
      }
    });
    if(slate.utils.getParameterByName('size') !== null) {
      setFilter('size', slate.utils.getParameterByName('size'),null);
    }
    if(slate.utils.getParameterByName('colour') !== null) {
      setFilter('colour', slate.utils.getParameterByName('colour'),null);
    }
  }


  //collection filter mob
  $('.collection-mob--filter').click(function() {
    scrollLock(function() {
      $('#collectionMenu').toggleClass('open');
      $('html').toggleClass('no-scroll');
    });
  });
  $('.close-coll-filter span').click(function() {
    scrollLock(function() {
      $('.menu').removeClass('open');
      $('html').removeClass('no-scroll');
    });
  });  // Mobile menu
  // Mobile menu
  $('.js-mobile-nav-toggle').click(function() {
    scrollLock(function() {
      $('#mobileMenu').toggleClass('open');
      $('html').toggleClass('no-scroll');
    });
  });
  $('.menu-close, .menu-mask').click(function() {
    scrollLock(function() {
      $('.menu').removeClass('open');
      $('html').removeClass('no-scroll');
      $('.subnav-toggle').trigger('click');
    });
  });
  $('.subnav-toggle').click(function() {
    let open = $(this).hasClass('open');
    let nav__inner = $(this).parent().parent().hasClass('nav--inner');
    if(!nav__inner) {
      $('.nav-list.level-1').addClass('level-1-open-nav');
      $('.nav-list__item:not(.nav--inner--list)').addClass('hide');
      let nav_id = $(this).attr('data-title');
      $('.nav-list__item.nav--inner--list').filter('[data-title="' + nav_id + '"]').removeClass('hide');
      $('.nav--inner').filter('[data-title="' + nav_id + '"]').addClass('open-nav');
      $(this).parent(':not(.level-1').addClass('hide');
    }
    else {
       $('.nav-list.level-1').removeClass('level-1-open-nav');
       $('.nav-list__item').removeClass('hide');
       $('.nav--inner').removeClass('open-nav');
    }
    $(this).next('.nav-list').toggle('height');
  });
  // Cart menu
  $('.site-header__cart').click(function(e) {
    e.preventDefault();
    scrollLock(function() {
       $('trigger', 'site-header__cart');
      $('#cartMenu').toggleClass('open');
      $('html').toggleClass('no-scroll');
    });
  });
  
  $('.tab-toggle').click(function() {
    if(this.dataset.type != "reviews") {
      var btn = $(this).parent().find('.tab-toggle');
      var target = $(this).parent().find('.panel')[0];
      var isOpen = $(target).hasClass('is-open');
      
      // Close all
      $('.product-tabs-mobile .tab-toggle.open').removeClass('open');
      var panels = $('.product-tabs-mobile .panel.is-open');
      for(let i = 0; i < panels.length; i++) {
        let panel = panels[i];
        $(panel).toggleClass('is-open');
        $(panel).toggle('height');
      }

      if(!isOpen) {
        $(btn).toggleClass('open');
        $(target).toggleClass('is-open');
        $(target).toggle('height');
      }
    }
  });
$('li.tab-toggle-2').click(function() {

      var btn = $(this).parent().find('.tab-toggle-2');

      var target = $(this).parent().find('.panel-2')[0];

      var isOpen = $(target).hasClass('is-open');
      // Close all
      $('li.tab-toggle-2.open').removeClass('open');
      var panels = $('.panel-2.is-open');
      for(let i = 0; i < panels.length; i++) {
        let panel = panels[i];
        $(panel).toggleClass('is-open');
        $(panel).toggle('height');
      }

      if(!isOpen) {
        $(btn).toggleClass('open');
        $(target).toggleClass('is-open');
        $(target).toggle('height');
      }

  });
  function swapAccountPage(hash) {
    $('.account-nav .active').removeClass('active');
    $('.account-page.active').removeClass('active');
    $('.account-navlink[href="' + hash + '"]').parent().addClass('active');
    $(hash).addClass('active');
  }

  $('.account-navlink, .account-btn').click(function(e) {
    e.preventDefault();
    swapAccountPage(this.getAttribute('href'));
  });

  $('.settings-btn').click(function() {
    $('#settingsMenu').toggleClass('open');
    $('html').toggleClass('no-scroll');
  });

  $('.gif-link').mouseenter(function() {
    let src = this.querySelector('img').src;
    this.querySelector('img').src = '#';
    this.querySelector('img').src = src;
  });

  function loadLandingPage() {
    var countStarted = false;

    function checkCounter() {
      if ($('#countryCount').isInViewport(0.5) && !countStarted) {
        count($('#countryCount'), $('#countryCount').data('number'), 300, 1);
        countStarted = true;
      }
    }

    function count(elem, endnum, time, step) {
      var curnum = 0;
      var step = step || 1;

      elem.text(curnum.toString().replace(",", ""));
      var timer = window.setInterval(function () {
        if (curnum < endnum) {
          if (curnum + step > endnum) {
            step = 1;
          }
          curnum += step;
          elem.html(curnum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
        } else {
          clearInterval(timer);
        }

      }, 10);
    }

    window.onscroll = function() {
      checkCounter();
    };
    checkCounter();
  }
  
  var carousels = $('.carousel');
  function checkFlickity() {
    carousels = $('.carousel');
    for(let i = 0; i < carousels.length; i++) {
      let carousel = carousels[i];
      if($(carousel).isInViewport(0.001)) {
        if($(carousel).hasClass('flickity-enabled')) {
          // Get all cells
          let cells = carousel.querySelectorAll('.carousel-cell');
          let biggestCell = cells[0];
          for(let j = 0; j < cells.length; j++) {
            let cell = cells[j];
            // If biggest cell is smaller than the cell from the loop
            if(biggestCell == null || biggestCell.offsetHeight < cell.offsetHeight) {
              // Declare a new biggest cell
              biggestCell = cell;
            }
          }
          // If the carousel is smaller than the biggest cell resize the carousel
          if(carousel.offsetHeight < biggestCell.offsetHeight) {
            $(carousel).flickity('resize');
          } else {
            $(carousel).addClass('loaded');
          }
        } else {
          createFlickity(carousel)
        }
      }
    }
  }
  if(carousels[0] != null) {
    setInterval(checkFlickity, 100);
  }
  
  var prev_scroll = window.scrollY;
  var atc_btn = $('.product-form__item--submit .product-form__cart-submit, .lavender-cta');
  window.addEventListener('scroll', function() {
    checkScroll();

    // Check to show or hide the nav
    new_scroll = window.scrollY;
    if(new_scroll > prev_scroll && new_scroll > 100) {
      // scrolled down
      $('#shopify-section-header').addClass('hidden');
      $('.collection__filters').addClass('topzero');
    } else {
      // scrolled up
      $('#shopify-section-header').removeClass('hidden');
      $('.collection__filters').removeClass('topzero');
    }
    prev_scroll = new_scroll;

    if($(atc_btn).length != 0) {
      var elementBottom = $(atc_btn).offset().top + $(atc_btn).outerHeight();
      var viewportTop = $(window).scrollTop();

      if(initials.get() == '' && artwork.get() == 'No Artwork' && zodiac.get() == 'No Zodiac' && $('.cp-image.black-caviar-mym-edition').hasClass('hide')) {
        // Personalise now
        $('.placebo-atc').find('.normal').addClass('hide');
        $('.placebo-atc').find('.custom').removeClass('hide');
      } else {
        // Add to bag
        $('.placebo-atc').find('.normal').removeClass('hide');
        $('.placebo-atc').find('.custom').addClass('hide');
      }

      if(viewportTop > elementBottom) {
        $('.placebo-atc').addClass('show');
      } else {
        $('.placebo-atc').removeClass('show');
      }
    }
  });
  
  $('.placebo-atc .btn.product-form__cart-submit').click(function(e) {
    e.preventDefault();

    if(initials.getMonogram() == '' && artwork.get() == 'No Artwork' && zodiac.get() == 'No Zodiac' && $('.cp-image.black-caviar-mym-edition').hasClass('hide')) {
      customizer.open();
    } else {
      $(atc_btn).click();

      let txt = $(this).find('[data-add-to-cart-text]');
      let loader = $(this).find('[data-loader]');
      $(txt).addClass('hide');
      $(loader).removeClass('hide');

      setTimeout(function() {
        $(txt).removeClass('hide');
        $(loader).addClass('hide');
      }, 1000);
    }
  });

$('.matching-heading').click(function(event,empty = null) {
    if(empty!=null && empty == 'open'){
     $(this).addClass('open');
   }
   else {
    $(this).toggleClass('open');
   }
    if($(this).hasClass('open') ){
    	$('.cart__matching').css('background',"#f4f4f4");
        $('.css-slider').slideDown(300,function() {
        });
  	}
   	else
    {
      $('.cart__matching').css('background',"#fff");
      $('.css-slider').slideUp( 300,function() {});
      
    }
  });
  function isBannerPage() {
    const banner_pages = ['index','blog','article','list-collections','page-skyBlue','page-blog','page-rsvp'];
    for(let i = 0; i < banner_pages.length; i++) {
      let c = 'template-' + banner_pages[i];
      if(document.querySelector('body').classList.contains(c)) {
        document.querySelector('#shopify-section-header').style.marginBottom = -(document.querySelector('#shopify-section-header').getBoundingClientRect().height) + "px";
      }
    }
  }

  $(window).resize(function() {
    isBannerPage();
  });

  if(isIE()) {
    $('html').addClass('ie-sucks');
  }

  function loadCustom() {
    initials.load();
    foil.load(true);
    artwork.load();
    valentine.load();
    zodiac.load();
    if($('.customizer_personalize').length) {
      customizer.load(true);
    }

    isBannerPage();

    // Product sliders
    if(document.querySelector('.product-images .p-slider') != null) {
      loadProductSliders();
    }
    
    if(document.querySelector('.lp-mob-slider') != null || document.querySelector('.color-list-slider') != null) {
      loadProductSliders();
   //   loadProductSliders2();
      $('.color-option .mickey-red').trigger('click');
    }
    if(document.querySelector('.product-left--desk') != null) {
      loadLpDeskImages();
    }
    

    if($('.page-landing').length != 0) {
      loadLandingPage();
    }
    
    // If it hasn't been closed today
    var now = new Date();

    if(localStorage.getItem('mdsCookies') != now.toDateString()) {
      // Show cookies bar
      $('.cookies-bar').toggle('height');
    }
    $('.cookies-bar__close').click(function() {
      $(this).closest('.cookies-bar').toggle('height');
      localStorage.setItem('mdsCookies', now.toDateString());
    });

    if(localStorage.getItem('mdsAnnouncement') != "DDDD") {
      // Show announcment bar
    //  $('.announcement-bar').toggle('height');
    }
    $('.announcement-bar__close').click(function() {
      $(this).closest('.announcement-bar').toggle('height');
      localStorage.setItem('mdsAnnouncement', now.toDateString());
    });
    if(sessionStorage.getItem("cvoidClose")=="true") {
    	$('.covid-bar').addClass('hide');
    }
    else {
    	$('.covid-bar').removeClass('hide');
    }

    
    if(localStorage.getItem('mdsNewsletter') == null) {
      let prevScroll = window.scrollY;
      let popped = false;
      $(window).scroll(function(e) {
        if(!popped) {
          let newScroll = window.scrollY;
          if(prevScroll < newScroll) {
            setTimeout(function() {
              // Show newsletter popup
              $('.newsletter-popup').addClass('active');
              popped = true;
            }, 1000);
          }
          prevScroll = newScroll;
        }
      });
    }
    $('.newsletter-close').click(function() {
      $('.newsletter-popup').removeClass('active');
      localStorage.setItem('mdsNewsletter', now.toDateString());
    });
    $('.newsletter_form').submit(function(e) {
      e.preventDefault();
      let form = this;
      let email = form.querySelector('input[type="email"]');
      if(form.checkValidity()) {
        $(email).removeClass('invalid');
        var action  = '/contact?';
            action += encodeURIComponent('form_type') +'='+ encodeURIComponent('customer');
            action += '&'+ encodeURIComponent('utf8') +'='+ encodeURIComponent('✓');
            action += '&'+ encodeURIComponent('contact[tags]') +'='+ encodeURIComponent('newsletter');
            action += '&'+ encodeURIComponent('contact[email]') +'='+ encodeURIComponent(email.value);
        $.ajax({
            type: "POST",
            async: true,
            url: action,
            success: function(response) {
              email.outerHTML = '<label style="width: 100%;color: green;">'+newsletter_thanks+'</label>';
              form.querySelector('.btn--submit').setAttribute('disabled', '');

              setTimeout(function() {
                $('.newsletter-popup').removeClass('active');
                localStorage.setItem('mdsNewsletter', now.toDateString());
              }, 3000);
            }
        });
      } else {
        $(email).addClass('invalid');
        $('.error-message').addClass('show');
        setTimeout(function() {
          $(email).removeClass('invalid');
          $('.error-message').removeClass('show');
        }, 1500);
      }
    });
    $(document).click(function(e) {
      let dropdown = $(e.target).closest('.drop-down-wrapper')[0];
      if(dropdown == null) {
        $('.drop-down-btn').removeClass('active');
        $('.drop-down').removeClass('active');
      }
    });

    $('.drop-down-btn').click(function() {
      // Can't just toggle since there may be multiple and one could be active
      let isActive = $(this).hasClass('active');
      
      $('.drop-down-btn').removeClass('active');
      $('.drop-down').removeClass('active');
      
      if(!isActive) {
        $(this).addClass('active');
        $(this).next('.drop-down').addClass('active');
      }
    });

    $('.drop-down-wrapper .drop-down a').click(function() {      
      $('.drop-down-btn').removeClass('active');
      $('.drop-down').removeClass('active');
    });
    $('.drop-down-artwork .drop-down a').click(function() {
      artwork.set(this.dataset.artwork);
    });
    $('.drop-down-amount .drop-down a').click(function(e) {
      e.preventDefault();
      $('.drop-down-amount .drop-down-btn').text(this.innerText);
      $('#Amount').val(this.dataset.variant);
      $('#Amount').trigger('change');
    });
    if($('#Amount')[0] != null) {
      var targetAmount = $('.drop-down-amount a')[3];
      $(targetAmount).click();
      $('.drop-down-amount .drop-down-btn').text(targetAmount.text);
    }
    
    // Get Country Code
    let countryCode = document.getElementById('country_code');
    let shipping_benefits = document.getElementById('shipping_benefits');
   
    if(countryCode != null) {
      // By default set it to Worldwide incase t he IP Info can't return a contry
      countryCode.innerHTML = ' Worldwide';
    }
    if(countryCode != null) {
    $.get("https://ipapi.co/json/", function (response) {
      if(response!= null) {
        
      countryCode.innerHTML = ' to ' + response.country_code;
      if(response.country_code == 'US') { 
        

       $('.express-shipping .method-cost').each(function(){
          	$(this).text('$10');
       });
        $('.shipping-description--us').each(function(){
                $(this).removeClass('hide');
              });
          $('.shipping-description--others').each(function(){
                $(this).addClass('hide');
         });
      }
      else {
          $('.shipping-description--others').each(function(){
                $(this).removeClass('hide');
              });
          $('.shipping-description--us').each(function(){
                $(this).addClass('hide');
         });
      }
       // shipping_tabUs.classList.add('hide');
       // shipping_tabOthers.classList.remove('hide');
      }
    });
    }


    // Account page, load active
    if(window.location.hash != '') {
      var accountLink = $('.account-navlink[href="' + window.location.hash + '"]');
      if(accountLink != null) {
        swapAccountPage(window.location.hash);
      } 
    }
    
    var add_to_bags = document.querySelectorAll('.add-to-bag');
    for(let i = 0; i < add_to_bags.length; i++) {
      let add_to_bag = add_to_bags[i];
      add_to_bag.addEventListener('click', function(e) {
        e.preventDefault();
        let btn_text = $(this).find('[data-add-to-cart-text]');
        let btn_loader = $(this).find('[data-loader]');
        if(btn_text != null && btn_loader != null) {
          $(btn_text).addClass('hide');
          $(btn_loader).removeClass('hide');
        }
        let props = {
          'Text': initials.get($(this).attr('p-type')),
          'Foil Color': foil.get(),
          'Pre-order':$(this).attr('preorder-text') !="null" ? $(this).attr('preorder-text') : null
        };
        
        if(initials.get($(this).attr('p-type')) != "") {
          props = {
            'Text': initials.get($(this).attr('p-type')),
            'Foil Color': foil.get(),
            'Pre-order':$(this).attr('preorder-text') !="null" ? $(this).attr('preorder-text') : null
          };
        }
        if(this.classList.contains('is_art_series')) {
          if(artwork.get() != "No Artwork") {
            props = {
              'Artwork': artwork.get(),
              'Foil Color': 'Gold'
            };
          }
        }
        if(this.classList.contains('is_zodiac_series')) {
          if(zodiac.get() != "No Zodiac") {
            props = {
              'Zodiac': zodiac.get(),
              'Foil Color': foil.get()
            };
          }
        }
        $.post('/cart/add.js', {
          quantity: 1,
          id: this.dataset.variant,
          properties: props
        }, function(item) {
          loadCart(0);
          if(btn_text != null && btn_loader != null) {
            $(btn_text).removeClass('hide');
            $(btn_loader).addClass('hide');
          }
          $('#cartMenu').addClass('open');
          $('html').addClass('no-scroll');
        }, "json");
      });
    }
  }

  if(document.readyState == 'complete') {
    loadCustom();
  } else {
    $(window).bind('load', loadCustom);
  }
});

window.addEventListener('DOMContentLoaded', function(e) {
  function registerBlackline(swiper) {
    const line = swiper.querySelector('.swiper-line');
    let isDown = false;
    let hasDragged = false;
    let currentSlide = 0;

    let carousel = swiper.parentElement.querySelector('.swiper-carousel');
    let slider = carousel.querySelector('.flickity-slider');
    // set black line width based on viewport size and slider width
    function getCellsWidth(carousel) {
      let cells = carousel.querySelectorAll('.carousel-cell');
      let cells_width = 0;
      for(let i = 0; i < cells.length; i++) {
        let cell = cells[i];
        if(cell != null) {
          cells_width += cell.offsetWidth;
        }
        // Add on margin right if the cell isn't the last
        if(i < cells.length - 1) {
          cells_width += parseInt(getComputedStyle(cell).marginRight.replace('px', ''));
        }
      }
      return cells_width;
    }
    line.style.width = ((carousel.offsetWidth / getCellsWidth(carousel)) * 100).toString() + "%";
    
    function startDrag(e) {
      if(e.target == line || e.target == swiper) {
        isDown = true;
        hasDragged = false;

        line.classList.add('dragging');
        onDrag(e);
      }
    }
    function endDrag(e) {
      isDown = false;
      line.classList.remove('dragging');
    }
    function onDrag(e) {
      if (!isDown) return;

      var scrollX = typeof window.scrollX != "undefined" ? window.scrollX : 0;
      const x = e.clientX + scrollX - swiper.offsetParent.offsetLeft;
      const widthOffset = line.offsetWidth;
      const maxWalk = swiper.offsetWidth - widthOffset;
      let walk = x - (widthOffset / 2);
      hasDragged = walk !== 0;

      // mouse_loc = get the % position of the mouse on the bar
      let mouse_loc = (walk / maxWalk);
      if(mouse_loc < 0) { mouse_loc = 0; }
      if(mouse_loc > 1) { mouse_loc = 1; }

      // slider_loc = the % scroll of the slider
      let carousel = swiper.parentElement.querySelector('.swiper-carousel');
      let slider = carousel.querySelector('.flickity-slider');
      let style = getComputedStyle(slider);
      let matrix = null;
      if(isIE()) {
        matrix = new MSCSSMatrix(style.msTransform);
      } else {
        matrix = new WebKitCSSMatrix(style.webkitTransform);
      }
      let tx = -matrix.m41;
      let maxT = getCellsWidth(carousel) - slider.offsetWidth;
      let slider_loc = tx / maxT;

      // find the difference between mouse_loc and slider_loc
      let delta_loc = mouse_loc - slider_loc;

      // apply the difference as the force below
      let force = delta_loc * 10;

      try {
        var $carousel = $('.swiper-carousel').flickity('applyForce', -force).flickity('startAnimation').flickity('dragEnd');
        /*
        let flkty = new Flickity('.swiper-carousel');
        flkty.applyForce(-force);
        flkty.startAnimation();
        flkty.dragEnd();
        */
      } catch(ex) {
      }
    }

    // Mobile
    swiper.addEventListener('touchstart', function(e) {
      startDrag(e.touches[0]);
    }, {passive: true});
    window.addEventListener('touchend', function(e) {
      endDrag(e);
    }, {passive: true});
    window.addEventListener('touchmove', function(e) {
      //if(hasDragged) { e.preventDefault(); }
      onDrag(e.touches[0]);
    }, {passive: true});

    // Desktop
    swiper.addEventListener('mousedown', function(e) {
      startDrag(e);
    });
    window.addEventListener('mouseleave', function(e) {
      endDrag(e);
    });
    window.addEventListener('mouseup', function(e) {
      //if(hasDragged) { e.preventDefault(); }
      endDrag(e);
    });
    window.addEventListener('mousemove', function(e) {
      onDrag(e);
    });
    
    
    // update when swipe on slider
    function updateLine(swiper) {
      //if (isDown) return;

      let carousel = swiper.parentElement.querySelector('.swiper-carousel');
      let slider = carousel.querySelector('.flickity-slider');

      if(slider != null) {
        let style = getComputedStyle(slider);
        let matrix = null;
        if(isIE()) {
          matrix = new MSCSSMatrix(style.msTransform);
        } else {
          matrix = new WebKitCSSMatrix(style.webkitTransform);
        }

        let tx = -matrix.m41;
        let overflow = tx / slider.offsetWidth;

        let line = swiper.querySelector('.swiper-line');
        line.style.transform = "translate3d(" + (overflow * 100).toString() + "%, 0px, 0px)";
        line.style.width = ((slider.offsetWidth / getCellsWidth(carousel)) * 100).toString() + "%";
      }
    }
    setInterval(function() {
      updateLine(swiper);
    }, 100);
  }
  let swipers = document.querySelectorAll('.swiper-bar');
  let isDesktop = window.matchMedia('(min-width:992px)').matches;
  if(swipers.length > 0) {
    for(let i = 0; i < swipers.length; i++) {
      let swiper = swipers[i];
      registerBlackline(swiper);
    }
  }
});

function loadGiftText(add_text, complete_text) {
  $('[data-gift-text],[data-atc-text]').text(localStorage.getItem('mdsGift') == 'first' ? add_text : complete_text);
}

/* Zodiac */
if($('.zodiac-slider').length != 0) {
  createFlickity($('.zodiac-slider'));
}

function swapZodiacIcon(z) {
  let handle = z.toLowerCase().replace(/ /g, '-');

  // Set the zodiac icon to active
  $('.zodiac-icon').removeClass('active');
  $('.zodiac-icon[data-zodiac="'+ z +'"]').addClass('active');

  // Show the info for the correct zodiac under the size select
  $('.zodiac-info').removeClass('active');
  $('#zodiac-info-' + handle).addClass('active');

  // Assign the current zodiac to the product grid
  $('#zodiac-products').attr('data-zodiac', handle);
}
function setZodiac(handle, date) {
  // Set the zodiac choice
  zodiac.set(handle);
  
  $('[data-zodiac-name]').text(handle);
  $('[data-zodiac-date]').text(date);

  swapZodiacIcon(handle);
}

function showZodiacSlide(index) {
  var $carousel = $('.zodiac-slider').flickity();
  $carousel.flickity( 'selectCell', index );
}

$('.zodiac-icon').click(function() {
  let zodiac = this.dataset.zodiac;
  let date = this.dataset.date;

  setZodiac(zodiac, date);

  showZodiacSlide($(this).closest('.zodiac-slide').index());
});

$(window).bind('load', function() {
  var current_zodiac = zodiac.get();
  if(current_zodiac != 'No Zodiac') {
    swapZodiacIcon(current_zodiac);
    
    showZodiacSlide($('.zodiac-icon.active').closest('.zodiac-slide').index());

    var date = $('.zodiac-icon.active').data('date');
    
    $('[data-zodiac-name]').text(current_zodiac);
    $('[data-zodiac-date]').text(date);
  }
});

// CSS Black Line
function cssBlackLine(scrollbar) {
  let isDown = false;
  let hasDragged = false;
  let isScrolling = false;

  const scrollHandle = scrollbar.querySelector('.css-scrollbar_handle');
  const slider = scrollbar.previousElementSibling;

  scrollHandle.style.width = (scrollbar.offsetWidth / slider.childElementCount) + "px";
  
  function startDrag(e) {
    isDown = true;
    hasDragged = false;

    scrollbar.classList.add('dragging');
  }
  function endDrag(e) {
    isDown = false;
    scrollbar.classList.remove('dragging');
  }
  function onBarDrag(e) {
    if (!isDown) return;

    var scrollX = typeof window.scrollX != "undefined" ? window.scrollX : 0;
    const x = e.clientX + scrollX - scrollbar.offsetParent.offsetLeft;
    const widthOffset = scrollHandle.offsetWidth;
    const maxWalk = scrollbar.offsetWidth - widthOffset;
    let walk = x - (widthOffset / 2);
    hasDragged = walk !== 0;

    if(walk > maxWalk) { walk = maxWalk; }
    if(walk < 0) { walk = 0; }

    scrollHandle.style.left = walk + "px";

    let scrollPercent = walk / maxWalk;
    let sliderScroll = (slider.scrollWidth - slider.offsetWidth) * scrollPercent;

    slider.scrollLeft = sliderScroll;
  }
  function onSliderDrag() {
    let scrollPercent = slider.scrollLeft / (slider.scrollWidth - slider.offsetWidth);
    let walk = (scrollbar.offsetWidth - scrollHandle.offsetWidth) * scrollPercent;
    hasDragged = walk !== 0;

    if(walk < 0) { walk = 0; }

    scrollHandle.style.left = walk + "px";
  }
  
  scrollbar.addEventListener('touchstart', function(e) {
    isScrolling = true;
  });
  setInterval( function() {
    if(!isScrolling) { onSliderDrag(); }
  }, 10);

  window.addEventListener('touchstart', function(e) {
    startDrag(e.touches[0]);
  });
  window.addEventListener('touchend', function(e) {
    isScrolling = false;
    endDrag(e);
  });
  scrollbar.addEventListener('touchmove', function(e) {
    if(hasDragged) { e.preventDefault(); }
    onBarDrag(e.touches[0]);
  });
  slider.addEventListener('touchmove', function(e) {
    if (isDown) { onSliderDrag(); }
  }, { passive: true } );
}

let cssLine = document.querySelector('.css-scrollbar');
if(cssLine != null) {
  //cssBlackLine(cssLine);
}

$('#country_select').change(function() {
  let url = this.value;
  window.location = url;
});

if(slate.utils.getParameterByName('discount') !== null) {
  localStorage.setItem('mdsDiscount', slate.utils.getParameterByName('discount'));
}
if(localStorage.getItem('mdsDiscount') != null) {
  $('.cart').append('<input type="hidden" name="discount" value="'+ localStorage.getItem('mdsDiscount') +'">');
}
if(slate.utils.getParameterByName('print') !== null) {
  valentine.set(slate.utils.getParameterByName('print'));
  $('.valentine-prompt').removeClass('hidden');
}

// COVID
$('.covid-open').click(function() {
  $('.covid-popup').addClass('open');
  $('html').addClass('no-scroll');
});
$('.covid-close').click(function() {
  $('.covid-popup').removeClass('open');
  $('html').removeClass('no-scroll');
});
$('.covid-bar-close').click(function() {
  $('.covid-bar').toggle('height');
    sessionStorage.setItem('cvoidClose', 'true');
});

//faq js starts here

function hideQuestions(option) {

    $('.faq__faq--questions').each(function(){
	   	if(option=='readmore') {
	    	$(this).addClass('hide');
	    }
	    else {
	      $(this).removeClass('hide');
	    }
    });
  	$('.readmore_section').toggleClass('faq_readmore');
}

function expandQuestion(heading,body) {
  	$('.faq-readmore__heading').text(heading).show('slow');
  	$('.faq-readmore__body').append(body);
}

function resetallfaqs(back=false) {

if(back) {
      var index=0;
      $('.faq__faq--questions').each(function(){
        if(index<4) {
        $(this).removeClass('hide');
        }
        index++;
      });
      $('.readmore_section').removeClass('faq_readmore');
  	  $('.related_questions').addClass('hide');
  		hideShippingInformation();
  	}
    $('.faq__search').val('');
  	//
  	$('.clear_search_icon').addClass('hide');
	$('.faq__search').keyup();
}

function filterRelatedFaqs(tag="notag",heading="noheading") {
  var found=false;
  var tag = tag.split(' ');
  $('.related_questions').addClass('hide');
  $('.related_question--all').each(function(){
      if($(this).hasClass($.trim(tag[1])) && $.trim(heading) != $.trim($(this).find('h5').text())){
          $(this).removeClass('hide');
          if(!found){
            $('.related_questions').removeClass('hide');
          }
              found=true;
      }
    else {
   		 $(this).addClass('hide');
    }
    });
}

$('.readfullanswer').on('click',function(e){
  hideShippingInformation();
  setgreybackground('#faq_search_box');
  var tag = $(this).parents().eq(1).find('.faq_tag').text();
  jQuery('html,body').animate({scrollTop:0},0);
  var body_text= $(this).parents().eq(1).find('.faq_answer-full').html();
  var tag = $(this).parents().eq(1).find('.faq_tag').text();
  var heading_text= $(this).closest('div').find('h2').text();
  filterRelatedFaqs(tag,heading_text);
  $('.faq-readmore__heading').text('');
  $('.faq-readmore__body').text('');
  $('.readmore_section').removeClass('faq_readmore');
  hideQuestions('readmore');
  expandQuestion(heading_text,body_text);
  e.preventDefault();
});

$('.search_a').on('click',function(e){
   if($(this).hasClass('ship-info')){
    shippingInformation();
  }
  else {
    hideShippingInformation();
  }

  var body_text = $(this).next('span').html();
  var tag = $(this).find('span').text();
  var heading_text= $(this).clone().children().remove().end().text();
  filterRelatedFaqs(tag,heading_text);
  body_text=body_text.replace('class="hide"', '');
  $('.faq-readmore__heading').text('');
  $('.faq-readmore__body').text('');
  $('.readmore_section').removeClass('faq_readmore');
  hideQuestions('readmore');
  expandQuestion(heading_text,body_text);
  $('.faq__search').val('');
  $('.faq__search').keyup();
  e.preventDefault();
});

function faqselected(heading_text,body_text)
{
  $('.faq__search').removeClass('search_suggestion');
  $('.faq-readmore__heading').text('');
  $('.faq-readmore__body').text('');
  $('.readmore_section').removeClass('faq_readmore');
  hideQuestions('readmore');
  expandQuestion(heading_text,body_text);
}

$('.faq_readmore--button').on('click',function(){
	resetallfaqs(true);
  	setgreybackground('.faq-row');
  	$('.related_questions').addClass('hide');
});

$('.faq__search').keyup(function() {
  $('.search_a').addClass('hide');
  filterFunction();
  if($(this).val()=='') {
  	$('.search_a').addClass('hide');
    $('#myDropdown').css('visibility','hidden');
    $('#myDropdown').css('display','none');
    $('.clear_search_icon').addClass('hide');
  }
  else {
    $('.clear_search_icon').removeClass('hide');
  }
});

function filterFunction() {
  var found = false;
  var counter = 0;
  var input, filter ,a;
  input = document.getElementById("faq_search_box");
  filter = input.value.toUpperCase();
  div = document.getElementById("myDropdown");
  a = div.getElementsByClassName("search_a");
  for (i = 0; i < a.length; i++) {
    txtValue = a[i].textContent || a[i].innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1)
      {
        if(counter<5) {
          a[i].classList.remove("hide");
          a[i].classList.add("last-suggestion");
          counter++;
          }
          found=true;
      } else {
          a[i].classList.add("hide");
      	}
   }
  if(!found){
    $('#myDropdown').css('visibility','hidden');
    $('#myDropdown').css('display','none');
  }
  else {
    $('#myDropdown').css('display','block');
    $('#myDropdown').css('visibility','visible');
  }
}

$('.clear_search_icon').on('click',function(){
	resetallfaqs();
});

// accordio js starts here
$('.faq-toggle').click(function() {
    let isOpen = $(this).hasClass('open');
  	$('.faq-toggle.open').nextUntil('.faq-toggle').filter('.related_answer').slideUp( 400, function() {
    // Animation complete.
});
   // $('.faq-toggle.open').nextUntil('.faq-toggle').filter('p').toggle('height');
    $('.faq-toggle.open').removeClass('open');


    if(!isOpen) {
      $(this).toggleClass('open');
     // $(this).nextUntil('.faq-toggle').filter('p').toggle('height');
      $(this).nextUntil('.faq-toggle').filter('.related_answer').slideDown( 400, function() {
    // Animation complete.
	});
    }
});

function setgreybackground(classname='.faq-row') {

}
setgreybackground();

function setbackgroundheight() {
  if($('.template-page').hasClass('template-page-contact')) {
    var elementOffset = $("#shopify-section-footer").offset().top;
    $('.background-image').css('height',elementOffset+50);
    $('.blurfordesktop').css('height',elementOffset+50);
    $('.blurformob').css('height',elementOffset+50);
   
  }
}

$(window).resize(function() {

	setbackgroundheight();

});

setbackgroundheight();

$(".explore").click(function() {
    $('html, body').animate({
        scrollTop: $("#product-sky").offset().top
    }, 1000);
});

$(".airpod-banner-btn-mob").click(function() {
 
  var scrolltosection=$('.top-content__heading');
    $('html, body').animate({
        scrollTop: $(scrolltosection).offset().top-50
    }, 800);
  
});

$(".scroll-to-element").click(function() {
 
  var scrolltosection='.' + $(this).data('scroll');
    $('html, body').animate({
        scrollTop: $(scrolltosection).offset().top
    }, 800);
  
});


var color = $( "#shopify-section-header" ).css( "background-color" );
var signup_btn = $('.signup-accordion');
$(window).on("load resize scroll", function() {
if(signup_btn.length!=0) { //we are on airpod page
     var elementBottom = $(signup_btn).offset().top + $(signup_btn).outerHeight();
     var viewportTop = $(window).scrollTop(); 
     var pos = $('.airpodsdetailsbottom').offset().top;
 
     if(elementBottom<viewportTop) {
       $('.airpod__signup_sticky').addClass('show');
     }
     else {
       $('.airpod__signup_sticky').removeClass('show');
     }
  }
 $(".about-content-sky").each(function() {
    var windowTop = $(window).scrollTop();
    var elementTop = $(this).offset().top;
    var leftPosition = windowTop - elementTop;
    
      $(this).find(".move-div-image").css("left",(leftPosition / 8) + "px");
   	  $('.mobile-heading-sky').find(".move-div-image").css("left",(50-leftPosition / 8) + "px");
  });
   
//header starts here
if(! ($('body').hasClass('template-collection') || $('body').hasClass('template-page-collection-gift-him') || $('body').hasClass('template-page-collection-gift-her')) ) {
    if(window.scrollY<=0 ){
      if($('body').hasClass('template-customers-login')  && $(window).width()>991) {
         $("#shopify-section-header" ).css( "background",'#fff');
        $("#shopify-section-header" ).css( "box-shadow",'rgb(245, 245, 245) 0px 2px');
          $('body').removeClass('template-scroll-affect');
      }
      else {
          if(color=="rgb(244, 244, 244)") {
           $("#shopify-section-header" ).css( "background",color);
          }
          else {
          $("#shopify-section-header" ).css( "background",'linear-gradient(to bottom, #5046464f, transparent 90%)');
          }
          $('body').removeClass('template-scroll-affect');
        }
      }
      if(window.scrollY>=5) {
        $( "#shopify-section-header" ).css( "background",'rgba(0,0,0,0.5)');
        $('body').addClass('template-scroll-affect');
      }
 }
});

//notify for sold out js starts here 

$("#notifyemail, .sold-out-info span").on('click',function(e){
  var btn= document.getElementById('notifyemail');
  var emailField=document.getElementById('k_id_email');
  var formId=document.getElementById('product_email_notify');
  emailField.classList.add('notify-email');
  btn.classList.add('small-btn');
  btn.innerText ='Submit';
  emailField.classList.remove('hide');
  //console.log(btn.type);
  if(btn.type!='submit'){
  	e.preventDefault();
  }
  btn.type='submit'; // cancel default behavior
});

function resetNotifydiv() {
  var btn= document.getElementById('notifyemail');
  if(btn!=null) {
  btn.disabled=false;
  var emailField=document.getElementById('k_id_email');
  var formId=document.getElementById('product_email_notify'); 
//  formId.action='#';
  emailField.classList.remove('notify-email');
  btn.classList.remove('small-btn');
  btn.classList.remove('btn-full');
  btn.innerHTML ='Reserve Now';
  emailField.classList.add('hide');
  btn.type='button';
  }
}

//preorder js
$('.pre-order-info,.mym-video').click(function() {
  $('.preorder-popup').addClass('open');
  $('html').addClass('no-scroll-preorder');
});
$('.preorder-close,.mym-close').click(function() {
  $('.preorder-popup').removeClass('open');
  $('html').removeClass('no-scroll-preorder');
});

$('.afterpay,.cart-status.cart-afterpay p').click(function() {
  $('.afterpay-popup').addClass('open');
  $('html').addClass('no-scroll');
});

$('.afterpay-close, .preorder-popup_mask').click(function() {
  $('.afterpay-popup').removeClass('open');
  $('html').removeClass('no-scroll');
});

// new product page slider for mob 

$(".ReviewCount--product").click(function() {
    $('html, body').animate({
        scrollTop: $("#shopify-section-product-reviews").offset().top
    }, 1000);
});

$('.lp_carousel').flickity({
  freeScroll: true,
  contain: true,
  prevNextButtons: false,
  pageDots: false,
  cellAlign: "left",
});


$('.lp-btn-customizer').click(function() {
  var clicked_product=$(this).attr('id');
  $('#lp-product-desk').addClass('hide');
  $('.customizer').each(function() {
    if(! $(this).hasClass(clicked_product)) {
      $(this).remove();
    }
  });
  var selected_Color = $(this).closest('.product_section--ic').find('.color-option-border').attr('value');
  let target = document.getElementById('color-' + selected_Color);
  if( (!target.checked) && localStorage.getItem('mdsColor') != selected_Color ) {
      target.click();
  }
   $('.lp-products-section').each(function(){
    if(!$(this).hasClass(clicked_product)){
      $(this).remove();
    }
    else {
      $(this).removeClass('hide');
    }
  });
  $('#color-' + selected_Color).trigger('change');
    customizer.open();
  $('.product_section--ic').addClass('hide');
  $('.product_prop').addClass('hide');

  $('.lp_product--mob').addClass('hide');
  $('.color-option').removeClass('color-option-border');

});

$('.lp-color-option').on('click',function(){
  $(this).addClass('color-option-border');
    $(this).closest('.color-list').find('.lp-color-option').each(function() {
    $(this).removeClass('color-option-border');
  });

  var changeimg = $(this).attr('value');
  $(this).closest('.product_section--ic').find('.p-slide-main img').each(function(){
    if($(this).hasClass(changeimg)) {
      $(this).removeClass('hideopacity');
    }
    else {
      $(this).addClass('hideopacity');
    }
  });
   $(this).addClass('color-option-border');
});


function filterimages (color) {
  $('.filter-desk-img').each(function(){
    if($(this).hasClass(color) ) {
   // $(this).show(600);
      $(this).fadeIn(500);
  }
  });
  $('.filter-desk-img').each(function(){
    if(!$(this).hasClass(color) ) {
   // $(this).show(600);
      $(this).fadeOut(500);
  }
 
  });
}
if($('.shipping--info').length>0) {
  $.get("https://ipapi.co/json/", function (response) {
    $('.shipping--info').removeClass('hide');
    $('.shipping--info h1').text($('.shipping--info h1').text().replace('[country]',response.country_name));
    $('.contact-ipaddress').val(response.ip);
  });
}

$('.story-review--text a').click(function(){
  $('.story-review--text').fadeOut(500);
});


/* Blog Category Page - Display All blogs */

function openBlogCategory(evt, catName,home=null) {
  var i, tabcontent, tablinks, signupblock;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  if(catName == "all_blogs") {
    for (i = 0; i <  document.getElementsByClassName(catName).length; i++) {
       $('.signup-block').css('display','none');
       document.getElementById('signup-block--all').style.display = "block";
       document.getElementsByClassName(catName)[i].style.display = "block";
    }
  }
  else {
    $('.'+catName +' .signup-block').css('display','block');
    document.getElementById('signup-block--all').style.display = "none";
    document.getElementsByClassName(catName)[0].style.display = "block";
}
  if(home != null) {
    $('.mds-thinks .content-block').addClass('hide');

    $( ".mds-thinks .content-block:nth-child(2)" ).removeClass('hide');
    $( ".mds-thinks .content-block:nth-child(4)" ).removeClass('hide');
    $( ".mds-thinks .content-block:nth-child(6)" ).removeClass('hide');
    $( ".mds-thinks .content-block:nth-child(8)" ).removeClass('hide');

  }
  else {
    $('.mds-thinks .content-block').removeClass('hide');
  }
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
if(document.getElementById("defaultOpen") != null) {
	document.getElementById("defaultOpen").click();
}

/* Blog Category Page - Display All blogs */

$('.color-list-slider1 input:radio').change(function(e) {
  e.preventDefault();
  let colorHandle = $(this).attr('value');
   $('.color-list-slider1 input:radio').attr('checked',false);
  $(this).prop('checked', true);
  $('.css-color-slider1').each(function(){
    if($(this).hasClass(colorHandle)){
      $(this).removeClass('hide-position');
    }});
 $('.css-color-slider1').each(function(){
    if(!$(this).hasClass(colorHandle)){
      $(this).addClass('hide-position');
 }});


  listFilterSliders(colorHandle);
  localStorage.setItem('mdsColor', colorHandle);

});

$('.color-list-slider2 input:radio').change(function(e) {
  e.preventDefault();
  let colorHandle = $(this).attr('value');
   $('.color-list-slider2 input:radio').attr('checked',false);
  $(this).prop('checked', true);
  $('.css-color-slider2').each(function(){
    if($(this).hasClass(colorHandle)){
      $(this).removeClass('hide-position');
    }});
 $('.css-color-slider2').each(function(){
    if(!$(this).hasClass(colorHandle)){
      $(this).addClass('hide-position');
 }});

  listFilterSliders2(colorHandle);

});

function preorder() {
  $('.preorder-popup').addClass('open');
  $('html').addClass('no-scroll-preorder');
}

$('.btn--main--arrow').hover(function () {
        $('.btn--main--arrow span' ).addClass('move_arrow');
    }, function () {
        // change to any color that was previously used.
        $('.btn--main--arrow span' ).removeClass('move_arrow');
});

$('.cart__submit-control').on('click',function(){
  $(this).addClass('hide');
  $('.checkout-loading').removeClass('hide');
});

$('.collapse_menu').click(function() {
  	$('.mega-menu .site-nav__childlist-grid').css('max-height','600px');
    $(this).addClass('hide');
    $('.expand_menu').removeClass('hide');
    $('.extra_menu_items').slideDown( 300, function() {
  });
});
$('.expand_menu').click(function() {
    $(this).addClass('hide');
    $('.collapse_menu').removeClass('hide');
    $('.extra_menu_items').slideUp( 200, function() {
      $('.mega-menu .site-nav__childlist-grid').css('max-height','465px');
    });
});
$(".hover-img").hover(function(){
    $(this).parent().find(".engrave").addClass('hide');
    }, function(){
     $(this).parent().find(".engrave").removeClass('hide');
});

$(".color-filter-slider .engrave").hover(function(){
   $(this).parent().find(".hover-img").trigger('mouseenter');
});


$('.val_close').on('click',function(){
  $('.valentine_card').fadeOut(400);
});

var mym_change= false;
function checkmym(is_mym,discount_img) {
  if(is_mym) {
    mym_change =true;
    $('#mym_variant').val("true");
    $('.customizer_edit').addClass('hide');
    $('.customizer_personalize').removeClass('hide');
    $('.customizer_personalize').removeAttr('href');
    $('.customizer_personalize').attr('disabled','disabled');
    $('#input_text').val('');

    zodiac.set('No Zodiac',true);
    $('.case-product-grid .details,.default-tab').addClass('hide');
    $('.case-product-grid .mym-details,.mym-tab').removeClass('hide');
    $('.tabs ul a[href="#tab1"]').trigger('click');
  }
  else {
    if(mym_change) {
      $('.tabs ul a[href="#tab1"]').trigger('click');
    }
    mym_change =false;
    $('#mym_variant').val("false");

    $('#input_text').val(localStorage.getItem('mdsEngraving'));
    $('.case-product-grid .details,.default-tab').removeClass('hide');
    $('.case-product-grid .mym-details,.mym-tab').addClass('hide');
    if(localStorage.getItem('mdsZodiac') != 'No Zodiac' || (localStorage.getItem('mdsEngraving') != '' && localStorage.getItem('mdsEngraving') != null)) {
      $('.customizer_edit').removeClass('hide');
      $('.customizer_personalize').addClass('hide');
      $('.customizer_personalize').attr('href','javascript:customizer.open();');
      $('.customizer_personalize').removeAttr('disabled');
    }
    else {
      $('.customizer_personalize').attr('href','javascript:customizer.open();');
      $('.customizer_personalize').removeAttr('disabled');
      $('.customizer_edit').addClass('hide');
      $('.customizer_personalize').removeClass('hide');
    }
  }
}

$.getJSON('https://api.db-ip.com/v2/free/self', function(data) {
  if(data.countryCode == 'US'){
  	$('.cart-status.cart-afterpay').removeClass('hide');
  }
});

function mdsProductDes(productTitle = null, mini = false) {
  productTitle = productTitle.toLowerCase();
  if(productTitle == 'airpods') {
    return airpods_description;
  }
  if(productTitle == 'phone case') {
    return phone_cases_description;
  }
   if(productTitle == 'sling phone case') {
    return sling_description;
  }
  if(productTitle == 'apple watch band') {
    return apple_description;
  }
  if(productTitle == 'notebook') {
    return notebook_description;
  }
  if(productTitle == 'keychain') {
    return keychain_description;
  }
  if(productTitle == 'card holder') {
    return card_holder_description;
  }
  if(productTitle == 'pocket bifold') {
    return pocket_bifold_description;
  }
  if(productTitle == 'zipped wallet') {
    return zipped_wallet_description;
  }
  if(productTitle == 'card case') {
    return card_case_description;
  }
  if(productTitle == 'clutches' && mini) {
    return mini_clutch_description;
  }
  if(productTitle == 'clutches' && !mini) {
    return clutch_description;
  }
  if(productTitle == 'bifold wallet') {
    return bifold_description;
  }
  if(productTitle == 'laptop case') {
    return laptop_description;
  }
  if(productTitle == 'beauty pouch') {
    return beauty_description;
  }
  if(productTitle == 'mini tote') {
    return tote_description;
  }
  if(productTitle == 'micro cross body') {
    return mcb_description;
  }
    if(productTitle == 'crossbody phone pouch') {
    return crossBody_description;
  }
  return '';
}

$('.bundles_size_3,.bundles_size_2:not(.holiday_size_2),.bundles_size_1:not(.holiday_size_1)').on('change', function() {
  changeBundlePrice();
});

function changeBundlePrice() {
    var selected_color = $('.color-list input:checked').val();
  //  var value = $('.holiday_size_1').children("option:selected").val();
    var select_size_1 = $('.bundles_size_1').children("option:selected").val();
    var index_1 = $(".product-1-color[data-variant='"+selected_color+"'][data-size='"+select_size_1+"']").data("index");
    var variant_1_price = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("price");
    var variant_1_comprice = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("comprice");
    

    var select_size_2 = $('.bundles_size_2').children("option:selected").val();
    var index_2 = $(".product-2-color[data-variant='"+selected_color+"'][data-size='"+select_size_2+"']").data("index");
    var variant_2_price = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("price");
    var variant_2_comprice = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("comprice");

    var select_size_3 = $('.bundles_size_3').children("option:selected").val();
    var index_3 = $(".product-3-color[data-variant='"+selected_color+"'][data-size='"+select_size_3+"']").data("index");
    var variant_3_price = $(".product-3-id[data-index='"+index_3+"'][data-size='"+select_size_3+"']").data("price");
    var variant_3_comprice = $(".product-3-id[data-index='"+index_3+"'][data-size='"+select_size_3+"']").data("comprice");
  
    var tech_price = theme.Currency.formatMoney((variant_1_price + variant_2_price)*0.80, theme.moneyFormat).replace('USD','');
    var tech_compare_price = theme.Currency.formatMoney(variant_1_price + variant_2_price, theme.moneyFormat).replace('USD','');
    var tech_save = theme.Currency.formatMoney((variant_1_price + variant_2_price) - ((variant_1_price + variant_2_price)*0.80), theme.moneyFormat);
  if($('.product-2-id').length <= 0) { 
    tech_price = theme.Currency.formatMoney(variant_1_price*0.80  , theme.moneyFormat);
     tech_compare_price = theme.Currency.formatMoney(variant_1_price, theme.moneyFormat);
     tech_save = theme.Currency.formatMoney(( tech_compare_price - tech_price), theme.moneyFormat);
    }
  
  if($('.engrave').hasClass('essentials-set')) {
   tech_price = theme.Currency.formatMoney((variant_1_price + variant_2_price + variant_3_price)*0.80, theme.moneyFormat);
          tech_compare_price = theme.Currency.formatMoney(variant_1_price + variant_2_price + variant_3_price, theme.moneyFormat).replace('USD','');
    tech_save = theme.Currency.formatMoney((variant_1_price + variant_2_price + variant_3_price) - ((variant_1_price + variant_2_price + variant_3_price)*0.80), theme.moneyFormat);
  }
    if($('.product-3-id').length > 0 && (!$('.engrave').hasClass('essentials-set'))) { 
      
      tech_price = theme.Currency.formatMoney((variant_1_price + variant_2_price + variant_3_price)*0.75, theme.moneyFormat);
          tech_compare_price = theme.Currency.formatMoney(variant_1_price + variant_2_price + variant_3_price, theme.moneyFormat).replace('USD','');
    tech_save = theme.Currency.formatMoney((variant_1_price + variant_2_price + variant_3_price) - ((variant_1_price + variant_2_price + variant_3_price)*0.75), theme.moneyFormat);

      if($('.product-sizes-watch').length > 0 ) {
                  tech_price = theme.Currency.formatMoney((variant_1_price + variant_2_price + variant_3_price)*0.90, theme.moneyFormat);
    tech_save = theme.Currency.formatMoney((variant_1_price + variant_2_price + variant_3_price) - ((variant_1_price + variant_2_price + variant_3_price)*0.90), theme.moneyFormat);

            }
    }
      $('.product-single__details [data-sale-price],.product-mob-nosize [data-sale-price]').text(tech_price);
      $('.product-single__details [data-regular-price], .product-mob-nosize [data-regular-price]').text(tech_compare_price);
      $('.savings span').text('Save '+tech_save);
    

}
if(localStorage.getItem('Olympic') != null) {
     OlympicEdition();
    }
function OlympicEdition() {
  $('label[for="color-olympic-edition"],label[for="customizer-color_olympic-edition"]').addClass('show');
  $('a.filter-btn.colour.olympic-edition').addClass('show');
}
function checkDisney(is_disney) {

  
  if(is_disney) {
    $('.details:not(.disney)').addClass('hide');
     $('.details.disney').removeClass('hide');
    $('.normal_desc').addClass('hide');
    $('.disney_desc').removeClass('hide');
     $('.disney').removeClass('hide');
     $('.li-product-accordion .disney').removeClass('hide');
  }
  else {
        $('.normal_desc').removeClass('hide');
    $('.disney_desc').addClass('hide');
    // $('.content_desc').removeClass('hide');
    $('.is_coral').addClass('hide');

    $('.details:not(.disney)').removeClass('hide');
     $('.details.disney').addClass('hide');
    
     
     $('.li-product-accordion .olym').addClass('hide');
     $('.details.mym-details').addClass('hide');
    $('.details.Olympic').addClass('hide');
    $('.details.disney').addClass('hide');
    $('.details.coral_blue').addClass('hide');
    
   
  }
}

function checkEta(variantTitle,product){
  variantTitle = variantTitle.replace(/\W+/g, "-").toLowerCase() + '-eta:';
  var preorder_text ='';
  	for(i=0;i<product.tags.length;i++) {
            if(product.tags[i].includes(variantTitle)) {
              preorder_text=product.tags[i].split(':')[1];
            }
      
        }
  if(product.title.includes('13')) {
    preorder_text = ' end of February, 2022';
  }
  if(preorder_text != '' || product.title.includes('13')) {
    $('input[name="properties[Pre-order]"').val('Ships from ' + preorder_text);
    $('.pre-order-text a').text('Third release to ship from ' + preorder_text);
    $('[data-ships-preorder]').text('Ships from ' + preorder_text);
  }
  else {
    for(i=0;i<product.tags.length;i++) {
      if(product.tags[i].includes('preorder_date:')) {
              preorder_text=product.tags[i].split(':')[1];
            }
        }
    $('[data-ships-preorder]').text('Ships from ' + preorder_text);
    $('input[name="properties[Pre-order]"').val('Ships from ' + preorder_text);
    $('.pre-order-text a').text('Arriving from ' + preorder_text);
  }

}
$('#holiday,#holiday_1').click(function() {

  var gift_variant = 40944977019062;

   var monogram1 =$('.customizer__text--preset').text();
  var monogram2 =$('.customizer__text--preset').text();
  var monogram3= $('.customizer__text--preset').text();
    if($('.p-type').text().includes('Style')) {
      monogram2 = monogram1[0] + monogram1[1];
    }
    if($('.p-type').text().includes('Go-to')) {
      monogram2 = monogram1[0] + monogram1[1];

    }
    if($('.p-type').text().includes('Tech')) {
      monogram3 = monogram1[0] + monogram1[1];
    }
    if($('.p-type').text().includes('Twin')) {
    }
    if($('.p-type').text().includes('Essentials')) {
      monogram3 = monogram1[0] + monogram1[1];
    }
    var foil = 'gold';
    if(localStorage.getItem('mdsFoil') != null) {
      foil = localStorage.getItem('mdsFoil').toLowerCase();
    }
  if($('.customizer__text--preset').text().length <= 0){
    monogram1 = monogram2 = monogram3 = '';
  }
   if(monogram1[1] == 'undefined' || monogram1[1] == null || monogram1[1].length == 0 && (monogram1[0] != null )){

    monogram2 =  monogram3 = monogram1[0];
  }
 

    var selected_color = $('.color-list input:checked').val();
    var select_size_1 = $('.bundles_size_1').children("option:selected").val();
    var index_1 = $(".product-1-color[data-variant='"+selected_color+"'][data-size='"+select_size_1+"']").data("index");
    var variant_1 = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("variant");
    var select_size_2 = $('.bundles_size_2').children("option:selected").val();
    var index_2 = $(".product-2-color[data-variant='"+selected_color+"'][data-size='"+select_size_2+"']").data("index");
    var variant_2 = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("variant");
    var variant_1_available = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("available");
    var variant_2_available = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("available");
    var variant_1_preorder = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("preorder");
    var variant_2_preorder = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("preorder");
    var pre1,pre2,pre3 = null;
    if(select_size_1.includes('Laptop')) {
      gift_variant = 40944977445046;
    }
    if(select_size_1.includes('Mini Tote')) {
      gift_variant = 40944977608886;
    }
  if(variant_1_preorder) {
    pre1 = 'Ships from 30th December';
  }
  if(variant_2_preorder) {
    pre2 = 'Ships from 30th December';
  }

if($('.product-2-id').length > 0) { 

      $.post('/cart/add.js', {
            'items': [{
            'id': variant_1,
            'quantity': 1,
            properties: {
                'Text': monogram1,
                 'Foil Color':foil,
                 'Pre-order': pre1,
              }
            },
            {
            'id': variant_2,
            'quantity': 1,
             properties: {
                'Text': monogram2,
                'Foil Color':foil,
                'Pre-order': pre2,
              }
            },
            {
            'id': gift_variant,
            'quantity': 1,
             properties: ""
            }]
             
            }, function(item) {
             // $('button[name="checkout"]').trigger('click');
              loadCart(2);
               $('#cartMenu').addClass('open');
            $('html').addClass('no-scroll');
            }, "json");
    }
    else {
       $.post('/cart/add.js', {
            'items': [{
            'id': variant_1,
            'quantity': 1,
            properties: {
                'Text': monogram1,
                 'Foil Color':foil,
                 'Pre-order': pre1,
              }
            },
            {
            'id': gift_variant,
            'quantity': 1,
             properties: ""
            }]
             
            }, function(item) {
             // $('button[name="checkout"]').trigger('click');
              loadCart(2);
               $('#cartMenu').addClass('open');
            $('html').addClass('no-scroll');
            }, "json");
    }
});

$('.holiday_size_1,.holiday_size_2').on('change', function() {
  changeHolidayPrice();
});

function changeHolidayPrice() {

    var selected_color = $('.color-list input:checked').val();
    var select_size_1 = $('.holiday_size_1').children("option:selected").val();
    var index_1 = $(".product-1-color[data-variant='"+selected_color+"'][data-size='"+select_size_1+"']").data("index");
    var variant_1_price = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("price");
    var variant_1_comprice = $(".product-1-id[data-index='"+index_1+"'][data-size='"+select_size_1+"']").data("comprice");
    

    var select_size_2 = $('.holiday_size_2').children("option:selected").val();
    var index_2 = $(".product-2-color[data-variant='"+selected_color+"'][data-size='"+select_size_2+"']").data("index");
    var variant_2_price = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("price");
    var variant_2_comprice = $(".product-2-id[data-index='"+index_2+"'][data-size='"+select_size_2+"']").data("comprice");

    var tech_price = theme.Currency.formatMoney((variant_1_price + variant_2_price)*0.85, theme.moneyFormat);
    var tech_compare_price = theme.Currency.formatMoney(variant_1_price + variant_1_price, theme.moneyFormat);
    var tech_save = theme.Currency.formatMoney((variant_1_price + variant_2_price) - ((variant_1_price + variant_2_price)*0.85), theme.moneyFormat).replace('USD','');
    if($('.product-2-id').length <= 0) { 
    tech_price = theme.Currency.formatMoney(variant_1_price*0.85  , theme.moneyFormat);
     tech_compare_price = theme.Currency.formatMoney(variant_1_price, theme.moneyFormat);
     tech_save = theme.Currency.formatMoney(( tech_compare_price - tech_price), theme.moneyFormat).replace('AUD','');
    }
      
      $('.product-single__details [data-sale-price],.product-mob-nosize [data-sale-price]').text(tech_price);
      $('.product-single__details [data-regular-price], .product-mob-nosize [data-regular-price]').text(tech_compare_price);
      $('.savings span').text('Save '+tech_save);
    
}
//holiday sets js ends .......

$('.size_help').click(function() {
  $('.size_help-popup').addClass('open');
  $('.size_help-popup').css('display','flex');
  $('html').addClass('no-scroll');
});
$('.size_help-close, .size_help_mask,.preorder-popup_mask,.size_help-btn').click(function() {
$('.size_help-popup').removeClass('open');
  $('html').removeClass('no-scroll');
});

$(".more_characters").on('click',function(){
 if($(".extra-svgs .svgs").is(':visible')) {
  $(".extra-svgs .svgs").slideUp();
}
else {  $(".extra-svgs .svgs").slideDown();

}
});



$('.collection__filters__colours label.bold,.collection__filters__sizes label.bold').on('click',function(){
	$(this).parent().toggleClass('open');
	$(this).parent().find('ul').slideToggle(500);
});

function metafieldCta (variant) {

var metafields_data = document.querySelector('#metafields_data');
     let metafields_text = '';
     if(metafields_data != null) {
        let variants = metafields_data.value.split('?');
        for(var i = 0; i < variants.length; i++) {
          let values = variants[i].split(':');
          if(values[0] == variant.id) {
            metafields_text = values[1];
            if(metafields_text != '' ) {
            $('.product-benefits  p').text(metafields_text);
            }
          }
        }
      }
}
$('.customizer-grid-top').flickity({

  cellAlign: 'left',
  contain: true,
    groupCells: true,
    pageDots:false

});
// show limited text description product starts
$(".text-box").text(function(index, currentText) {
  var maxLength = $(this).attr('data-maxlength');
  if(currentText.length >= maxLength) {
    return currentText.substr(0, maxLength) + "...";
  } else {
    return currentText
  } 
});
// ends